import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative w-full py-16 md:py-24 flex items-center justify-center overflow-hidden border-b border-[#E7E3DA]">
      {/* Background Matte Texture */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16 items-center">
        
        {/* Text Content */}
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-block px-3 py-1 rounded-full border border-[#E7E3DA] bg-[#F4F1EA] text-[11px] uppercase tracking-[0.25em] text-[#78716C] font-semibold mb-6"
          >
            Fine Living & Artisanal Pantry
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl sm:text-6xl lg:text-7xl font-serif-luxury font-normal leading-[1.08] text-[#1C1917] tracking-tight"
          >
            The art of <br />
            <span className="italic font-light text-[#78716C]">fine living.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="mt-6 text-base sm:text-lg text-[#78716C] font-normal max-w-lg leading-relaxed"
          >
            Curated exceptional ingredients delivered with uncompromising quality. Welcome to the new standard of organic produce & premium pantry.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="mt-8 flex flex-wrap items-center gap-4"
          >
            <button 
              onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
              className="group inline-flex items-center justify-center px-8 py-3.5 text-xs font-semibold uppercase tracking-widest text-[#FAF9F5] bg-[#1C1917] hover:bg-[#292524] transition-all cursor-pointer rounded-sm"
            >
              Explore Collection
              <ArrowRight className="ml-3 w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </motion.div>
        </div>

        {/* Textured Visual Display */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="hidden md:block relative h-[420px]"
        >
          <div className="absolute inset-0 bg-[#F4F1EA] rounded-2xl border border-[#E7E3DA] p-4 flex gap-4 overflow-hidden">
            <div className="w-1/2 h-full rounded-xl overflow-hidden relative group">
              <img 
                src="https://images.unsplash.com/photo-1618897996318-5a901fa6ca3a?auto=format&fit=crop&q=80&w=600" 
                alt="Fresh Produce"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1C1917]/40 via-transparent to-transparent flex items-end p-4">
                <span className="text-xs uppercase tracking-widest text-[#FAF9F5] font-medium">Artisanal Selection</span>
              </div>
            </div>
            <div className="w-1/2 h-full rounded-xl overflow-hidden relative group">
              <img 
                src="https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&q=80&w=500" 
                alt="Organic Harvest"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1C1917]/40 via-transparent to-transparent flex items-end p-4">
                <span className="text-xs uppercase tracking-widest text-[#FAF9F5] font-medium">Direct Farm Origin</span>
              </div>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
}
