import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Loader2, LogOut, Check, Mail, Lock, User, Sparkles, Phone, ShieldCheck, ArrowRight, Smartphone } from "lucide-react";
import { useCart } from "../CartContext";
import { auth, googleProvider, appleProvider, db } from "../lib/firebase";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile, 
  signInWithPopup, 
  signInWithRedirect,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult
} from "firebase/auth";

export function AuthModal({ isOpen, onClose, hideClose = false }: { isOpen: boolean; onClose: () => void; hideClose?: boolean }) {
  const { user, logoutUser } = useCart();
  const [authMethod, setAuthMethod] = useState<"email" | "phone">("email");
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [step, setStep] = useState<"login" | "success">("login");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Email state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");

  // Phone state
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);

  const [phase, setPhase] = useState<"enter" | "walkToCard" | "grab" | "pull" | "release" | "idle" | "vanish">("idle");
  const recaptchaVerifierRef = useRef<RecaptchaVerifier | null>(null);

  useEffect(() => {
    if (isOpen) {
      setError(null);
      setStep("login");
      setMode("signin");
      setIsLoading(false);
      setOtpSent(false);
      setOtp("");
      setPhase("idle");
    }
  }, [isOpen]);

  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      setStep("success");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      if (err.code === "auth/user-not-found" || err.code === "auth/wrong-password" || err.code === "auth/invalid-credential") {
        setError("Invalid email or password. Don't have an account? Click 'Create Account' above.");
      } else {
        setError(err.message || "Failed to sign in. Please check your credentials.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      setError("Please enter your full name");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(userCredential.user, {
        displayName: fullName
      });
      setStep("success");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      if (err.code === "auth/email-already-in-use") {
        setError("An account with this email already exists.");
      } else if (err.code === "auth/weak-password") {
        setError("Password should be at least 6 characters.");
      } else {
        setError(err.message || "Failed to create account. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
      setStep("success");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      if (
        err?.code === "auth/popup-blocked" || 
        err?.code === "auth/popup-closed-by-user" ||
        err?.code === "auth/operation-not-supported-in-this-environment"
      ) {
        try {
          await signInWithRedirect(auth, googleProvider);
          return;
        } catch (redirectErr: any) {
          setError(redirectErr.message || "Failed to sign in with Google.");
        }
      } else {
        setError(err.message || "Failed to sign in with Google.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleSignIn = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, appleProvider);
      setStep("success");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      if (
        err?.code === "auth/popup-blocked" || 
        err?.code === "auth/popup-closed-by-user" ||
        err?.code === "auth/operation-not-supported-in-this-environment"
      ) {
        try {
          await signInWithRedirect(auth, appleProvider);
          return;
        } catch (redirectErr: any) {
          setError(redirectErr.message || "Apple Sign In requires Apple Developer configuration.");
        }
      } else {
        setError(err.message || "Apple Sign In requires active Apple Developer service credentials.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const setupRecaptcha = () => {
    if (!recaptchaVerifierRef.current) {
      recaptchaVerifierRef.current = new RecaptchaVerifier(auth, 'recaptcha-container', {
        size: 'invisible',
        callback: () => {
          // reCAPTCHA solved
        },
      });
    }
    return recaptchaVerifierRef.current;
  };

  const handleSendPhoneOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber.trim()) {
      setError("Please enter a valid phone number with country code (e.g. +91 9876543210)");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const verifier = setupRecaptcha();
      const formattedPhone = phoneNumber.startsWith('+') ? phoneNumber.trim() : `+91${phoneNumber.trim()}`;
      const confirmation = await signInWithPhoneNumber(auth, formattedPhone, verifier);
      setConfirmationResult(confirmation);
      setOtpSent(true);
    } catch (err: any) {
      console.warn("Phone OTP Error:", err);
      if (err.code === "auth/operation-not-allowed") {
        setError("Phone authentication is not enabled for this region. Please configure it in your Firebase Console -> Authentication -> Settings -> Phone authentication, or use Email/Google Sign-In instead.");
      } else {
        setError(err.message || "Failed to send SMS code. Make sure to format phone number as +91XXXXXXXXXX.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyPhoneOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp.trim()) {
      setError("Please enter the 6-digit code");
      return;
    }
    setIsLoading(true);
    setError(null);

    if (!confirmationResult) {
      setError("Please request a verification code first.");
      setIsLoading(false);
      return;
    }

    try {
      await confirmationResult.confirm(otp.trim());
      setStep("success");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      setError("Invalid verification code. Please check and try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.3 } }}
          className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md overflow-y-auto supports-[height:100dvh]:h-[100dvh]"
        >
          {/* Background overlay click to close */}
          <div className="absolute inset-0" onClick={onClose} />

          {/* Hidden recaptcha container */}
          <div id="recaptcha-container"></div>

          {/* Card Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="relative w-full max-w-md bg-white border border-stone-200/90 rounded-[2.5rem] p-6 sm:p-8 shadow-2xl z-10 max-h-[90dvh] overflow-y-auto custom-scrollbar"
          >
            {/* Close Button */}
            {!hideClose && (
              <button
                onClick={onClose}
                className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-full transition-colors z-20"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            )}

            {user ? (
              <motion.div
                key="logged-in"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-6"
              >
                {user.picture ? (
                  <img
                    src={user.picture}
                    alt={user.name}
                    className="w-20 h-20 rounded-full mx-auto mb-4 shadow-md border border-stone-200 object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-2xl font-serif font-bold mx-auto mb-4 text-amber-700 shadow-md">
                    {user.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                <h2 className="text-2xl font-serif font-bold text-stone-900 mb-1">
                  {user.name}
                </h2>
                <p className="text-xs text-stone-500 mb-6 font-light flex items-center justify-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-500" />
                  JIYOO Member Account
                </p>

                <button
                  onClick={() => {
                    logoutUser();
                    setTimeout(() => {
                      onClose();
                    }, 500);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-medium transition-all duration-200 text-sm border border-stone-200"
                >
                  <LogOut className="w-4 h-4" /> Sign Out
                </button>
              </motion.div>
            ) : step === "success" ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-10"
              >
                <div className="w-16 h-16 bg-stone-900 rounded-full flex items-center justify-center mx-auto mb-6 text-white shadow-lg">
                  <Check className="w-8 h-8 text-amber-400" />
                </div>
                <h2 className="text-2xl font-serif font-bold text-stone-900 mb-2">
                  Welcome to JIYOO
                </h2>
                <p className="text-xs text-stone-500 font-light tracking-wide uppercase">
                  Redirecting to your experience...
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="auth-form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                {/* Header */}
                <div className="text-center mb-6">
                  <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 tracking-tight mb-1">
                    {mode === "signin" ? "Sign In to JIYOO" : "Join JIYOO"}
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-500 font-light">
                    Select your preferred login method
                  </p>
                </div>

                {/* Main Social Quick Auth Buttons */}
                <div className="grid grid-cols-2 gap-2.5 mb-5">
                  {/* Google Button */}
                  <button
                    type="button"
                    onClick={handleGoogleSignIn}
                    disabled={isLoading}
                    className="flex items-center justify-center gap-2 py-3 px-3 bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-800 rounded-xl font-medium text-xs transition-all shadow-2xs hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <svg viewBox="0 0 24 24" className="w-4 h-4 shrink-0">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    <span>Google</span>
                  </button>

                  {/* Apple ID Button */}
                  <button
                    type="button"
                    onClick={handleAppleSignIn}
                    disabled={isLoading}
                    className="flex items-center justify-center gap-2 py-3 px-3 bg-black text-white hover:bg-stone-900 rounded-xl font-medium text-xs transition-all shadow-2xs hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current shrink-0">
                      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.32c.62-.76 1.05-1.81.93-2.87-.9.04-2.01.6-2.65 1.35-.58.67-1.08 1.74-.94 2.78 1.01.08 2.04-.5 2.66-1.26z"/>
                    </svg>
                    <span>Apple ID</span>
                  </button>
                </div>

                {/* Method Selector Tabs: Email / Phone */}
                <div className="flex bg-stone-100 p-1 rounded-xl mb-5 border border-stone-200">
                  <button
                    type="button"
                    onClick={() => { setAuthMethod("email"); setError(null); }}
                    className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                      authMethod === "email"
                        ? "bg-white text-stone-900 shadow-xs border border-stone-200/80"
                        : "text-stone-500 hover:text-stone-900"
                    }`}
                  >
                    <Mail className="w-3.5 h-3.5" />
                    Email
                  </button>
                  <button
                    type="button"
                    onClick={() => { setAuthMethod("phone"); setError(null); }}
                    className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                      authMethod === "phone"
                        ? "bg-white text-stone-900 shadow-xs border border-stone-200/80"
                        : "text-stone-500 hover:text-stone-900"
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    Phone OTP
                  </button>
                </div>

                {/* PHONE AUTH SECTION */}
                {authMethod === "phone" ? (
                  <div className="space-y-4">
                    {!otpSent ? (
                      <form onSubmit={handleSendPhoneOtp} className="space-y-4">
                        <div>
                          <label className="block text-[11px] font-semibold text-stone-700 mb-1.5 tracking-wider uppercase">
                            Mobile Phone Number
                          </label>
                          <div className="relative group">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-400">
                              <Phone className="w-4 h-4" />
                            </div>
                            <input
                              type="tel"
                              required
                              value={phoneNumber}
                              onChange={(e) => setPhoneNumber(e.target.value)}
                              placeholder="+91 98765 43210"
                              className="w-full pl-10 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 text-sm focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all outline-none font-mono"
                            />
                          </div>
                          <p className="text-[10px] text-stone-400 mt-1">
                            Include country code (e.g., +91 for India, +1 for US)
                          </p>
                        </div>

                        <button
                          type="submit"
                          disabled={isLoading}
                          className="w-full py-3.5 px-4 bg-stone-900 hover:bg-black text-white rounded-xl font-medium text-xs transition-all flex items-center justify-center gap-2 shadow-md"
                        >
                          {isLoading ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <>
                              <span>Send Verification SMS</span>
                              <ArrowRight className="w-4 h-4" />
                            </>
                          )}
                        </button>
                      </form>
                    ) : (
                      <form onSubmit={handleVerifyPhoneOtp} className="space-y-4">
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <label className="block text-[11px] font-semibold text-stone-700 tracking-wider uppercase">
                              Enter 6-Digit Code
                            </label>
                            <button
                              type="button"
                              onClick={() => setOtpSent(false)}
                              className="text-[10px] text-amber-600 hover:underline"
                            >
                              Change Number
                            </button>
                          </div>
                          <input
                            type="text"
                            required
                            maxLength={6}
                            value={otp}
                            onChange={(e) => setOtp(e.target.value)}
                            placeholder="123456"
                            className="w-full text-center tracking-[0.5em] text-lg font-mono py-3 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all outline-none"
                            autoFocus
                          />
                        </div>

                        <button
                          type="submit"
                          disabled={isLoading}
                          className="w-full py-3.5 px-4 bg-stone-900 hover:bg-black text-white rounded-xl font-medium text-xs transition-all flex items-center justify-center gap-2 shadow-md"
                        >
                          {isLoading ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <span>Verify Code & Sign In</span>
                          )}
                        </button>
                      </form>
                    )}
                  </div>
                ) : (
                  /* EMAIL AUTH SECTION */
                  <div>
                    {/* Sign In vs Sign Up mode toggle */}
                    <div className="flex bg-stone-50 p-1 rounded-xl mb-4 border border-stone-200">
                      <button
                        type="button"
                        onClick={() => { setMode("signin"); setError(null); }}
                        className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                          mode === "signin"
                            ? "bg-stone-900 text-white shadow-xs"
                            : "text-stone-500 hover:text-stone-900"
                        }`}
                      >
                        Sign In
                      </button>
                      <button
                        type="button"
                        onClick={() => { setMode("signup"); setError(null); }}
                        className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                          mode === "signup"
                            ? "bg-stone-900 text-white shadow-xs"
                            : "text-stone-500 hover:text-stone-900"
                        }`}
                      >
                        Create Account
                      </button>
                    </div>

                    <form
                      onSubmit={mode === "signin" ? handleEmailSignIn : handleEmailSignUp}
                      className="space-y-3"
                    >
                      {mode === "signup" && (
                        <div>
                          <label className="block text-[11px] font-semibold text-stone-700 mb-1 tracking-wider uppercase">
                            Full Name
                          </label>
                          <div className="relative group">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-400">
                              <User className="h-4 w-4" />
                            </div>
                            <input
                              type="text"
                              required={mode === "signup"}
                              value={fullName}
                              onChange={(e) => setFullName(e.target.value)}
                              className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 text-sm focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all outline-none"
                              placeholder="John Doe"
                            />
                          </div>
                        </div>
                      )}

                      <div>
                        <label className="block text-[11px] font-semibold text-stone-700 mb-1 tracking-wider uppercase">
                          Email Address
                        </label>
                        <div className="relative group">
                          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-400">
                            <Mail className="h-4 w-4" />
                          </div>
                          <input
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 text-sm focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all outline-none"
                            placeholder="hello@example.com"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-stone-700 mb-1 tracking-wider uppercase">
                          Password
                        </label>
                        <div className="relative group">
                          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-400">
                            <Lock className="h-4 w-4" />
                          </div>
                          <input
                            type="password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 text-sm focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all outline-none"
                            placeholder="••••••••"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full py-3 px-4 bg-stone-900 hover:bg-black text-white rounded-xl font-medium transition-all duration-200 text-xs shadow-md mt-2 disabled:opacity-70"
                      >
                        {isLoading ? (
                          <Loader2 className="w-4 h-4 animate-spin mx-auto" />
                        ) : (
                          mode === "signin" ? "Sign In with Email" : "Create Account"
                        )}
                      </button>
                    </form>
                  </div>
                )}

                {/* Error Banner */}
                <AnimatePresence>
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="bg-red-50 border border-red-100 text-red-600 text-xs p-3 rounded-xl mt-3 flex items-start gap-2"
                    >
                      <span className="shrink-0 font-bold">!</span>
                      <span>{error}</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Security Footer */}
                <div className="mt-6 pt-4 border-t border-stone-100 flex items-center justify-center gap-2 text-[10px] uppercase tracking-widest text-stone-400 font-medium">
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  Encrypted & Secure Authentication
                </div>
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
