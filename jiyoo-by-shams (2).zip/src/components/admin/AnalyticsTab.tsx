import React, { useState, useEffect } from 'react';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Order } from '../../types';
import { format, subDays, isSameDay } from 'date-fns';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function AnalyticsTab() {
  const [data, setData] = useState<{ date: string; revenue: number }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const q = query(collection(db, 'orders'), orderBy('createdAt', 'asc'));
        const snap = await getDocs(q);
        
        const orders: Order[] = [];
        snap.forEach(doc => {
          orders.push({ id: doc.id, ...doc.data() } as Order);
        });

        // Generate last 7 days data
        const chartData = [];
        for (let i = 6; i >= 0; i--) {
          const date = subDays(new Date(), i);
          const dayOrders = orders.filter(o => 
            o.createdAt?.seconds && isSameDay(new Date(o.createdAt.seconds * 1000), date)
          );
          
          const revenue = dayOrders.reduce((sum, o) => sum + (o.amount || 0), 0);
          chartData.push({
            date: format(date, 'MMM dd'),
            revenue
          });
        }
        
        setData(chartData);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  if (loading) return <div className="p-8 text-brand-gray-500">Loading analytics...</div>;

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div>
        <h2 className="text-2xl font-bold text-brand-black">Analytics</h2>
        <p className="text-brand-gray-500">Revenue overview for the last 7 days.</p>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-gray-200 flex-1 min-h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
            <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: '#6B7280', fontSize: 12 }} dy={10} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: '#6B7280', fontSize: 12 }} dx={-10} tickFormatter={(val) => `₹${val}`} />
            <Tooltip 
              contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              formatter={(value: any) => [`₹${value}`, 'Revenue']}
            />
            <Area type="monotone" dataKey="revenue" stroke="#D97706" fill="#FEF3C7" strokeWidth={3} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
