import React, { useState, useEffect } from 'react';
import { collection, getDocs, doc, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { AuthUser } from '../../types';
import { Search } from 'lucide-react';

export function UsersTab() {
  const [users, setUsers] = useState<AuthUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    setLoading(true);
    try {
      const snap = await getDocs(collection(db, 'users'));
      const loaded: AuthUser[] = [];
      snap.forEach(doc => {
        loaded.push({ id: doc.id, ...doc.data() } as AuthUser);
      });
      setUsers(loaded);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  const updateRole = async (id: string, newRole: string) => {
    try {
      await updateDoc(doc(db, 'users', id), { role: newRole });
      setUsers(prev => prev.map(u => u.id === id ? { ...u, role: newRole } : u));
    } catch (err) {
      console.error("Error updating role", err);
      alert("Failed to update role");
    }
  };

  const filteredUsers = users.filter(u => 
    u.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-brand-black">Users</h2>
        <p className="text-brand-gray-500">Manage customer accounts and admin access.</p>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-brand-gray-200">
        <div className="relative max-w-md mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-gray-400" />
          <input 
            type="text"
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-brand-gray-50 border border-brand-gray-200 rounded-lg outline-none focus:border-emerald-600 text-sm"
          />
        </div>

        {loading ? (
          <div className="py-10 text-center text-brand-gray-500">Loading users...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-brand-gray-500 uppercase bg-brand-gray-50">
                <tr>
                  <th className="px-4 py-3 rounded-tl-lg">User</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3 rounded-tr-lg">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map(u => (
                  <tr key={u.id} className="border-b border-brand-gray-100 hover:bg-brand-gray-50 transition-colors">
                    <td className="px-4 py-3 flex items-center gap-3">
                      {u.picture ? (
                        <img src={u.picture} alt={u.name} className="w-8 h-8 rounded-full border border-brand-gray-200" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-brand-gray-200 flex items-center justify-center text-xs font-bold text-brand-gray-500">
                          {u.name?.slice(0, 2).toUpperCase() || 'U'}
                        </div>
                      )}
                      <span className="font-medium text-brand-black">{u.name}</span>
                    </td>
                    <td className="px-4 py-3 text-brand-gray-600">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        u.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-brand-gray-100 text-brand-gray-700'
                      }`}>
                        {u.role || 'user'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <select 
                        value={u.role || 'user'}
                        onChange={(e) => updateRole(u.id, e.target.value)}
                        className="bg-brand-gray-50 border border-brand-gray-200 text-brand-black text-xs rounded-lg focus:ring-emerald-600 focus:border-emerald-600 block w-full p-2"
                      >
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
