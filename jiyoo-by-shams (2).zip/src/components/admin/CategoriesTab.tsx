import React, { useState, useEffect } from 'react';
import { collection, getDocs, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Category } from '../../types';
import { Plus, Trash2 } from 'lucide-react';

export function CategoriesTab() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCatId, setNewCatId] = useState('');
  const [newCatLabel, setNewCatLabel] = useState('');

  useEffect(() => {
    loadCategories();
  }, []);

  async function loadCategories() {
    setLoading(true);
    try {
      const snap = await getDocs(collection(db, 'categories'));
      const loaded: Category[] = [];
      snap.forEach(doc => {
        loaded.push({ id: doc.id, ...doc.data() } as Category);
      });
      setCategories(loaded);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatId || !newCatLabel) return;
    try {
      const cat: Category = { id: newCatId.toLowerCase(), label: newCatLabel };
      await setDoc(doc(db, 'categories', cat.id), cat);
      setNewCatId('');
      setNewCatLabel('');
      loadCategories();
    } catch (err) {
      console.error(err);
      alert('Failed to add category');
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Delete category?')) {
      try {
        await deleteDoc(doc(db, 'categories', id));
        loadCategories();
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-brand-black">Categories</h2>
        <p className="text-brand-gray-500">Manage product categories.</p>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-gray-200">
        <form onSubmit={handleAdd} className="flex gap-4 items-end mb-8">
          <div className="flex-1">
            <label className="block text-sm font-medium text-brand-gray-700 mb-1">Category ID (e.g., chicken)</label>
            <input 
              required type="text" value={newCatId} onChange={e => setNewCatId(e.target.value)}
              className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-brand-gray-700 mb-1">Display Label (e.g., Chicken)</label>
            <input 
              required type="text" value={newCatLabel} onChange={e => setNewCatLabel(e.target.value)}
              className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
            />
          </div>
          <button type="submit" className="bg-brand-black text-white px-4 py-2 rounded-lg font-medium hover:bg-brand-gray-900 transition-colors flex items-center gap-2 h-[38px]">
            <Plus className="w-4 h-4" /> Add
          </button>
        </form>

        {loading ? (
          <div className="text-center text-brand-gray-500">Loading...</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {categories.map(c => (
              <div key={c.id} className="border border-brand-gray-200 rounded-lg p-4 flex justify-between items-center bg-brand-gray-50">
                <div>
                  <h4 className="font-bold text-brand-black">{c.label}</h4>
                  <p className="text-xs text-brand-gray-500">ID: {c.id}</p>
                </div>
                <button onClick={() => handleDelete(c.id)} className="text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
