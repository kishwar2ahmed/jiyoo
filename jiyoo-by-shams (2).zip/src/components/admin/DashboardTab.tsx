import React, { useState, useEffect } from 'react';
import { collection, getDocs, query, where, orderBy, limit } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Order, AuthUser, Product } from '../../types';
import { Users, ShoppingBag, DollarSign, Package } from 'lucide-react';

export function DashboardTab() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalOrders: 0,
    totalRevenue: 0,
    totalProducts: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      try {
        const usersSnap = await getDocs(collection(db, 'users'));
        const ordersSnap = await getDocs(collection(db, 'orders'));
        const productsSnap = await getDocs(collection(db, 'products'));

        let revenue = 0;
        ordersSnap.forEach(doc => {
          const order = doc.data() as Order;
          revenue += order.amount || 0;
        });

        setStats({
          totalUsers: usersSnap.size,
          totalOrders: ordersSnap.size,
          totalRevenue: revenue,
          totalProducts: productsSnap.size,
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadStats();
  }, []);

  if (loading) return <div>Loading dashboard...</div>;

  const statCards = [
    { label: 'Total Revenue', value: `₹${stats.totalRevenue.toLocaleString()}`, icon: DollarSign, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Total Orders', value: stats.totalOrders.toString(), icon: ShoppingBag, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Total Users', value: stats.totalUsers.toString(), icon: Users, color: 'text-emerald-600', bg: 'bg-emerald-100' },
    { label: 'Products', value: stats.totalProducts.toString(), icon: Package, color: 'text-purple-600', bg: 'bg-purple-100' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-brand-black">Dashboard Overview</h2>
        <p className="text-brand-gray-500">Welcome to your store's control center.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map(stat => (
          <div key={stat.label} className="bg-white p-6 rounded-2xl shadow-sm border border-brand-gray-200 flex items-center gap-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${stat.bg} ${stat.color}`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-brand-gray-500">{stat.label}</p>
              <p className="text-2xl font-bold text-brand-black">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Could add recent orders table here */}
    </div>
  );
}
