import React, { useState } from 'react';
import { Save } from 'lucide-react';

export function SettingsTab() {
  const [storeName, setStoreName] = useState('JIYOO Fresh Meats');
  const [contactEmail, setContactEmail] = useState('support@jiyoo.com');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      localStorage.setItem('jiyoo_store_name', storeName);
      localStorage.setItem('jiyoo_contact_email', contactEmail);
    } catch (err) {
      console.warn("Could not save settings to localStorage", err);
    }
    setTimeout(() => {
      setIsSaving(false);
      alert('Store settings saved successfully.');
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-brand-black">Settings</h2>
        <p className="text-brand-gray-500">Manage global store configuration.</p>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-gray-200 max-w-2xl">
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-brand-gray-700 mb-1">Store Name</label>
            <input 
              type="text" value={storeName} onChange={e => setStoreName(e.target.value)}
              className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-brand-gray-700 mb-1">Contact Email</label>
            <input 
              type="email" value={contactEmail} onChange={e => setContactEmail(e.target.value)}
              className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
            />
          </div>
          
          <div className="pt-4 border-t border-brand-gray-100">
            <button disabled={isSaving} type="submit" className="bg-brand-black text-white px-4 py-2 rounded-lg font-medium hover:bg-brand-gray-900 transition-colors flex items-center gap-2">
              <Save className="w-4 h-4" /> {isSaving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
