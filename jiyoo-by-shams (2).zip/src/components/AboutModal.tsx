import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AboutModal({ isOpen, onClose }: AboutModalProps) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-brand-black/60 backdrop-blur-sm"
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-3xl bg-brand-white rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-brand-gray-200">
            <h2 className="text-2xl font-serif font-bold text-brand-black">About Us</h2>
            <button
              onClick={onClose}
              className="p-2 text-brand-gray-500 hover:text-brand-black transition-colors rounded-full hover:bg-brand-gray-100"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="p-6 sm:p-8 overflow-y-auto custom-scrollbar flex-1 space-y-8">
            
            {/* Intro */}
            <section>
              <p className="text-brand-gray-600 leading-relaxed text-sm sm:text-base">
                <strong className="text-brand-black">JIYOO (jiyoooshams)</strong> is an emerging online service provider connecting businesses and consumers with the finest fresh fruits, vegetables, and other premium produce, sourced through a strong network of farmers, importers, and distributors both locally and internationally.
              </p>
              <p className="text-brand-gray-600 leading-relaxed text-sm sm:text-base mt-4">
                Our objective is to build an efficient and robust online & offline platform that showcases our strengths in quality, express service, and value for money. We specialize in exotic and imported fresh produce, while continuously expanding beyond fruits to offer a wider range of healthy food products.
              </p>
              <p className="text-brand-gray-600 leading-relaxed text-sm sm:text-base mt-4">
                Our vision is to consistently deliver premium quality with a wide assortment of healthy foods while enhancing customer experience through customized solutions and a pay-per-demand model.
              </p>
              <p className="text-brand-gray-600 leading-relaxed text-sm sm:text-base mt-4">
                With an experienced team serving hotels, retail stores, restaurants, general trade, and end-users, we are committed to maintaining the highest standards of hygiene, safety, and customer satisfaction in everything we do.
              </p>
            </section>

            {/* Leadership & Contact */}
            <div className="grid sm:grid-cols-2 gap-8 border-t border-brand-gray-200 pt-8">
              <div>
                <h3 className="text-lg font-bold text-brand-black mb-4">Leadership</h3>
                <div className="space-y-4">
                  <div>
                    <p className="font-medium text-brand-black">Syed Shams</p>
                    <p className="text-xs text-brand-gray-500 uppercase tracking-wider">Founder, CEO & CFO</p>
                  </div>
                  <div>
                    <p className="font-medium text-brand-black">Dr. Mehraj Sultana</p>
                    <p className="text-xs text-brand-gray-500 uppercase tracking-wider">Managing Director (MD)</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold text-brand-black mb-2">Marketed By</h3>
                  <p className="text-brand-gray-600 font-medium">SHAM'S™</p>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-brand-black mb-2">Contact</h3>
                  <p className="text-brand-gray-600 font-medium text-lg">+91 97393 91891</p>
                </div>
              </div>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
