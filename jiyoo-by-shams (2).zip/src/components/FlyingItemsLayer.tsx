import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCart, FlyingItem } from '../CartContext';

export function FlyingItemsLayer() {
  const { flyingItems, removeFlyingItem } = useCart();
  const [cartPos, setCartPos] = useState({ x: window.innerWidth - 40, y: 40 });

  useEffect(() => {
    // Update cart position
    const updateCartPos = () => {
      const cartIcon = document.getElementById('cart-icon-button');
      if (cartIcon) {
        const rect = cartIcon.getBoundingClientRect();
        setCartPos({
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2,
        });
      }
    };
    updateCartPos();
    window.addEventListener('resize', updateCartPos);
    return () => window.removeEventListener('resize', updateCartPos);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
      <AnimatePresence>
        {flyingItems.map(item => (
          <motion.div
            key={item.id}
            initial={{ 
              x: item.startX, 
              y: item.startY, 
              scale: 1.2,
              opacity: 1,
              rotate: 0
            }}
            animate={{ 
              x: cartPos.x, 
              y: cartPos.y, 
              scale: 0.1,
              opacity: 0.2,
              rotate: 360
            }}
            exit={{ opacity: 0, scale: 0 }}
            transition={{ 
              x: { type: "tween", ease: "linear", duration: 0.7 },
              y: { type: "tween", ease: "easeIn", duration: 0.7 },
              scale: { type: "tween", ease: "easeInOut", duration: 0.7 },
              opacity: { duration: 0.7, ease: "easeIn" },
              rotate: { duration: 0.7, ease: "linear" }
            }}
            onAnimationComplete={() => removeFlyingItem(item.id)}
            className="absolute top-0 left-0 -ml-8 -mt-8 w-16 h-16 rounded-lg overflow-hidden shadow-2xl bg-brand-white border-2 border-brand-white"
          >
            {item.image.endsWith('.mp4') ? (
              <video 
                src={item.image} 
                autoPlay 
                loop 
                muted 
                playsInline 
                // @ts-ignore
                webkit-playsinline="true"
                className="w-full h-full object-cover"
              />
            ) : (
              <img 
                src={item.image} 
                alt="Flying product" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/logo.jpg';
                }}
              />
            )}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
