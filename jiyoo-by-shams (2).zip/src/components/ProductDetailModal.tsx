import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, ShoppingBag, X, Minus, Plus, ShieldCheck, Clock, Check } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../CartContext';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  wishlist: string[];
  toggleWishlist: (id: string) => void;
}

export function ProductDetailModal({ product, isOpen, onClose, wishlist, toggleWishlist }: ProductDetailModalProps) {
  const { addToCart, triggerFlyingItem } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedWeight, setSelectedWeight] = useState(product?.weights?.[0]);
  const [selectedCut, setSelectedCut] = useState(product?.fishCuts?.[0]);
  const [selectedCleaning, setSelectedCleaning] = useState(product?.cleaningOptions?.[0]);

  // Sync state when product changes
  useEffect(() => {
    if (product) {
      setQuantity(1);
      setSelectedWeight(product.weights?.[0]);
      setSelectedCut(product.fishCuts?.[0]);
      setSelectedCleaning(product.cleaningOptions?.[0]);
    }
  }, [product]);

  if (!product) return null;

  const isMeat = product.categoryId === 'meat';
  const currentPrice = selectedWeight ? selectedWeight.price : product.price;
  const currentUnit = selectedWeight ? selectedWeight.label : product.unit;

  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  const handleIncrease = () => {
    setQuantity(prev => prev + 1);
  };

  const handleAddToCart = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    triggerFlyingItem({
      image: product.image,
      startX: rect.left + rect.width / 2,
      startY: rect.top + rect.height / 2,
    });

    let itemName = product.name;
    if (selectedCut) itemName += ` - ${selectedCut}`;
    if (selectedCleaning) itemName += ` (${selectedCleaning})`;

    addToCart({
      id: `${product.id}-${currentUnit}-${selectedCut || ''}-${selectedCleaning || ''}`,
      name: itemName,
      price: `₹${currentPrice}`,
      numericPrice: currentPrice,
      image: product.image,
      badge: currentUnit
    }, quantity);

    // Optionally close the modal or keep it open with visual confirmation
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10">
          {/* Backdrop blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-brand-black/40 backdrop-blur-md"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', damping: 30, stiffness: 350 }}
            className="relative bg-brand-white w-full max-w-4xl max-h-[90vh] supports-[height:100dvh]:max-h-[90dvh] md:max-h-[85vh] rounded-[32px] shadow-2xl overflow-y-auto overflow-x-hidden border border-brand-gray-100 flex flex-col md:flex-row z-10"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-6 right-6 z-30 w-10 h-10 bg-brand-white/80 backdrop-blur-md hover:bg-brand-white text-brand-black rounded-full flex items-center justify-center shadow-md transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Left Column: Premium Image Area */}
            <div className="relative w-full md:w-1/2 aspect-[4/3] md:aspect-auto md:min-h-[500px] bg-brand-gray-50 flex items-center justify-center overflow-hidden">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
                loading="eager"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/logo.jpg';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-black/35 via-transparent to-transparent pointer-events-none" />

              {/* Freshness Badge overlay */}
              {product.freshnessBadge && (
                <div className="absolute bottom-6 left-6 z-20">
                  <span className="inline-flex items-center gap-1.5 bg-brand-white/95 backdrop-blur-md text-brand-black px-3.5 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider shadow-lg">
                    <ShieldCheck className="w-4 h-4 text-green-500" />
                    {product.freshnessBadge}
                  </span>
                </div>
              )}
            </div>

            {/* Right Column: Detailed Info Form */}
            <div className="w-full md:w-1/2 p-6 sm:p-8 md:p-10 flex flex-col justify-between">
              <div>
                {/* Breadcrumbs */}
                <div className="flex items-center gap-2 text-xs text-brand-gray-400 uppercase tracking-widest font-semibold mb-3">
                  <span>{product.categoryId}</span>
                  {product.subcategoryId && (
                    <>
                      <span>/</span>
                      <span>{product.subcategoryId.replace('-', ' ')}</span>
                    </>
                  )}
                  {product.subSubcategoryId && (
                    <>
                      <span>/</span>
                      <span className="text-brand-black">{product.subSubcategoryId.replace('-', ' ')}</span>
                    </>
                  )}
                </div>

                {/* Product Name */}
                <h1 className="text-2xl sm:text-3xl font-semibold text-brand-black tracking-tight mb-2 leading-tight">
                  {product.name}
                </h1>

                {/* Subtext info */}
                <div className="flex items-center gap-3 text-sm text-brand-gray-500 mb-6">
                  {product.origin && (
                    <span className="bg-brand-gray-50 px-2.5 py-1 rounded-lg">Origin: {product.origin}</span>
                  )}
                  {isMeat && product.cutType && (
                    <span className="bg-brand-gray-50 px-2.5 py-1 rounded-lg">Cut: {product.cutType}</span>
                  )}
                  <span className="inline-flex items-center gap-1 text-green-600 font-semibold text-xs uppercase tracking-wider">
                    <Check className="w-3.5 h-3.5" /> In Stock
                  </span>
                </div>

                {/* Short Description */}
                {product.description && (
                  <p className="text-sm sm:text-base text-brand-gray-500 leading-relaxed mb-6 font-light">
                    {product.description}
                  </p>
                )}

                {/* Option Selectors */}
                <div className="space-y-5 mb-8">
                  {/* Weight Selector */}
                  {product.weights && product.weights.length > 0 && (
                    <div>
                      <h4 className="text-xs uppercase tracking-wider text-brand-gray-400 font-bold mb-2.5">Select Weight</h4>
                      <div className="flex flex-wrap gap-2">
                        {product.weights.map((w) => (
                          <button
                            key={w.label}
                            onClick={() => setSelectedWeight(w)}
                            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-300 ${
                              selectedWeight?.label === w.label
                                ? 'bg-brand-black text-brand-white shadow-md scale-[1.02]'
                                : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100 border border-transparent'
                            }`}
                          >
                            {w.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Fish Cuts Selector */}
                  {product.fishCuts && product.fishCuts.length > 0 && (
                    <div>
                      <h4 className="text-xs uppercase tracking-wider text-brand-gray-400 font-bold mb-2.5">Fish Cut Style</h4>
                      <div className="flex flex-wrap gap-2">
                        {product.fishCuts.map((c) => (
                          <button
                            key={c}
                            onClick={() => setSelectedCut(c)}
                            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-300 ${
                              selectedCut === c
                                ? 'bg-brand-black text-brand-white shadow-md scale-[1.02]'
                                : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100'
                            }`}
                          >
                            {c}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Cleaning Options Selector */}
                  {product.cleaningOptions && product.cleaningOptions.length > 0 && (
                    <div>
                      <h4 className="text-xs uppercase tracking-wider text-brand-gray-400 font-bold mb-2.5">Preparation</h4>
                      <div className="flex flex-wrap gap-2">
                        {product.cleaningOptions.map((c) => (
                          <button
                            key={c}
                            onClick={() => setSelectedCleaning(c)}
                            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-300 ${
                              selectedCleaning === c
                                ? 'bg-brand-black text-brand-white shadow-md scale-[1.02]'
                                : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100'
                            }`}
                          >
                            {c}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Interactive Purchase Row */}
              <div className="pt-6 border-t border-brand-gray-100 space-y-4">
                <div className="flex items-center justify-between">
                  {/* Delivery Info */}
                  <div className="flex items-center gap-1.5 text-xs text-brand-gray-400 font-semibold uppercase tracking-wider">
                    <Clock className="w-4 h-4 text-brand-gray-400" />
                    Delivery: {product.deliveryEstimate || '60 mins'}
                  </div>

                  {/* Price display */}
                  <div className="text-right">
                    <span className="text-[10px] uppercase tracking-wider text-brand-gray-400 font-semibold block">Total Price</span>
                    <div className="flex items-baseline justify-end gap-2 mt-0.5">
                      <span className="text-2xl sm:text-3xl font-bold text-brand-black tracking-tight">
                        ₹{currentPrice * quantity}
                      </span>
                      {product.discount && (
                        <span className="text-sm text-brand-gray-400 line-through">
                          ₹{Math.round((currentPrice * quantity) / (1 - product.discount / 100))}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  {/* Quantity Selector */}
                  <div className="bg-brand-gray-50/80 p-1 rounded-2xl flex items-center border border-brand-gray-100 h-[52px]">
                    <button
                      onClick={handleDecrease}
                      disabled={quantity <= 1}
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-brand-black hover:bg-brand-white disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-10 text-center font-semibold text-brand-black text-sm">{quantity}</span>
                    <button
                      onClick={handleIncrease}
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-brand-black hover:bg-brand-white transition-all"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Wishlist Icon */}
                  <button
                    onClick={() => toggleWishlist(product.id)}
                    className="w-[52px] h-[52px] bg-brand-gray-50/80 border border-brand-gray-100 hover:bg-brand-gray-100 rounded-2xl flex items-center justify-center text-brand-black transition-all shrink-0 active:scale-95"
                  >
                    <Heart
                      className="w-5 h-5 transition-transform active:scale-125"
                      fill={wishlist.includes(product.id) ? '#EF4444' : 'none'}
                      stroke={wishlist.includes(product.id) ? '#EF4444' : 'currentColor'}
                    />
                  </button>

                  {/* Add to Bag CTA */}
                  <button
                    onClick={handleAddToCart}
                    className="flex-1 h-[52px] bg-brand-black text-brand-white rounded-2xl font-semibold text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-brand-gray-900 shadow-lg hover:shadow-xl transition-all duration-300 active:scale-95"
                  >
                    <ShoppingBag className="w-5 h-5" /> Add to Bag
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
