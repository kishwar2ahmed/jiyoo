export type SubSubcategory = { id: string; label: string };
export type Subcategory = { id: string; label: string; items?: SubSubcategory[] };
export type Category = { id: string; label: string; items?: Subcategory[] };

export interface ProductWeight {
  label: string;
  price: number;
  stock?: number;
}

export interface Product {
  id: string;
  name: string;
  description?: string;
  price: number;
  stock?: number;
  unit: string;
  categoryId: string;
  subcategoryId?: string;
  subSubcategoryId?: string;
  image: string;
  tags: string[];
  cutType?: string;
  freshnessBadge?: string;
  deliveryEstimate?: string;
  discount?: number;
  origin?: string;
  weights?: ProductWeight[];
  cleaningOptions?: string[];
  fishCuts?: string[];
}

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  picture?: string;
  role?: string;
}

export interface CartProduct {
  id: string;
  name: string;
  price: string;
  numericPrice: number;
  image: string;
  badge?: string;
}

export interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  stock?: number;
  image: string;
}

export interface Order {
  id: string;
  userId: string;
  amount: number;
  status: string;
  items: OrderItem[];
  shippingDetails?: {
    name: string;
    phone: string;
    address: string;
  };
  razorpayPaymentId?: string;
  razorpayOrderId?: string;
  createdAt?: any;
}
