import { Category, Product } from './types';

export const CATEGORIES: Category[] = [
  {
    id: 'fruits',
    label: 'Fruits',
    items: [
      { id: 'imported-fruits', label: 'Imported Fruits' },
      { id: 'indian-fruits', label: 'Indian Fruits' }
    ]
  },
  {
    id: 'vegetables',
    label: 'Vegetables',
    items: [
      { id: 'thai-vegetables', label: 'Thai Vegetables' },
      { id: 'indian-vegetables', label: 'Indian Vegetables' }
    ]
  },
  {
    id: 'meat',
    label: 'Meat',
    items: [
      { 
        id: 'chicken', 
        label: 'Chicken',
        items: [
          { id: 'boneless-cut', label: 'Boneless Cut' },
          { id: 'bone-cut', label: 'Bone Cut' },
          { id: 'curry-cut', label: 'Curry Cut' },
          { id: 'biryani-cut', label: 'Biryani Cut' },
          { id: 'kabab-cut', label: 'Kabab Cut' }
        ]
      },
      { 
        id: 'mutton', 
        label: 'Mutton',
        items: [
          { id: 'boneless-cut', label: 'Boneless Cut' },
          { id: 'bone-cut', label: 'Bone Cut' },
          { id: 'curry-cut', label: 'Curry Cut' },
          { id: 'biryani-cut', label: 'Biryani Cut' },
          { id: 'kabab-cut', label: 'Kabab Cut' }
        ]
      },
      { 
        id: 'fish', 
        label: 'Fish',
        items: [
          { id: 'rohu', label: 'Rohu' },
          { id: 'katla', label: 'Katla' },
          { id: 'pomfret', label: 'Pomfret' },
          { id: 'surmai', label: 'Surmai' }
        ]
      },
      { id: 'prawns', label: 'Prawns' }
    ]
  },
  {
    id: 'smoothies',
    label: 'Smoothies'
  }
];

export const PRODUCTS: Product[] = [
  // =========================================================
  // FRUITS
  // =========================================================
  // Imported Fruits
  {
    id: 'f_gala_apple',
    name: 'Gala Apple',
    description: 'Crisp, sweet, and highly aromatic Gala apples imported from premium global orchards.',
    price: 299,
    unit: '4 pcs',
    categoryId: 'fruits',
    subcategoryId: 'imported-fruits',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6faa6?auto=format&fit=crop&q=80&w=600',
    tags: ['Imported', 'Crisp'],
    freshnessBadge: 'Premium',
    deliveryEstimate: '60 mins',
    discount: 10,
    weights: [
      { label: '4 pcs', price: 299 },
      { label: '8 pcs', price: 549 }
    ]
  },
  {
    id: 'f_washington_apple',
    name: 'Washington Apple',
    description: 'Classic deep-red Washington apples with a firm texture and exceptionally sweet flavor.',
    price: 349,
    unit: '4 pcs',
    categoryId: 'fruits',
    subcategoryId: 'imported-fruits',
    image: 'https://images.unsplash.com/photo-1619546813926-a78fa6372cd2?auto=format&fit=crop&q=80&w=600',
    tags: ['Imported', 'Sweet'],
    freshnessBadge: 'Premium',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '4 pcs', price: 349 },
      { label: '8 pcs', price: 649 }
    ]
  },
  {
    id: 'f_citrus_orange',
    name: 'Citrus Orange',
    description: 'Juicy, vibrant citrus oranges packed with fresh, tangy vitamin C goodness.',
    price: 199,
    unit: '1kg',
    categoryId: 'fruits',
    subcategoryId: 'imported-fruits',
    image: 'https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&q=80&w=600',
    tags: ['Imported', 'Juicy'],
    freshnessBadge: 'Fresh Catch',
    deliveryEstimate: '60 mins',
    discount: 15,
    weights: [
      { label: '1kg', price: 199 },
      { label: '2kg', price: 369 }
    ]
  },
  {
    id: 'f_mandarin_orange',
    name: 'Mandarin Orange',
    description: 'Sweet, easy-to-peel Mandarin oranges with a burst of bright, refreshing citrus flavor.',
    price: 249,
    unit: '6 pcs',
    categoryId: 'fruits',
    subcategoryId: 'imported-fruits',
    image: 'https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&q=80&w=600',
    tags: ['Imported', 'Sweet'],
    freshnessBadge: 'Daily Pick',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '6 pcs', price: 249 },
      { label: '12 pcs', price: 469 }
    ]
  },
  {
    id: 'f_avocado',
    name: 'Avocado',
    description: 'Rich, buttery imported Hass avocados, handpicked for perfect creamy ripeness.',
    price: 399,
    unit: '2 pcs',
    categoryId: 'fruits',
    subcategoryId: 'imported-fruits',
    image: 'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&q=80&w=600',
    tags: ['Imported', 'Creamy'],
    freshnessBadge: 'Top Tier',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '2 pcs', price: 399 },
      { label: '4 pcs', price: 749 }
    ]
  },
  {
    id: 'f_dragon_fruit',
    name: 'Dragon Fruit (Red)',
    description: 'Exotic red-fleshed dragon fruit with a delicate, subtly sweet taste and stunning color.',
    price: 279,
    unit: '2 pcs',
    categoryId: 'fruits',
    subcategoryId: 'imported-fruits',
    image: 'https://images.unsplash.com/photo-1527324688151-0e627063f2b1?auto=format&fit=crop&q=80&w=600',
    tags: ['Exotic', 'Sweet'],
    freshnessBadge: 'Premium',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '2 pcs', price: 279 },
      { label: '4 pcs', price: 529 }
    ]
  },
  {
    id: 'f_ice_guava',
    name: 'Ice Guava',
    description: 'Rare, crisp, and refreshing imported Ice Guavas with a delightfully clean sweet finish.',
    price: 329,
    unit: '500g',
    categoryId: 'fruits',
    subcategoryId: 'imported-fruits',
    image: 'https://images.unsplash.com/photo-1534482421-64566f976cfa?auto=format&fit=crop&q=80&w=600',
    tags: ['Imported', 'Crisp'],
    freshnessBadge: 'Rare Find',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '500g', price: 329 },
      { label: '1kg', price: 599 }
    ]
  },

  // Indian Fruits
  {
    id: 'f_shimla_apple',
    name: 'Shimla Apple',
    description: 'Sweet, traditional Indian apples handpicked from the high-altitude orchards of Shimla.',
    price: 189,
    unit: '4 pcs',
    categoryId: 'fruits',
    subcategoryId: 'indian-fruits',
    image: 'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Sweet'],
    freshnessBadge: 'Local Farm',
    deliveryEstimate: '60 mins',
    discount: 5,
    weights: [
      { label: '4 pcs', price: 189 },
      { label: '8 pcs', price: 349 }
    ]
  },
  {
    id: 'f_pomegranate',
    name: 'Pomegranate',
    description: 'Plump Indian pomegranates filled with deep red, juicy, and sweet arils.',
    price: 219,
    unit: '3 pcs',
    categoryId: 'fruits',
    subcategoryId: 'indian-fruits',
    image: 'https://images.unsplash.com/photo-1615486171448-4df2b028dfac?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Antioxidant'],
    freshnessBadge: 'Super Fresh',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '3 pcs', price: 219 },
      { label: '6 pcs', price: 399 }
    ]
  },
  {
    id: 'f_banana',
    name: 'Banana',
    description: 'Naturally sweet and perfectly ripe Robusta bananas from the fertile plantations of South India.',
    price: 79,
    unit: '1 Dozen',
    categoryId: 'fruits',
    subcategoryId: 'indian-fruits',
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Nutritious'],
    freshnessBadge: 'Daily Pick',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '1 Dozen', price: 79 },
      { label: '2 Dozen', price: 149 }
    ]
  },
  {
    id: 'f_papaya',
    name: 'Papaya',
    description: 'Sweet, tree-ripened Indian papaya with rich orange flesh, high in natural digestive enzymes.',
    price: 129,
    unit: '1 pc',
    categoryId: 'fruits',
    subcategoryId: 'indian-fruits',
    image: 'https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Digestive'],
    freshnessBadge: 'Naturally Ripe',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '1 pc (approx 1kg)', price: 129 },
      { label: '2 pcs (approx 2kg)', price: 239 }
    ]
  },

  // =========================================================
  // VEGETABLES
  // =========================================================
  // Thai Vegetables
  {
    id: 'v_green_asparagus',
    name: 'Green Asparagus',
    description: 'Tender, fresh green asparagus spears imported from top-tier agricultural fields in Thailand.',
    price: 249,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: 'https://images.unsplash.com/photo-1464195244916-405fa0a82545?auto=format&fit=crop&q=80&w=600',
    tags: ['Thai', 'Exotic'],
    freshnessBadge: 'Freshly Imported',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '250g', price: 249 },
      { label: '500g', price: 469 }
    ]
  },
  {
    id: 'v_white_asparagus',
    name: 'White Asparagus',
    description: 'Highly sought-after white asparagus with a delicate, mild flavor and extremely tender spears.',
    price: 349,
    unit: '250g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&q=80&w=600',
    tags: ['Thai', 'Gourmet'],
    freshnessBadge: 'Ultra Rare',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '250g', price: 349 },
      { label: '500g', price: 659 }
    ]
  },
  {
    id: 'v_artichoke',
    name: 'Artichoke',
    description: 'Premium fresh Thai artichokes, prized for their tender hearts and rich culinary versatility.',
    price: 299,
    unit: '2 pcs',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: 'https://images.unsplash.com/photo-1508747703725-7197771375a0?auto=format&fit=crop&q=80&w=600',
    tags: ['Thai', 'Versatile'],
    freshnessBadge: 'Premium',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '2 pcs', price: 299 },
      { label: '4 pcs', price: 549 }
    ]
  },
  {
    id: 'v_mini_lettuce',
    name: 'Mini Lettuce',
    description: 'Crisp, sweet, and compact mini butterhead lettuce, hydroponically grown and freshly harvested.',
    price: 149,
    unit: '2 pcs',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: 'https://images.unsplash.com/photo-1556801712-76c8eb07bbc9?auto=format&fit=crop&q=80&w=600',
    tags: ['Thai', 'Hydroponic'],
    freshnessBadge: 'Clean Greens',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '2 pcs', price: 149 },
      { label: '4 pcs', price: 279 }
    ]
  },
  {
    id: 'v_garlic_chives',
    name: 'Garlic Chives',
    description: 'Fragrant Thai garlic chives with a mild garlic-onion aroma, essential for Asian stir-fries.',
    price: 99,
    unit: '100g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: 'https://images.unsplash.com/photo-1606787366850-de6330128bfc?auto=format&fit=crop&q=80&w=600',
    tags: ['Thai', 'Fragrant'],
    freshnessBadge: 'Fresh Cut',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '100g', price: 99 },
      { label: '250g', price: 219 }
    ]
  },
  {
    id: 'v_parsley',
    name: 'Parsley',
    description: 'Bright green, aromatic curly parsley, freshly cut to retain its essential oils and herbal notes.',
    price: 79,
    unit: '100g',
    categoryId: 'vegetables',
    subcategoryId: 'thai-vegetables',
    image: 'https://images.unsplash.com/photo-1515471204800-9240d5e62e12?auto=format&fit=crop&q=80&w=600',
    tags: ['Thai', 'Herb'],
    freshnessBadge: 'Daily Pick',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '100g', price: 79 },
      { label: '250g', price: 179 }
    ]
  },

  // Indian Vegetables
  {
    id: 'v_onion',
    name: 'Onion',
    description: 'Fresh, pungent, and indispensable Indian pink onions sourced straight from Nashik farms.',
    price: 49,
    unit: '1kg',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Pungent'],
    freshnessBadge: 'Farm Direct',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '1kg', price: 49 },
      { label: '2kg', price: 89 },
      { label: '5kg', price: 219 }
    ]
  },
  {
    id: 'v_potato',
    name: 'Potato',
    description: 'Premium-quality Indian Jyoti potatoes, perfect for mashing, baking, or crispy frying.',
    price: 39,
    unit: '1kg',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Starch'],
    freshnessBadge: 'Freshly Dug',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '1kg', price: 39 },
      { label: '2kg', price: 69 },
      { label: '5kg', price: 159 }
    ]
  },
  {
    id: 'v_tomato',
    name: 'Tomato',
    description: 'Vine-ripened, juicy red Indian tomatoes, rich in flavor and lycopene.',
    price: 59,
    unit: '1kg',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Juicy'],
    freshnessBadge: 'Vine Ripe',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '1kg', price: 59 },
      { label: '2kg', price: 109 }
    ]
  },
  {
    id: 'v_radish',
    name: 'Radish',
    description: 'Crisp, spicy-pungent white radishes (Mooli) harvested fresh from local organic fields.',
    price: 45,
    unit: '500g',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://images.unsplash.com/photo-1590005354167-6da97870c913?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Crisp'],
    freshnessBadge: 'Organic',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '500g', price: 45 },
      { label: '1kg', price: 79 }
    ]
  },
  {
    id: 'v_broccoli',
    name: 'Broccoli',
    description: 'Fresh, nutrient-dense green broccoli crowns, grown locally using sustainable organic methods.',
    price: 119,
    unit: '1 pc',
    categoryId: 'vegetables',
    subcategoryId: 'indian-vegetables',
    image: 'https://images.unsplash.com/photo-1534080564583-6be75777b70a?auto=format&fit=crop&q=80&w=600',
    tags: ['Indian', 'Organic'],
    freshnessBadge: 'Nutrient Rich',
    deliveryEstimate: '60 mins',
    weights: [
      { label: '1 pc (approx 350g)', price: 119 },
      { label: '2 pcs', price: 219 }
    ]
  },

  // =========================================================
  // MEAT - CHICKEN
  // =========================================================
  {
    id: 'm_ch_boneless',
    name: 'Premium Chicken Breast (Boneless Cut)',
    description: 'Succulent, 100% lean boneless chicken breast fillets. Perfect for healthy grills, gym prep, and salads.',
    price: 329,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'boneless-cut',
    image: 'https://images.unsplash.com/photo-1604503468506-a8da13d82791?auto=format&fit=crop&q=80&w=600',
    tags: ['Lean', 'Antibiotic Free'],
    cutType: 'Boneless Cut',
    freshnessBadge: 'Farm Fresh',
    deliveryEstimate: '90 mins',
    discount: 10,
    weights: [
      { label: '250g', price: 179 },
      { label: '500g', price: 329 },
      { label: '1kg', price: 599 }
    ]
  },
  {
    id: 'm_ch_bone',
    name: 'Tender Chicken Thigh (Bone Cut)',
    description: 'Juicy, bone-in chicken thigh pieces, perfect for absorbing deep slow-cooked spice flavors.',
    price: 249,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'bone-cut',
    image: 'https://images.unsplash.com/photo-1598514982205-f36b96d1e8d4?auto=format&fit=crop&q=80&w=600',
    tags: ['Bone-In', 'Juicy'],
    cutType: 'Bone Cut',
    freshnessBadge: 'Daily Fresh',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g', price: 249 },
      { label: '1kg', price: 459 }
    ]
  },
  {
    id: 'm_ch_curry',
    name: 'Farm-Fresh Chicken Curry Cut',
    description: 'Skinless, bone-in chicken pieces cut perfectly for traditional rich and savory Indian curries.',
    price: 239,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'curry-cut',
    image: 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?auto=format&fit=crop&q=80&w=600',
    tags: ['Curry Cut', 'Farm Fresh'],
    cutType: 'Curry Cut',
    freshnessBadge: 'Daily Fresh',
    deliveryEstimate: '90 mins',
    discount: 15,
    weights: [
      { label: '500g', price: 239 },
      { label: '1kg', price: 449 }
    ]
  },
  {
    id: 'm_ch_biryani',
    name: 'Classic Chicken Biryani Cut',
    description: 'Generously sized, juicy chicken pieces on the bone, crafted specifically for the ultimate dum biryani experience.',
    price: 269,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'biryani-cut',
    image: 'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&q=80&w=600',
    tags: ['Biryani Cut', 'Biryani Special'],
    cutType: 'Biryani Cut',
    freshnessBadge: 'Specialty Cut',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g', price: 269 },
      { label: '1kg', price: 499 }
    ]
  },
  {
    id: 'm_ch_kabab',
    name: 'Gourmet Chicken Kabab Cut',
    description: 'Perfectly sized, succulent chunks of chicken breast and thigh, pre-cut and ready for your skewering and grill creations.',
    price: 289,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'chicken',
    subSubcategoryId: 'kabab-cut',
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&q=80&w=600',
    tags: ['Kabab Cut', 'Grill Ready'],
    cutType: 'Kabab Cut',
    freshnessBadge: 'Premium Cut',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g', price: 289 },
      { label: '1kg', price: 549 }
    ]
  },

  // =========================================================
  // MEAT - MUTTON
  // =========================================================
  {
    id: 'm_mu_boneless',
    name: 'Mutton Boneless Cubes (Boneless Cut)',
    description: 'Tender, melt-in-your-mouth pasture-raised boneless mutton cubes. Ideal for slow-cooked stews, handis, or roasts.',
    price: 799,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'boneless-cut',
    image: 'https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&q=80&w=600',
    tags: ['Boneless', 'Pasture Raised'],
    cutType: 'Boneless Cut',
    freshnessBadge: '100% Organic',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '250g', price: 419 },
      { label: '500g', price: 799 },
      { label: '1kg', price: 1499 }
    ]
  },
  {
    id: 'm_mu_bone',
    name: 'Mutton Chops & Ribs (Bone Cut)',
    description: 'Premium bone-in mutton chops and ribs with deep marbling, offering unparalleled flavor richness for roasts and pan-searing.',
    price: 699,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'bone-cut',
    image: 'https://images.unsplash.com/photo-1603048297172-c92544798d5e?auto=format&fit=crop&q=80&w=600',
    tags: ['Bone Cut', 'Ribs & Chops'],
    cutType: 'Bone Cut',
    freshnessBadge: 'Prime Quality',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g', price: 699 },
      { label: '1kg', price: 1299 }
    ]
  },
  {
    id: 'm_mu_curry',
    name: 'Classic Mutton Curry Cut',
    description: 'Bite-sized pasture-raised mutton pieces on the bone, perfect for traditional mutton curry, rogan josh, or bhuna meat.',
    price: 629,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'curry-cut',
    image: 'https://images.unsplash.com/photo-1603048297172-c92544798d5e?auto=format&fit=crop&q=80&w=600',
    tags: ['Curry Cut', 'Heritage Lamb'],
    cutType: 'Curry Cut',
    freshnessBadge: 'Pure Quality',
    deliveryEstimate: '90 mins',
    discount: 15,
    weights: [
      { label: '500g', price: 629 },
      { label: '1kg', price: 1199 }
    ]
  },
  {
    id: 'm_mu_biryani',
    name: 'Rich Mutton Biryani Cut',
    description: 'Large, succulent bone-in mutton chunks specially carved to absorb exquisite spices in premium slow-cooked biryanis.',
    price: 649,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'biryani-cut',
    image: 'https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&q=80&w=600',
    tags: ['Biryani Special', 'Bone-In'],
    cutType: 'Biryani Cut',
    freshnessBadge: 'Gourmet Selection',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g', price: 649 },
      { label: '1kg', price: 1249 }
    ]
  },
  {
    id: 'm_mu_kabab',
    name: 'Mutton Keema & Kabab Chunks (Kabab Cut)',
    description: 'Finely minced lamb keema and hand-diced tender kabab chunks, optimal for making melt-in-the-mouth galouti or seekh kababs.',
    price: 719,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'mutton',
    subSubcategoryId: 'kabab-cut',
    image: 'https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&q=80&w=600',
    tags: ['Kabab Cut', 'Minced & Chunks'],
    cutType: 'Kabab Cut',
    freshnessBadge: 'Finest Grade',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g', price: 719 },
      { label: '1kg', price: 1399 }
    ]
  },

  // =========================================================
  // MEAT - FISH
  // =========================================================
  {
    id: 'm_fi_rohu',
    name: 'Fresh River Rohu',
    description: 'Freshly caught sweet-water Rohu, scaled and sliced into perfect traditional Bengali-style curry cuts.',
    price: 249,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'fish',
    subSubcategoryId: 'rohu',
    origin: 'Local Rivers',
    image: 'https://images.unsplash.com/photo-1611171711790-b98d9ee81410?auto=format&fit=crop&q=80&w=600',
    tags: ['Daily Catch', 'Freshwater'],
    cutType: 'Curry Cut',
    freshnessBadge: 'Daily Catch',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g', price: 249 },
      { label: '1kg', price: 469 }
    ],
    fishCuts: ['Curry Cut', 'Steak Cut', 'Whole Cleaned']
  },
  {
    id: 'm_fi_katla',
    name: 'Freshwater Katla',
    description: 'Nutrient-rich, classic Katla fish sourced sustainably from local freshwater lakes, expertly sliced and ready to fry.',
    price: 269,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'fish',
    subSubcategoryId: 'katla',
    origin: 'Freshwater Lakes',
    image: 'https://images.unsplash.com/photo-1599084924616-646e3cce9880?auto=format&fit=crop&q=80&w=600',
    tags: ['Daily Catch', 'Steak Cut'],
    cutType: 'Steak Cut',
    freshnessBadge: '100% Fresh',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g', price: 269 },
      { label: '1kg', price: 499 }
    ],
    fishCuts: ['Steak Cut', 'Curry Cut']
  },
  {
    id: 'm_fi_pomfret',
    name: 'Premium White Pomfret',
    description: 'Exquisite, delicate-tasting whole White Pomfret wild-caught from the Arabian Sea, ideal for tawa frying or steaming.',
    price: 599,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'fish',
    subSubcategoryId: 'pomfret',
    origin: 'Arabian Sea',
    image: 'https://images.unsplash.com/photo-1611171711790-b98d9ee81410?auto=format&fit=crop&q=80&w=600',
    tags: ['Sea Fish', 'Whole Pomfret'],
    cutType: 'Whole Cleaned',
    freshnessBadge: 'Wild Caught',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '500g (2-3 pcs)', price: 599 },
      { label: '1kg', price: 1149 }
    ],
    fishCuts: ['Whole Cleaned', 'Sliced']
  },
  {
    id: 'm_fi_surmai',
    name: 'Surmai (King Fish)',
    description: 'Prestige Seer Fish (Surmai) cut into thick bone-in steaks, famed for its highly meaty texture and delicate oceanic flavor.',
    price: 689,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'fish',
    subSubcategoryId: 'surmai',
    origin: 'Indian Ocean',
    image: 'https://images.unsplash.com/photo-1599084924616-646e3cce9880?auto=format&fit=crop&q=80&w=600',
    tags: ['Seer Fish', 'Premium'],
    cutType: 'Steak Cut',
    freshnessBadge: 'Wild Caught',
    deliveryEstimate: '90 mins',
    discount: 5,
    weights: [
      { label: '500g', price: 689 },
      { label: '1kg', price: 1299 }
    ],
    fishCuts: ['Steak Cut', 'Boneless Fillet']
  },

  // =========================================================
  // MEAT - PRAWNS (no third level subsubcategory)
  // =========================================================
  {
    id: 'm_pr_tiger',
    name: 'Jumbo Tiger Prawns',
    description: 'Large, fleshy, and extremely sweet Tiger Prawns harvested sustainably, completely peeled, cleaned and deveined with tail-on.',
    price: 749,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'prawns',
    image: 'https://images.unsplash.com/photo-1559742811-822873691fc8?auto=format&fit=crop&q=80&w=600',
    tags: ['Prawns', 'Wild Caught'],
    freshnessBadge: 'Premium',
    deliveryEstimate: '90 mins',
    weights: [
      { label: '250g', price: 399 },
      { label: '500g', price: 749 },
      { label: '1kg', price: 1399 }
    ],
    cleaningOptions: ['Deveined, Tail-On', 'Fully Peeled']
  },
  {
    id: 'm_pr_white',
    name: 'Medium White Prawns',
    description: 'Sweet, tender fresh white prawns, perfectly peeled and deveined, exceptional for quick stir-fries, curries, and pasta dishes.',
    price: 499,
    unit: '500g',
    categoryId: 'meat',
    subcategoryId: 'prawns',
    image: 'https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&q=80&w=600',
    tags: ['Prawns', 'Daily Catch'],
    freshnessBadge: 'Super Fresh',
    deliveryEstimate: '90 mins',
    discount: 10,
    weights: [
      { label: '250g', price: 269 },
      { label: '500g', price: 499 },
      { label: '1kg', price: 929 }
    ],
    cleaningOptions: ['Deveined', 'Whole Cleaned']
  },

  // =========================================================
  // SMOOTHIES
  // =========================================================
  {
    id: 's_avocado',
    name: 'Avocado Classic',
    description: 'Ultra-creamy premium blend of ripe organic Hass avocados, organic spinach, cold-pressed almond milk, and raw wild honey.',
    price: 289,
    unit: '350ml',
    categoryId: 'smoothies',
    image: 'https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&q=80&w=600',
    tags: ['Cold Pressed', 'Antioxidant'],
    freshnessBadge: 'Freshly Blended',
    deliveryEstimate: '30 mins',
    weights: [
      { label: '350ml', price: 289 },
      { label: '500ml', price: 399 }
    ]
  },
  {
    id: 's_blueberry',
    name: 'Blueberry Smoothie',
    description: 'Packed with handpicked antioxidant-rich blueberries, creamy organic Greek yogurt, and a touch of organic chia seeds.',
    price: 319,
    unit: '350ml',
    categoryId: 'smoothies',
    image: 'https://images.unsplash.com/photo-1600718374662-0483d2b9da44?auto=format&fit=crop&q=80&w=600',
    tags: ['Antioxidant', 'Superfood'],
    freshnessBadge: 'Made To Order',
    deliveryEstimate: '30 mins',
    weights: [
      { label: '350ml', price: 319 },
      { label: '500ml', price: 439 }
    ]
  },
  {
    id: 's_raspberry',
    name: 'Raspberry Smoothie',
    description: 'A delightful tart-sweet health fusion of organic red raspberries, raw gluten-free oats, and rich coconut milk cream.',
    price: 319,
    unit: '350ml',
    categoryId: 'smoothies',
    image: 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&q=80&w=600',
    tags: ['Vibrant', 'Vegan'],
    freshnessBadge: 'Made To Order',
    deliveryEstimate: '30 mins',
    weights: [
      { label: '350ml', price: 319 },
      { label: '500ml', price: 439 }
    ]
  },
  {
    id: 's_red_grape',
    name: 'Red Grape Smoothie',
    description: 'Deeply refreshing puree of hand-harvested organic red seedless grapes, blended with superfood chia seeds and fresh apple juice.',
    price: 269,
    unit: '350ml',
    categoryId: 'smoothies',
    image: 'https://images.unsplash.com/photo-1536882240095-0379873feb4e?auto=format&fit=crop&q=80&w=600',
    tags: ['Refreshing', 'Hydrating'],
    freshnessBadge: 'Fresh Press',
    deliveryEstimate: '30 mins',
    weights: [
      { label: '350ml', price: 269 },
      { label: '500ml', price: 369 }
    ]
  }
];
