import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartProduct, AuthUser } from './types';
import { auth, db } from './lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { onAuthStateChanged, signOut, getRedirectResult } from 'firebase/auth';

interface CartItem extends CartProduct {
  quantity: number;
}

export interface FlyingItem {
  id: string;
  image: string;
  startX: number;
  startY: number;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (product: CartProduct, quantity?: number) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  cartTotal: number;
  cartCount: number;
  clearCart: () => void;
  user: AuthUser | null;
  logoutUser: () => void;
  isAuthLoading: boolean;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  addedItemToast: { id: string; name: string } | null;
  setAddedItemToast: (toast: { id: string; name: string } | null) => void;
  flyingItems: FlyingItem[];
  triggerFlyingItem: (item: Omit<FlyingItem, 'id'>) => void;
  removeFlyingItem: (id: string) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [addedItemToast, setAddedItemToast] = useState<{ id: string; name: string } | null>(null);
  const [flyingItems, setFlyingItems] = useState<FlyingItem[]>([]);

  const triggerFlyingItem = (item: Omit<FlyingItem, 'id'>) => {
    const id = Math.random().toString(36).substring(7);
    setFlyingItems(prev => [...prev, { ...item, id }]);
  };

  const removeFlyingItem = (id: string) => {
    setFlyingItems(prev => prev.filter(item => item.id !== id));
  };

  useEffect(() => {
    // Handle redirect result for mobile Safari / iOS
    getRedirectResult(auth).catch((err) => {
      console.warn("Redirect auth check:", err);
    });

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        let role = 'user';
        try {
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          const userDocSnap = await getDoc(userDocRef);
          
          if (userDocSnap.exists()) {
            role = userDocSnap.data().role || 'user';
          }
          if (firebaseUser.email === 'jiyooshams@gmail.com' || firebaseUser.email === 'yoyokishwar@gmail.com') {
            role = 'admin';
          }
          
          const userData = {
            id: firebaseUser.uid,
            name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
            email: firebaseUser.email || '',
            picture: firebaseUser.photoURL || undefined,
            role,
          };
          
          setUser(userData);
          
          // Upsert user in Firestore
          await setDoc(userDocRef, {
            ...userData,
            lastLogin: serverTimestamp(),
          }, { merge: true });
          
        } catch (error) {
          console.error("Error fetching user role:", error);
          setUser({
            id: firebaseUser.uid,
            name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
            email: firebaseUser.email || '',
            picture: firebaseUser.photoURL || undefined,
            role: 'user',
          });
        }
      } else {
        setUser(null);
      }
      setIsAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const addToCart = (product: CartProduct, quantity: number = 1) => {
    setItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { ...product, quantity }];
    });

    // Trigger premium notification toast
    setAddedItemToast({ id: product.id, name: product.name });
  };

  const removeFromCart = (id: string) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, quantity: number) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, quantity } : item));
  };

  const clearCart = () => setItems([]);

  const logoutUser = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  const cartTotal = items.reduce((sum, item) => sum + (item.numericPrice * item.quantity), 0);
  const cartCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider value={{ 
      items, 
      addToCart, 
      removeFromCart, 
      updateQuantity,
      cartTotal, 
      cartCount, 
      clearCart,
      user,
      logoutUser,
      isAuthLoading,
      searchQuery,
      setSearchQuery,
      addedItemToast,
      setAddedItemToast,
      flyingItems,
      triggerFlyingItem,
      removeFlyingItem
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}


