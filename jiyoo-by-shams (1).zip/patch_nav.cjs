const fs = require('fs');
let code = fs.readFileSync('src/components/Navbar.tsx', 'utf8');

code = code.replace('export function Navbar({ onUserClick, onCartClick }: { onUserClick: () => void; onCartClick: () => void }) {', 'export function Navbar({ onUserClick, onCartClick, onAboutClick }: { onUserClick: () => void; onCartClick: () => void; onAboutClick?: () => void }) {');

code = code.replace('<nav className="hidden md:flex space-x-8 items-center">', `<nav className="hidden md:flex space-x-8 items-center">
              <button onClick={onAboutClick} className="text-sm font-medium text-brand-gray-500 hover:text-brand-black transition-colors">About JIYOO</button>`);

fs.writeFileSync('src/components/Navbar.tsx', code);
