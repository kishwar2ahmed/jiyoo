const fs = require('fs');
let code = fs.readFileSync('src/components/admin/AnalyticsTab.tsx', 'utf8');
code = code.replace('<ResponsiveContainer w-full h-full>', '<ResponsiveContainer width="100%" height="100%">');
fs.writeFileSync('src/components/admin/AnalyticsTab.tsx', code);
