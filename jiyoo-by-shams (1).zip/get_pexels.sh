#!/bin/bash
fetch() {
  url=$(curl -s "https://api.pexels.com/v1/search?query=$1&per_page=15" -H 'Authorization: 563492ad6f91700001000001d9426f499edb4ba4b6b6ec06f7dfbaea' | grep -o '"large":"[^"]*"' | head -n 1 | cut -d'"' -f4)
  echo "$url"
}
echo "Mango: $(fetch 'fresh+mango')"
echo "Avocado: $(fetch 'fresh+avocado+halves')"
echo "Apple: $(fetch 'fresh+red+apples')"
echo "Pomegranate: $(fetch 'pomegranate+fruit')"
echo "Tomatoes: $(fetch 'heirloom+tomatoes')"
echo "Basil: $(fetch 'fresh+basil+leaves')"
echo "Galangal: $(fetch 'ginger+root')"
echo "Spinach: $(fetch 'fresh+spinach+leaves')"
echo "Salmon: $(fetch 'raw+salmon+fillet')"
echo "Chicken: $(search 'raw+chicken+breast')"
echo "Mutton: $(fetch 'raw+red+meat')"
echo "Prawns: $(fetch 'raw+prawns+seafood')"
echo "Berry Smoothie: $(fetch 'berry+smoothie+drink')"
echo "Mango Smoothie: $(fetch 'mango+smoothie+drink')"
