const fs = require('fs');

let cartContext = fs.readFileSync('src/CartContext.tsx', 'utf8');
cartContext = cartContext.replace(
  `if (userDocSnap.exists()) {\n            role = userDocSnap.data().role || 'user';\n          }`,
  `if (userDocSnap.exists()) {
            role = userDocSnap.data().role || 'user';
          }
          if (firebaseUser.email === 'jiyooshams@gmail.com' || firebaseUser.email === 'yoyokishwar@gmail.com') {
            role = 'admin';
          }`
);
fs.writeFileSync('src/CartContext.tsx', cartContext);

let adminPanel = fs.readFileSync('src/components/AdminPanel.tsx', 'utf8');
adminPanel = adminPanel.replace(
  `if (!user || user.role !== 'admin') {`,
  `if (!user || (user.role !== 'admin' && user.email !== 'jiyooshams@gmail.com' && user.email !== 'yoyokishwar@gmail.com')) {`
);
fs.writeFileSync('src/components/AdminPanel.tsx', adminPanel);

