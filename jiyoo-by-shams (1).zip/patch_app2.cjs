const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const eventListener = `
  useEffect(() => {
    const handleOpenAbout = () => setIsAboutOpen(true);
    document.addEventListener('open-about', handleOpenAbout);
    return () => document.removeEventListener('open-about', handleOpenAbout);
  }, []);
`;

code = code.replace('const [isAboutOpen, setIsAboutOpen] = useState(false);', `const [isAboutOpen, setIsAboutOpen] = useState(false);\n${eventListener}`);

fs.writeFileSync('src/App.tsx', code);
