const { execSync } = require('child_process');
const queries = ['fresh mango on table', 'fresh avocado halves', 'fresh red apples', 'pomegranate fruit', 'heirloom tomatoes', 'fresh basil leaves', 'ginger root', 'fresh spinach leaves', 'raw salmon fillet', 'raw chicken breast', 'raw red meat', 'raw prawns seafood', 'berry smoothie drink', 'mango smoothie drink'];

for (const q of queries) {
  try {
    const cmd = `curl -s 'https://api.pexels.com/v1/search?query=${encodeURIComponent(q)}&per_page=1' -H 'Authorization: 563492ad6f91700001000001d9426f499edb4ba4b6b6ec06f7dfbaea'`;
    const res = execSync(cmd).toString();
    const data = JSON.parse(res);
    console.log(`${q}: ${data.photos[0].src.large}`);
  } catch(e) { console.log(q, 'Error'); }
}
