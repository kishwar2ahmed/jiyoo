const fs = require('fs');

let footer = fs.readFileSync('src/components/Footer.tsx', 'utf8');
footer = footer.replace('JIYOO Premium Grocery.', 'JIYOO Premium Products.');
fs.writeFileSync('src/components/Footer.tsx', footer);

let hero = fs.readFileSync('src/components/Hero.tsx', 'utf8');
hero = hero.replace('premium grocery.', 'premium products.');
fs.writeFileSync('src/components/Hero.tsx', hero);

let cart = fs.readFileSync('src/components/CartModal.tsx', 'utf8');
cart = cart.replace('Premium Grocery Order', 'Premium Products Order');
fs.writeFileSync('src/components/CartModal.tsx', cart);

let nav = fs.readFileSync('src/components/Navbar.tsx', 'utf8');
nav = nav.replace('Search premium groceries...', 'Search premium products...');
fs.writeFileSync('src/components/Navbar.tsx', nav);
