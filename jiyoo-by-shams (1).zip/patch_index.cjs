const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');
html = html.replace('<title>JIYOO | Premium Grocery</title>', '<link rel="icon" type="image/jpeg" href="/logo.jpg" />\n    <title>JIYOO | Premium Products</title>');
html = html.replace('content="JIYOO | Premium Grocery"', 'content="JIYOO | Premium Products"');
fs.writeFileSync('index.html', html);
