const fs = require('fs');
let code = fs.readFileSync('src/components/AuthModal.tsx', 'utf8');

// Find the start of the return statement
const returnStart = code.indexOf('return (');
const beforeReturn = code.substring(0, returnStart);

const modalRender = `return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#f8f6f0]/90 backdrop-blur-sm overflow-y-auto overflow-x-hidden"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="relative w-full max-w-sm my-8 bg-white/90 backdrop-blur-3xl border border-stone-200/90 rounded-[2.5rem] p-8 md:p-10 shadow-2xl pointer-events-auto"
          >
              {/* Inner ambient luxury glow */}
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-100/40 rounded-full blur-[70px] pointer-events-none" />

              {!isLoading && step !== "success" && (
                <button
                  onClick={onClose}
                  className="absolute top-6 right-6 p-2 rounded-full hover:bg-stone-100 text-stone-400 hover:text-stone-900 transition-colors z-50"
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              )}

              <div className="relative z-10">
                {user && step !== "success" ? (
                  <motion.div
                    key="profile"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-6"
                  >
                    {user.picture ? (
                      <img
                        src={user.picture}
                        alt={user.name}
                        className="w-20 h-20 rounded-full mx-auto mb-6 shadow-md border border-stone-200"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-20 h-20 rounded-full bg-stone-100 border border-stone-200 flex items-center justify-center text-2xl font-medium mx-auto mb-6 text-stone-800 shadow-md">
                        {user.name.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    <h2 className="text-2xl font-serif text-stone-900 mb-1">
                      {user.name}
                    </h2>
                    <p className="text-sm text-stone-500 mb-8 font-light flex items-center justify-center gap-2">
                      <Check className="w-4 h-4 text-amber-500" />
                      Premium Member
                    </p>

                    <button
                      onClick={() => {
                        logoutUser();
                        setTimeout(() => {
                          onClose();
                        }, 500);
                      }}
                      className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-medium transition-all duration-200 text-sm border border-stone-200"
                    >
                      <LogOut className="w-4 h-4" /> Sign Out
                    </button>
                  </motion.div>
                ) : step === "success" ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-10"
                  >
                    <div className="w-16 h-16 bg-stone-900 rounded-full flex items-center justify-center mx-auto mb-6 text-white shadow-lg">
                      <Check className="w-8 h-8" />
                    </div>
                    <h2 className="text-2xl font-serif text-stone-900 mb-2">
                      {mode === "signup" ? "Account Created!" : "Welcome Back"}
                    </h2>
                    <p className="text-xs text-stone-500 font-light tracking-wide uppercase">
                      Redirecting to your JIYOO Experience...
                    </p>
                  </motion.div>
                ) : (
                  <motion.div
                    key="auth-form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    {/* Mode Toggle Switcher */}
                    <div className="flex bg-stone-100 p-1.5 rounded-2xl mb-6 border border-stone-200/80">
                      <button
                        type="button"
                        onClick={() => { setMode("signin"); setError(null); }}
                        className={\`flex-1 py-2.5 text-xs font-medium rounded-xl transition-all duration-200 \${
                          mode === "signin"
                            ? "bg-white text-stone-900 shadow-sm border border-stone-200/60 font-semibold"
                            : "text-stone-500 hover:text-stone-900"
                        }\`}
                      >
                        Sign In
                      </button>
                      <button
                        type="button"
                        onClick={() => { setMode("signup"); setError(null); }}
                        className={\`flex-1 py-2.5 text-xs font-medium rounded-xl transition-all duration-200 \${
                          mode === "signup"
                            ? "bg-white text-stone-900 shadow-sm border border-stone-200/60 font-semibold"
                            : "text-stone-500 hover:text-stone-900"
                        }\`}
                      >
                        Sign Up
                      </button>
                    </div>

                    <div className="text-center mb-8">
                      <h2 className="text-3xl font-serif text-stone-900 tracking-tight mb-2">
                        {mode === "signin" ? "Welcome Back" : "Join JIYOO"}
                      </h2>
                      <p className="text-sm text-stone-500 font-light">
                        {mode === "signin" 
                          ? "Enter your credentials to access your account." 
                          : "Create an account to begin your premium experience."}
                      </p>
                    </div>

                    <form
                      onSubmit={mode === "signin" ? handleEmailSignIn : handleEmailSignUp}
                      className="space-y-4 mb-6"
                    >
                      {mode === "signup" && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <label
                            className="block text-[11px] font-medium text-stone-700 mb-1.5 tracking-wider uppercase"
                            htmlFor="fullName"
                          >
                            Full Name
                          </label>
                          <div className="relative group">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                              <User className="h-4 w-4 text-stone-400 group-focus-within:text-stone-900 transition-colors" />
                            </div>
                            <input
                              id="fullName"
                              type="text"
                              required={mode === "signup"}
                              value={fullName}
                              onChange={(e) => setFullName(e.target.value)}
                              className="w-full pl-11 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 text-sm focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all outline-none"
                              placeholder="John Doe"
                            />
                          </div>
                        </motion.div>
                      )}

                      <div>
                        <label
                          className="block text-[11px] font-medium text-stone-700 mb-1.5 tracking-wider uppercase"
                          htmlFor="email"
                        >
                          Email Address
                        </label>
                        <div className="relative group">
                          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <Mail className="h-4 w-4 text-stone-400 group-focus-within:text-stone-900 transition-colors" />
                          </div>
                          <input
                            id="email"
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full pl-11 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 text-sm focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all outline-none"
                            placeholder="hello@example.com"
                          />
                        </div>
                      </div>

                      <div>
                        <label
                          className="block text-[11px] font-medium text-stone-700 mb-1.5 tracking-wider uppercase"
                          htmlFor="password"
                        >
                          Password
                        </label>
                        <div className="relative group">
                          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <Lock className="h-4 w-4 text-stone-400 group-focus-within:text-stone-900 transition-colors" />
                          </div>
                          <input
                            id="password"
                            type="password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full pl-11 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 text-sm focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all outline-none"
                            placeholder="••••••••"
                          />
                        </div>
                      </div>

                      {error && (
                        <motion.div
                          initial={{ opacity: 0, y: -5 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-red-50 border border-red-100 text-red-600 text-xs p-3 rounded-lg flex items-start gap-2"
                        >
                          <span className="shrink-0 font-medium">!</span>
                          <span>{error}</span>
                        </motion.div>
                      )}

                      <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full relative py-3.5 px-4 bg-stone-900 hover:bg-black text-white rounded-xl font-medium transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed shadow-md shadow-stone-900/10 overflow-hidden group mt-6"
                      >
                        <span className={\`flex items-center justify-center gap-2 \${isLoading ? "opacity-0" : "opacity-100"}\`}>
                          {mode === "signin" ? "Sign In" : "Create Account"}
                        </span>
                        {isLoading && (
                          <div className="absolute inset-0 flex items-center justify-center bg-stone-900">
                            <Loader2 className="w-5 h-5 animate-spin" />
                          </div>
                        )}
                      </button>
                    </form>

                    <div className="relative flex items-center py-4">
                      <div className="flex-grow border-t border-stone-200"></div>
                      <span className="flex-shrink-0 mx-4 text-stone-400 text-xs font-medium uppercase tracking-wider">
                        Or continue with
                      </span>
                      <div className="flex-grow border-t border-stone-200"></div>
                    </div>

                    <button
                      type="button"
                      onClick={handleGoogleSignIn}
                      disabled={isLoading}
                      className="w-full flex items-center justify-center gap-3 py-3.5 px-4 bg-white border border-stone-200 hover:bg-stone-50 text-stone-700 rounded-xl font-medium transition-all duration-200 shadow-sm mt-2 disabled:opacity-50 text-sm"
                    >
                      <svg viewBox="0 0 24 24" className="w-5 h-5">
                        <path
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                          fill="#4285F4"
                        />
                        <path
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                          fill="#34A853"
                        />
                        <path
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                          fill="#FBBC05"
                        />
                        <path
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                          fill="#EA4335"
                        />
                      </svg>
                      Google
                    </button>
                    
                    <div className="mt-8 pt-6 border-t border-stone-100 flex items-center justify-center gap-2 text-[10px] uppercase tracking-widest text-stone-400 font-medium">
                      <Sparkles className="w-3 h-3 text-amber-500" />
                      Secure Encrypted Login
                    </div>
                  </motion.div>
                )}
              </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
`;

fs.writeFileSync('src/components/AuthModal.tsx', beforeReturn + modalRender);
console.log('Fixed AuthModal completely!');
