#!/bin/bash
search() {
  curl -s "https://unsplash.com/napi/search/photos?query=$1&per_page=1" | grep -o '"id":"[^"]*"' | head -n 1 | cut -d'"' -f4
}
echo "Mango: $(search mango)"
echo "Avocado: $(search avocado)"
echo "Apple: $(search apple)"
echo "Pomegranate: $(search pomegranate)"
echo "Tomatoes: $(search tomatoes)"
echo "Basil: $(search basil)"
echo "Galangal: $(search galangal)"
echo "Spinach: $(search spinach)"
echo "Salmon: $(search salmon+fillet)"
echo "Chicken: $(search raw+chicken)"
echo "Mutton: $(search raw+meat)"
echo "Prawns: $(search raw+prawns)"
echo "Berry Smoothie: $(search berry+smoothie)"
echo "Mango Smoothie: $(search mango+smoothie)"
