import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCart } from '../CartContext';
import { 
  X, Minus, Plus, ShoppingBag, ArrowRight, 
  CreditCard, Check, MapPin, Loader2, ShieldCheck,
  ChevronLeft
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export function CartModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { items, removeFromCart, updateQuantity, cartTotal, cartCount, clearCart, user } = useCart();
  
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [formErrors, setFormErrors] = useState<{ name?: string; phone?: string; address?: string }>({});

  useEffect(() => {
    if (user) {
      setName(user.name);
    }
  }, [user]);

  // Reset state when opened/closed
  useEffect(() => {
    if (!isOpen) {
      setTimeout(() => setStep('cart'), 300);
    }
  }, [isOpen]);

  const validateForm = () => {
    const errors: any = {};
    if (!name.trim()) errors.name = 'Name is required';
    if (!phone.trim() || phone.length < 10) errors.phone = 'Valid phone is required';
    if (!address.trim()) errors.address = 'Address is required';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      if (document.querySelector('script[src="https://checkout.razorpay.com/v1/checkout.js"]')) {
        resolve(true);
        return;
      }
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    
    setIsProcessing(true);
    const res = await loadRazorpayScript();
    if (!res) {
      setFormErrors({ ...formErrors, address: 'Razorpay SDK failed to load. Check your connection.' });
      setIsProcessing(false);
      return;
    }

    try {
      const orderRes = await fetch('/api/razorpay/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: cartTotal }),
      });
      
      const data = await orderRes.json();
      
      if (!data.success) {
        setFormErrors({ ...formErrors, address: 'Failed to create order: ' + data.error });
        setIsProcessing(false);
        return;
      }
      
      const options = {
        key: data.key_id,
        amount: data.order.amount,
        currency: 'INR',
        name: 'JIYOO',
        description: 'Premium Products Order',
        order_id: data.order.id,
        config: {
          display: {
            hide: [{ method: 'paylater' }]
          }
        },
        handler: async function (response: any) {
          try {
            // Prepare order data for secure backend creation
            const orderData = {
              userId: user?.id || 'guest',
              amount: cartTotal,
              items: items.map(i => ({ 
                 id: i.id, 
                 name: i.name, 
                 quantity: i.quantity, 
                 price: i.numericPrice, 
                 image: i.image 
               })),
              shippingDetails: { name, phone, address }
            };

            // Verify payment
            const verifyRes = await fetch('/api/razorpay/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
                orderData
              })
            });
            const verifyData = await verifyRes.json();
            
            if (!verifyData.success) {
              setFormErrors({ ...formErrors, address: 'Payment verification failed: ' + verifyData.error });
              setIsProcessing(false);
              return;
            }

            // Always write client order record as instant fallback
            try {
              await addDoc(collection(db, 'orders'), {
                ...orderData,
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                status: 'completed',
                createdAt: serverTimestamp()
              });
            } catch (fallbackErr) {
              console.warn('Backup order creation in client firestore:', fallbackErr);
            }
          } catch (e: any) {
            console.error('Failed to save order to firestore', e);
            const errInfo = {
              error: e.message || String(e),
              operationType: 'create',
              path: 'orders',
              authInfo: { userId: user?.id }
            };
            console.error('Firestore Error: ', JSON.stringify(errInfo));
          }
          setStep('success');
          setTimeout(clearCart, 2000);
        },
        prefill: {
          name: name,
          email: user?.email || '',
          contact: phone,
        },
        theme: { color: '#000000' },
        modal: {
          ondismiss: function() {
            setIsProcessing(false);
          }
        }
      };

      const rzp1 = new (window as any).Razorpay(options);
      rzp1.on('payment.failed', function (response: any) {
        setFormErrors({ ...formErrors, address: `Payment failed! Reason: ${response.error.description}` });
        setIsProcessing(false);
      });
      rzp1.open();
      
    } catch (err: any) {
      setFormErrors({ ...formErrors, address: 'Error starting Razorpay checkout: ' + err.message });
      setIsProcessing(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="fixed top-0 right-0 h-full supports-[height:100dvh]:h-[100dvh] w-full max-w-md bg-white shadow-2xl z-50 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-100 bg-white z-10">
              <div className="flex items-center gap-4">
                {step === 'checkout' && (
                  <button onClick={() => setStep('cart')} className="p-2 -ml-2 text-gray-400 hover:text-black transition-colors rounded-full hover:bg-gray-100">
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                )}
                <h2 className="text-xl font-serif text-gray-900 tracking-wide">
                  {step === 'cart' ? 'Your Bag' : step === 'checkout' ? 'Checkout' : 'Order Confirmed'}
                </h2>
              </div>
              <button onClick={onClose} className="p-2 text-gray-400 hover:text-black transition-colors rounded-full hover:bg-gray-100">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto bg-gray-50/50 scrollbar-hide relative">
              <AnimatePresence mode="wait">
                {/* CART STEP */}
                {step === 'cart' && (
                  <motion.div 
                    key="cart"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                    className="p-6 flex flex-col min-h-full"
                  >
                    {items.length === 0 ? (
                      <div className="flex-1 flex flex-col items-center justify-center text-gray-400 space-y-6">
                        <ShoppingBag className="w-16 h-16 stroke-[1]" />
                        <p className="text-lg font-light tracking-wide">Your bag is empty.</p>
                        <button onClick={onClose} className="px-8 py-3 bg-black text-white text-sm tracking-widest uppercase hover:bg-gray-800 transition-colors">
                          Continue Shopping
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="space-y-6 flex-1">
                          {items.map((item) => (
                            <div key={item.id} className="flex gap-6 p-4 bg-white rounded-2xl shadow-sm border border-gray-100">
                              <div className="w-24 h-24 bg-gray-50 rounded-xl overflow-hidden relative flex-shrink-0">
                                {item.image ? (
                                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="absolute inset-0 flex items-center justify-center text-gray-300">
                                    <ShoppingBag className="w-8 h-8 opacity-20" />
                                  </div>
                                )}
                              </div>
                              <div className="flex-1 flex flex-col justify-between py-1">
                                <div>
                                  <div className="flex justify-between items-start">
                                    <h3 className="font-medium text-gray-900">{item.name}</h3>
                                    <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                                      <X className="w-4 h-4" />
                                    </button>
                                  </div>
                                  <p className="text-gray-500 text-sm mt-1">₹{item.numericPrice}</p>
                                </div>
                                <div className="flex items-center justify-between mt-4">
                                  <div className="flex items-center gap-4 bg-gray-50 rounded-lg p-1 border border-gray-100">
                                    <button 
                                      onClick={() => updateQuantity(item.id, Math.max(0, item.quantity - 1))}
                                      className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-black hover:bg-white rounded-md transition-all shadow-sm"
                                    >
                                      <Minus className="w-3 h-3" />
                                    </button>
                                    <span className="w-4 text-center text-sm font-medium">{item.quantity}</span>
                                    <button 
                                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                      className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-black hover:bg-white rounded-md transition-all shadow-sm"
                                    >
                                      <Plus className="w-3 h-3" />
                                    </button>
                                  </div>
                                  <p className="font-medium text-gray-900 tracking-tight">₹{item.numericPrice * item.quantity}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </motion.div>
                )}

                {/* CHECKOUT STEP */}
                {step === 'checkout' && (
                  <motion.div 
                    key="checkout"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="p-6 space-y-8 pb-32"
                  >
                    {/* Delivery Info */}
                    <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
                      <div className="flex items-center gap-3 text-gray-900 border-b border-gray-100 pb-4">
                        <MapPin className="w-5 h-5 text-gray-400" />
                        <h3 className="font-serif text-lg">Delivery Details</h3>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2 font-medium">Full Name</label>
                          <input 
                            type="text" value={name} onChange={e => setName(e.target.value)}
                            className={`w-full bg-gray-50 border ${formErrors.name ? 'border-red-300 focus:border-red-500' : 'border-gray-200 focus:border-black'} rounded-xl p-3.5 text-gray-900 transition-colors outline-none`}
                            placeholder="Jane Doe"
                          />
                          {formErrors.name && <p className="text-red-500 text-xs mt-1.5">{formErrors.name}</p>}
                        </div>
                        <div>
                          <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2 font-medium">Phone Number</label>
                          <input 
                            type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                            className={`w-full bg-gray-50 border ${formErrors.phone ? 'border-red-300 focus:border-red-500' : 'border-gray-200 focus:border-black'} rounded-xl p-3.5 text-gray-900 transition-colors outline-none`}
                            placeholder="+91 98765 43210"
                          />
                          {formErrors.phone && <p className="text-red-500 text-xs mt-1.5">{formErrors.phone}</p>}
                        </div>
                        <div>
                          <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2 font-medium">Full Address</label>
                          <textarea 
                            value={address} onChange={e => setAddress(e.target.value)} rows={3}
                            className={`w-full bg-gray-50 border ${formErrors.address ? 'border-red-300 focus:border-red-500' : 'border-gray-200 focus:border-black'} rounded-xl p-3.5 text-gray-900 transition-colors outline-none resize-none`}
                            placeholder="House No, Street, City, Landmark..."
                          />
                          {formErrors.address && <p className="text-red-500 text-xs mt-1.5">{formErrors.address}</p>}
                        </div>
                      </div>
                    </section>

                    {/* Payment Method */}
                    <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
                      <div className="flex items-center gap-3 text-gray-900 border-b border-gray-100 pb-4">
                        <CreditCard className="w-5 h-5 text-gray-400" />
                        <h3 className="font-serif text-lg">Payment Method</h3>
                      </div>
                      <div className="space-y-3">
                        <div className="w-full flex items-center justify-between p-4 rounded-xl border-2 border-black bg-gray-50">
                          <div className="flex items-center gap-3">
                            <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center border-black">
                              <div className="w-2.5 h-2.5 bg-black rounded-full" />
                            </div>
                            <span className="font-medium text-gray-900">Pay Online Securely</span>
                          </div>
                          <ShieldCheck className="w-5 h-5 text-black" />
                        </div>
                      </div>
                    </section>
                  </motion.div>
                )}

                {/* SUCCESS STEP */}
                {step === 'success' && (
                  <motion.div 
                    key="success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-8 flex flex-col items-center justify-center text-center min-h-full space-y-6"
                  >
                    <div className="w-24 h-24 bg-green-50 rounded-full flex items-center justify-center text-green-600 mb-4 shadow-sm border border-green-100">
                      <Check className="w-12 h-12" strokeWidth={2.5} />
                    </div>
                    <h2 className="text-3xl font-serif text-gray-900">Order Confirmed</h2>
                    <p className="text-gray-500 leading-relaxed max-w-xs">
                      Thank you for your order. We've received it and are preparing it for delivery.
                    </p>
                    <button 
                      onClick={onClose}
                      className="mt-8 px-8 py-3 bg-black text-white text-sm tracking-widest uppercase hover:bg-gray-800 transition-colors rounded-full"
                    >
                      Return to Store
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Sticky Footer */}
            {step !== 'success' && items.length > 0 && (
              <div className="bg-white border-t border-gray-100 p-6 shadow-[0_-10px_40px_rgba(0,0,0,0.05)] z-20">
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-gray-500 text-sm">
                    <span>Subtotal</span>
                    <span>₹{cartTotal}</span>
                  </div>
                  <div className="flex justify-between text-gray-500 text-sm">
                    <span>Delivery</span>
                    <span className="text-green-600 font-medium">Free</span>
                  </div>
                  <div className="pt-3 border-t border-gray-100 flex justify-between text-gray-900 font-medium text-lg">
                    <span>Total</span>
                    <span>₹{cartTotal}</span>
                  </div>
                </div>
                
                {step === 'cart' ? (
                  <button 
                    onClick={() => setStep('checkout')}
                    className="w-full py-4 bg-black text-white text-sm font-medium tracking-widest uppercase hover:bg-gray-800 transition-all rounded-xl shadow-lg shadow-black/10 flex items-center justify-center gap-2"
                  >
                    Checkout securely
                  </button>
                ) : (
                  <button 
                    onClick={handleCheckout}
                    disabled={isProcessing}
                    className="w-full py-4 bg-black text-white text-sm font-medium tracking-widest uppercase hover:bg-gray-800 transition-all rounded-xl shadow-lg shadow-black/10 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                      <>
                        Pay ₹{cartTotal} 
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                )}
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
