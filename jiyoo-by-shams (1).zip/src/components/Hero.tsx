import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative w-full h-[80vh] flex items-center justify-center overflow-hidden bg-brand-gray-50">
      {/* Background Abstract/Cinematic Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand-gray-100 to-brand-white" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        
        {/* Text Content */}
        <div className="max-w-2xl">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl sm:text-6xl lg:text-7xl font-serif font-medium leading-tight text-brand-black tracking-tight"
          >
            The art of <br />
            <span className="italic text-brand-gray-500">fine living.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="mt-6 text-lg sm:text-xl text-brand-gray-500 font-light max-w-lg leading-relaxed"
          >
            Curated exceptional ingredients delivered with uncompromising quality. Welcome to the new standard of premium products.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="mt-10"
          >
            <button 
              onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
              className="group inline-flex items-center justify-center px-8 py-4 text-sm font-medium tracking-wide text-brand-white bg-brand-black transition-transform hover:scale-105 active:scale-95"
            >
              Explore Collection
              <ArrowRight className="ml-3 w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </motion.div>
        </div>

        {/* 3D Visual Concept */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="hidden md:block relative h-[500px]"
        >
          {/* Abstract floating elements simulating 3D premium products */}
          <motion.div 
            animate={{ y: [-10, 10, -10], rotate: [0, 5, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-10 right-10 w-64 h-80 rounded-2xl overflow-hidden shadow-2xl z-20 bg-brand-white relative"
          >
            <div className="absolute inset-0 bg-brand-gray-100 animate-pulse" />
            <img 
              src="https://images.unsplash.com/photo-1618897996318-5a901fa6ca3a?auto=format&fit=crop&q=80&w=600" 
              alt="Premium Berries"
              className="w-full h-full object-cover opacity-95 relative z-10"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/logo.jpg';
                (e.target as HTMLImageElement).classList.add('opacity-80', 'object-contain', 'p-4');
              }}
              onLoad={(e) => {
                (e.target as HTMLImageElement).previousElementSibling?.remove();
              }}
            />
          </motion.div>

          <motion.div 
            animate={{ y: [10, -10, 10], rotate: [0, -5, 0] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className="absolute bottom-10 left-10 w-56 h-72 rounded-2xl overflow-hidden shadow-xl z-10 bg-brand-gray-100 relative"
          >
            <div className="absolute inset-0 bg-brand-gray-100 animate-pulse" />
            <img 
              src="https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&q=80&w=500" 
              alt="Fresh Avocado"
              className="w-full h-full object-cover relative z-10"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/logo.jpg';
                (e.target as HTMLImageElement).classList.add('opacity-80', 'object-contain', 'p-4');
              }}
              onLoad={(e) => {
                (e.target as HTMLImageElement).previousElementSibling?.remove();
              }}
            />
          </motion.div>
        </motion.div>

      </div>
    </section>
  );
}
