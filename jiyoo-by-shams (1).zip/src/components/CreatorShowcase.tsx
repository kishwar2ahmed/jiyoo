import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ExternalLink, Zap, Code2, PenTool, Cpu, Hexagon, Shield, Coffee } from 'lucide-react';

interface CreatorShowcaseProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CreatorShowcase({ isOpen, onClose }: CreatorShowcaseProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop Blur Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] bg-brand-black/90 backdrop-blur-2xl"
            onClick={onClose}
          />

          {/* Modal Container */}
          <div className="fixed inset-0 z-[120] pointer-events-none flex items-center justify-center p-4 sm:p-6 md:p-10">
            <motion.div
              initial={{ opacity: 0, scale: 0.88, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 20 }}
              transition={{ type: "spring", damping: 28, stiffness: 280, mass: 0.8 }}
              className="relative w-full max-w-5xl bg-gradient-to-br from-brand-gray-900 via-brand-black to-slate-950 rounded-3xl shadow-[0_0_100px_rgba(99,102,241,0.25)] border border-indigo-500/20 overflow-y-auto md:overflow-hidden pointer-events-auto flex flex-col md:flex-row max-h-[92vh] supports-[height:100dvh]:max-h-[90dvh]"
            >
              {/* Close Button - Mobile */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 p-2.5 text-white/70 hover:text-white bg-black/40 hover:bg-white/10 backdrop-blur-md rounded-full transition-all md:hidden z-20 border border-white/10"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Left Column - Developer Hero Showcase */}
              <div className="md:w-5/12 bg-gradient-to-b from-slate-950 via-black to-brand-black relative p-8 md:p-10 flex flex-col justify-between border-b md:border-b-0 md:border-r border-indigo-500/10 overflow-hidden shrink-0">
                {/* Background Ambient Glows */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-72 bg-indigo-500/15 blur-[90px] rounded-full pointer-events-none" />
                <div className="absolute bottom-0 right-0 w-60 h-60 bg-violet-600/10 blur-[80px] rounded-full pointer-events-none" />
                
                {/* Background Grid Pattern */}
                <div className="absolute inset-0 bg-[radial-gradient(rgba(99,102,241,0.08)_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none opacity-60" />

                <div className="relative z-10 space-y-6">
                  <motion.div 
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-mono font-semibold tracking-[0.2em] uppercase"
                  >
                    <Zap className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                    Lead Architect & Developer
                  </motion.div>

                  {/* Developer Image Frame with Modern Indigo Glow */}
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.2 }}
                    className="relative group w-44 h-44 sm:w-52 sm:h-52 mx-auto md:mx-0 my-4"
                  >
                    {/* Animated Outer Glow Ring */}
                    <div className="absolute -inset-1.5 bg-gradient-to-tr from-indigo-500 via-violet-300 to-indigo-600 rounded-3xl blur-md opacity-70 group-hover:opacity-100 transition-opacity duration-500 animate-pulse" />
                    
                    {/* Main Image Holder */}
                    <div className="relative w-full h-full rounded-3xl overflow-hidden border-2 border-indigo-400/50 bg-slate-900 shadow-2xl">
                      <img 
                        src="/IMG-20260723-WA0099.jpg" 
                        alt="kishuu - Lead Developer & Designer" 
                        className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                      />
                      {/* Gradient overlay for contrast */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80" />
                      
                      {/* Status Tag on Image */}
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10">
                        <span className="text-[11px] font-sans font-bold text-indigo-300 tracking-wider flex items-center gap-1.5">
                          <Hexagon className="w-3 h-3 fill-indigo-400 text-indigo-400" />
                          kishuu
                        </span>
                        <span className="text-[9px] text-slate-300 font-mono tracking-widest uppercase">Pro Creator</span>
                      </div>
                    </div>
                  </motion.div>

                  <div>
                    <h2 className="text-2xl sm:text-3xl md:text-4xl font-sans font-bold text-white leading-tight tracking-wide">
                      developed with <span className="text-indigo-400 inline-block animate-bounce">☕</span><br />
                      <span className="font-mono text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 via-indigo-400 to-violet-500 tracking-[0.1em] lowercase text-3xl sm:text-4xl md:text-5xl block mt-1">
                        by kishuu
                      </span>
                    </h2>
                  </div>
                </div>

                <div className="relative z-10 mt-8 pt-6 border-t border-white/10">
                  <p className="text-indigo-400 font-mono text-sm mb-2 flex items-center gap-2">
                    Fuelled by <Coffee className="w-4 h-4 text-indigo-400 inline" />
                  </p>
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed font-light">
                    Every detail of this website has been thoughtfully designed and engineered to deliver a seamless, modern, and highly performant digital experience.
                  </p>
                </div>
              </div>

              {/* Right Column - Capabilities & Experience Showcase */}
              <div className="md:w-7/12 p-8 sm:p-10 md:p-12 relative flex flex-col bg-slate-950/80 backdrop-blur-xl">
                {/* Close Button - Desktop */}
                <button
                  onClick={onClose}
                  className="absolute top-6 right-6 p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-full transition-colors hidden md:block"
                  aria-label="Close modal"
                >
                  <X className="w-6 h-6" />
                </button>

                <div className="flex-1 overflow-y-auto custom-scrollbar">
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.25 }}
                    className="space-y-8"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-indigo-400 text-xs uppercase tracking-widest font-semibold mb-2 font-mono">
                        <Shield className="w-4 h-4 text-indigo-400" />
                        Digital Craftsmanship & Expertise
                      </div>
                      <h3 className="text-2xl sm:text-3xl font-sans font-bold text-white mb-3 tracking-tight">
                        Elevating Digital Experiences
                      </h3>
                      <p className="text-slate-300 text-sm leading-relaxed">
                        Crafting premium websites, eCommerce platforms, AI-powered solutions, and digital experiences that help businesses grow and stand out.
                      </p>
                    </div>

                    {/* Highlighted Feature Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {[
                        { 
                          icon: PenTool, 
                          title: 'Premium Design', 
                          desc: 'Bespoke UI/UX layouts with meticulous typography and motion.' 
                        },
                        { 
                          icon: Code2, 
                          title: 'Robust Engineering', 
                          desc: 'High-speed React, Vite, and full-stack cloud performance.' 
                        },
                        { 
                          icon: Cpu, 
                          title: 'AI-Powered Solutions', 
                          desc: 'Cutting-edge intelligent workflows and automated customer tools.' 
                        },
                        { 
                          icon: Zap, 
                          title: 'E-Commerce Growth', 
                          desc: 'Conversion-oriented shopping experiences engineered to scale.' 
                        },
                      ].map((feature, idx) => (
                        <div 
                          key={idx} 
                          className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-indigo-500/40 hover:bg-indigo-500/[0.04] transition-all duration-300 hover:-translate-y-1 shadow-lg"
                        >
                          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center mb-3">
                            <feature.icon className="w-5 h-5 text-indigo-400" />
                          </div>
                          <h4 className="text-white font-semibold text-sm mb-1 font-sans">{feature.title}</h4>
                          <p className="text-slate-400 text-xs leading-relaxed">{feature.desc}</p>
                        </div>
                      ))}
                    </div>

                    {/* Available for Projects Box */}
                    <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-indigo-500/15 via-violet-500/10 to-transparent border border-indigo-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative overflow-hidden group shadow-2xl">
                      <div className="absolute top-0 right-0 -mt-8 -mr-8 w-36 h-36 bg-indigo-500/20 blur-3xl rounded-full transition-transform duration-700 group-hover:scale-150" />
                      
                      <div className="relative z-10 space-y-1">
                        <div className="flex items-center gap-2.5 text-indigo-300 text-xs font-bold tracking-widest uppercase font-mono">
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                          Available for New Projects
                        </div>
                        <p className="text-white font-medium text-sm font-sans">Ready to build something extraordinary?</p>
                        <p className="text-slate-400 text-xs">Let's connect and transform your vision into reality.</p>
                      </div>
                      
                      <a
                        href="https://www.instagram.com/yo_yo_kishwar_lucky?igsh=MWlieDNzbjY0bGJ3NA=="
                        target="_blank"
                        rel="noopener noreferrer"
                        className="relative z-10 inline-flex items-center justify-center gap-2.5 px-6 py-3.5 bg-gradient-to-r from-indigo-500 to-violet-500 text-white rounded-2xl text-xs font-bold hover:from-indigo-400 hover:to-violet-400 transition-all duration-300 shadow-[0_0_25px_rgba(99,102,241,0.35)] hover:shadow-[0_0_35px_rgba(99,102,241,0.5)] hover:scale-105 whitespace-nowrap"
                      >
                        <span>Connect on Instagram</span>
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}

