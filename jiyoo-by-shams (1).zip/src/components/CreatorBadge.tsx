import React, { Component, ReactNode, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, MeshDistortMaterial, Environment } from "@react-three/drei";
import * as THREE from "three";
import { motion } from "motion/react";
import { Zap } from "lucide-react";

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class CanvasErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: any) {
    console.warn("Canvas WebGL error safely caught for mobile/iOS:", error);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

function BadgeCore({ hovered }: { hovered: boolean }) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * (hovered ? 2 : 0.5);
      meshRef.current.rotation.x += delta * 0.2;
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
      <mesh ref={meshRef} scale={hovered ? 1.25 : 1}>
        <octahedronGeometry args={[1, 0]} />
        <MeshDistortMaterial
          color={hovered ? "#6366f1" : "#312e81"}
          envMapIntensity={2}
          clearcoat={1}
          clearcoatRoughness={0.1}
          metalness={0.9}
          roughness={0.1}
          distort={hovered ? 0.45 : 0.15}
          speed={hovered ? 5 : 1.5}
        />
      </mesh>
    </Float>
  );
}

export function CreatorBadge() {
  const [hovered, setHovered] = useState(false);

  return (
    <button
      onClick={() => document.dispatchEvent(new CustomEvent('open-creator-showcase'))}
      className="group relative flex items-center gap-3.5 py-2.5 px-4 rounded-2xl transition-all duration-500 hover:bg-white/10 border border-indigo-500/20 hover:border-indigo-500/50 text-left cursor-pointer bg-slate-900/40 backdrop-blur-md shadow-lg"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Developer Photo Avatar Ring with Glowing Edge */}
      <div className="relative w-12 h-12 shrink-0">
        <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-violet-400 rounded-full blur-xs opacity-75 group-hover:opacity-100 transition-opacity" />
        <img 
          src="/IMG-20260723-WA0099.jpg" 
          alt="Developer Kishwar" 
          className="relative w-full h-full object-cover object-top rounded-full border border-indigo-400/80 shadow-md"
        />
        <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-950" />
      </div>

      {/* 3D Crystal Interactive Canvas with WebGL Error Protection */}
      <div className="w-10 h-10 relative hidden sm:block shrink-0">
        <CanvasErrorBoundary
          fallback={
            <div className="w-full h-full rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center">
              <Zap className="w-5 h-5 text-indigo-400 animate-pulse" />
            </div>
          }
        >
          <Canvas 
            camera={{ position: [0, 0, 4], fov: 45 }} 
            className="pointer-events-none"
            gl={{ powerPreference: "low-power", antialias: false, failIfMajorPerformanceCaveat: false }}
          >
            <ambientLight intensity={0.6} />
            <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={2} castShadow />
            <Environment preset="city" />
            <BadgeCore hovered={hovered} />
          </Canvas>
        </CanvasErrorBoundary>
      </div>

      <div className="flex flex-col justify-center overflow-hidden">
        <motion.span 
          className="text-[9.5px] font-mono uppercase tracking-[0.22em] font-semibold text-indigo-400/90 mb-0.5 flex items-center gap-1.5"
          animate={{ color: hovered ? "#818cf8" : "#6366f1" }}
        >
          developed with <span className="text-indigo-400 text-xs inline-block animate-bounce">☕</span> by
        </motion.span>
        <span className="text-xs font-sans font-bold tracking-[0.2em] text-white group-hover:text-indigo-300 transition-colors duration-300 flex items-center gap-1.5">
          kishuu
          <motion.span 
            className="text-[10px] text-indigo-400 font-sans"
            initial={{ x: -4, opacity: 0.6 }}
            animate={{ x: hovered ? 2 : -4, opacity: hovered ? 1 : 0.6 }}
          >
            ↗
          </motion.span>
        </span>
      </div>
    </button>
  );
}
