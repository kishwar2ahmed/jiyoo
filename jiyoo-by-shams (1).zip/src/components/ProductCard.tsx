import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, ShoppingBag, Clock, ShieldCheck, Check, Minus, Plus } from 'lucide-react';
import { useCart } from '../CartContext';
import { Product } from '../types';

export function ProductCard({ 
  product, 
  wishlist, 
  toggleWishlist, 
  onProductClick 
}: { 
  key?: React.Key,
  product: Product, 
  wishlist: string[], 
  toggleWishlist: (id: string) => void,
  onProductClick?: (product: Product) => void
}) {
  const { addToCart, triggerFlyingItem } = useCart();
  const [selectedWeight, setSelectedWeight] = useState(product.weights?.[0]);
  const [selectedCleaning, setSelectedCleaning] = useState(product.cleaningOptions?.[0]);
  const [selectedCut, setSelectedCut] = useState(product.fishCuts?.[0]);
  const [cardQty, setCardQty] = useState(1);

  const currentPrice = selectedWeight ? selectedWeight.price : product.price;
  const currentUnit = selectedWeight ? selectedWeight.label : product.unit;

  const handleAddToCart = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation(); // Prevent opening the detail modal
    const rect = e.currentTarget.getBoundingClientRect();
    triggerFlyingItem({
      image: product.image,
      startX: rect.left + rect.width / 2,
      startY: rect.top + rect.height / 2,
    });
    
    let itemName = product.name;
    if (selectedCut) itemName += ` - ${selectedCut}`;
    if (selectedCleaning) itemName += ` (${selectedCleaning})`;

    addToCart({
      id: `${product.id}-${currentUnit}-${selectedCut || ''}-${selectedCleaning || ''}`,
      name: itemName,
      price: `₹${currentPrice}`,
      numericPrice: currentPrice,
      image: product.image,
      badge: currentUnit
    }, cardQty);
  };

  const incrementQty = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCardQty(prev => prev + 1);
  };

  const decrementQty = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (cardQty > 1) {
      setCardQty(prev => prev - 1);
    }
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      onClick={() => onProductClick?.(product)}
      className="group flex flex-col bg-brand-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-brand-gray-100 cursor-pointer h-full"
    >
      {/* Product Image Area */}
      <div className="relative aspect-[4/3] overflow-hidden bg-brand-gray-50">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          referrerPolicy="no-referrer"
          loading="lazy"
          decoding="async"
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/logo.jpg';
          }}
        />
        <div className="absolute inset-0 z-20 bg-gradient-to-t from-brand-black/40 via-transparent pointer-events-none" />
        
        {/* Freshness Badge */}
        {product.freshnessBadge && (
          <div className="absolute top-4 left-4 z-30">
            <span className="inline-flex items-center gap-1 bg-brand-white/95 backdrop-blur-md text-brand-black px-2.5 py-1 rounded-md text-[10px] font-semibold uppercase tracking-wider shadow-sm">
              <ShieldCheck className="w-3 h-3 text-green-500" />
              {product.freshnessBadge}
            </span>
          </div>
        )}

        {/* Wishlist Button */}
        <button 
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className="absolute top-4 right-4 z-30 w-9 h-9 bg-brand-white/80 backdrop-blur-md rounded-full flex items-center justify-center text-brand-black hover:bg-brand-white transition-colors shadow-sm"
        >
          <Heart 
            className="w-4 h-4 transition-transform active:scale-125" 
            fill={wishlist.includes(product.id) ? '#EF4444' : 'none'} 
            stroke={wishlist.includes(product.id) ? '#EF4444' : 'currentColor'}
          />
        </button>
      </div>

      {/* Product Information Card */}
      <div className="flex-1 flex flex-col p-5">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h4 className="text-base sm:text-lg font-semibold text-brand-black leading-tight mb-1 line-clamp-1 group-hover:text-brand-black/80 transition-colors">
              {product.name}
            </h4>
            <div className="flex items-center gap-2 text-[11px] text-brand-gray-400 font-medium">
              <span className="uppercase tracking-wider">{product.categoryId}</span>
              <span>•</span>
              <span className="inline-flex items-center gap-0.5 text-green-600 font-semibold uppercase">
                <Check className="w-2.5 h-2.5" /> In Stock
              </span>
            </div>
          </div>
        </div>
        
        {product.description && (
          <p className="text-xs sm:text-sm text-brand-gray-500 line-clamp-2 mb-4 leading-relaxed font-light">
            {product.description}
          </p>
        )}

        {/* Option selectors */}
        <div className="mt-auto space-y-4">
          <div className="space-y-2">
            {/* Weights */}
            {product.weights && product.weights.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-0.5">
                {product.weights.map((w) => (
                  <button
                    key={w.label}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedWeight(w);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[10px] sm:text-xs font-semibold whitespace-nowrap transition-colors ${
                      selectedWeight?.label === w.label 
                        ? 'bg-brand-black text-brand-white shadow-sm' 
                        : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100'
                    }`}
                  >
                    {w.label}
                  </button>
                ))}
              </div>
            )}

            {/* Fish Cuts */}
            {product.fishCuts && product.fishCuts.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-0.5">
                {product.fishCuts.map((c) => (
                  <button
                    key={c}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedCut(c);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[10px] sm:text-xs font-semibold whitespace-nowrap transition-colors ${
                      selectedCut === c 
                        ? 'bg-brand-black text-brand-white shadow-sm' 
                        : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}

            {/* Cleaning Options */}
            {product.cleaningOptions && product.cleaningOptions.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-0.5">
                {product.cleaningOptions.map((c) => (
                  <button
                    key={c}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedCleaning(c);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[10px] sm:text-xs font-semibold whitespace-nowrap transition-colors ${
                      selectedCleaning === c 
                        ? 'bg-brand-black text-brand-white shadow-sm' 
                        : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Action Row */}
          <div className="pt-3 border-t border-brand-gray-100 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[9px] text-brand-gray-400 uppercase font-semibold tracking-wider flex items-center gap-1">
                <Clock className="w-2.5 h-2.5" /> {product.deliveryEstimate || '60m'}
              </span>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-base sm:text-lg font-bold text-brand-black tracking-tight">₹{currentPrice * cardQty}</span>
                {product.discount && cardQty === 1 && (
                  <span className="text-[10px] text-brand-gray-400 line-through">
                    ₹{Math.round(currentPrice / (1 - product.discount / 100))}
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {/* Card Inline Quantity Selector */}
              <div className="bg-brand-gray-50/80 rounded-xl flex items-center border border-brand-gray-100 p-0.5 h-9 shrink-0">
                <button
                  onClick={decrementQty}
                  disabled={cardQty <= 1}
                  className="w-6 h-6 rounded-lg flex items-center justify-center text-brand-black hover:bg-brand-white disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-5 text-center font-bold text-brand-black text-xs">{cardQty}</span>
                <button
                  onClick={incrementQty}
                  className="w-6 h-6 rounded-lg flex items-center justify-center text-brand-black hover:bg-brand-white transition-all"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>

              {/* Add Button */}
              <button 
                onClick={handleAddToCart}
                className="bg-brand-black text-brand-white h-9 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1 hover:bg-brand-gray-900 shadow-sm transition-all active:scale-95"
              >
                <ShoppingBag className="w-3.5 h-3.5" /> Add
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
