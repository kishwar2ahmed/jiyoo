import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCart } from '../CartContext';
import { CATEGORIES, PRODUCTS as defaultProducts } from '../data';
import { ProductCard } from './ProductCard';
import { ProductDetailModal } from './ProductDetailModal';
import { Product } from '../types';
import { Search, Sparkles, ShoppingBag } from 'lucide-react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';

export function Storefront() {
  const [activeCategoryId, setActiveCategoryId] = useState(CATEGORIES[0].id);
  const [activeSubcategoryId, setActiveSubcategoryId] = useState<string | null>(CATEGORIES[0].items?.[0]?.id ?? null);
  const [activeSubSubcategoryId, setActiveSubSubcategoryId] = useState<string | null>(null);
  
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [dbProducts, setDbProducts] = useState<Product[]>([]);
  const [isProductsLoading, setIsProductsLoading] = useState(true);
  
  // Product Detail Modal state
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const { searchQuery } = useCart();

  useEffect(() => {
    async function loadProducts() {
      try {
        const snap = await getDocs(collection(db, 'products'));
        const loaded: Product[] = [];
        snap.forEach(doc => {
          loaded.push(doc.data() as Product);
        });
        if (loaded.length > 0) {
          setDbProducts(loaded);
        } else {
          setDbProducts(defaultProducts);
        }
      } catch (err) {
        console.error("Failed to load products from Firestore, using defaults", err);
        setDbProducts(defaultProducts);
      } finally {
        setIsProductsLoading(false);
      }
    }
    loadProducts();
  }, []);

  const currentProducts = isProductsLoading ? defaultProducts : dbProducts;

  // Loading simulation for beautiful skeleton displays
  const triggerLoading = () => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  };

  const handleCategoryChange = (categoryId: string) => {
    triggerLoading();
    setActiveCategoryId(categoryId);
    const category = CATEGORIES.find(c => c.id === categoryId);
    
    if (category && category.items && category.items.length > 0) {
      const firstSub = category.items[0];
      setActiveSubcategoryId(firstSub.id);
      
      if (firstSub.items && firstSub.items.length > 0) {
        setActiveSubSubcategoryId(firstSub.items[0].id);
      } else {
        setActiveSubSubcategoryId(null);
      }
    } else {
      setActiveSubcategoryId(null);
      setActiveSubSubcategoryId(null);
    }
  };

  const handleSubcategoryChange = (subcategoryId: string) => {
    triggerLoading();
    setActiveSubcategoryId(subcategoryId);
    const category = CATEGORIES.find(c => c.id === activeCategoryId);
    const subcategory = category?.items?.find(s => s.id === subcategoryId);
    
    if (subcategory && subcategory.items && subcategory.items.length > 0) {
      setActiveSubSubcategoryId(subcategory.items[0].id);
    } else {
      setActiveSubSubcategoryId(null);
    }
  };

  const handleSubSubcategoryChange = (subSubcategoryId: string) => {
    triggerLoading();
    setActiveSubSubcategoryId(subSubcategoryId);
  };

  const toggleWishlist = (productId: string) => {
    setWishlist(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const activeCategory = CATEGORIES.find(c => c.id === activeCategoryId);
  const activeSubcategory = activeCategory?.items?.find(s => s.id === activeSubcategoryId);

  const displayedProducts = useMemo(() => {
    if (searchQuery) {
      const lowerQuery = searchQuery.toLowerCase();
      return currentProducts.filter(p => 
        p.name.toLowerCase().includes(lowerQuery) || 
        p.description?.toLowerCase().includes(lowerQuery) ||
        p.tags?.some(tag => tag.toLowerCase().includes(lowerQuery))
      );
    }

    return currentProducts.filter(p => {
      if (p.categoryId !== activeCategoryId) return false;
      if (activeSubcategoryId && p.subcategoryId !== activeSubcategoryId) return false;
      if (activeSubSubcategoryId && p.subSubcategoryId !== activeSubSubcategoryId) return false;
      return true;
    });
  }, [activeCategoryId, activeSubcategoryId, activeSubSubcategoryId, searchQuery, currentProducts]);

  useEffect(() => {
    const handleSelectCategory = (e: CustomEvent<string | { categoryId: string }>) => {
      const categoryId = typeof e.detail === 'string' ? e.detail : e.detail?.categoryId;
      if (categoryId) {
        handleCategoryChange(categoryId);
        document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
      }
    };
    window.addEventListener('select-category' as any, handleSelectCategory);
    return () => window.removeEventListener('select-category' as any, handleSelectCategory);
  }, []);

  return (
    <div id="products" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative min-h-[800px]">
      
      {!searchQuery && (
        <div className="flex flex-col gap-8 mb-12 relative z-10">
          {/* Main Categories - Sleek Pills */}
          <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide snap-x">
            {CATEGORIES.map(category => {
              const isActive = activeCategoryId === category.id;
              return (
                <button
                  key={category.id}
                  onClick={() => handleCategoryChange(category.id)}
                  className={`relative px-6 py-3 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-300 snap-center
                    ${isActive 
                      ? 'text-brand-black shadow-lg shadow-brand-gold/20' 
                      : 'text-brand-gray-500 hover:text-brand-gray-900 bg-brand-white border border-brand-gray-200 hover:border-brand-gray-300'
                    }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeCategory"
                      className="absolute inset-0 bg-gradient-to-r from-brand-gold to-yellow-400 rounded-full"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  <span className="relative z-10">{category.label}</span>
                </button>
              );
            })}
          </div>

          {/* Subcategories - Refined Underline Tabs */}
          {activeCategory?.items && (
            <div className="flex gap-8 overflow-x-auto pb-2 scrollbar-hide border-b border-brand-gray-200">
              {activeCategory.items.map(sub => {
                const isActive = activeSubcategoryId === sub.id;
                return (
                  <button
                    key={sub.id}
                    onClick={() => handleSubcategoryChange(sub.id)}
                    className={`relative pb-4 text-sm font-medium whitespace-nowrap transition-colors duration-300
                      ${isActive ? 'text-brand-gray-900' : 'text-brand-gray-400 hover:text-brand-gray-600'}`}
                  >
                    {sub.label}
                    {isActive && (
                      <motion.div
                        layoutId="activeSubcategory"
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-gray-900"
                        transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* Sub-Subcategories - Minimalist Chips */}
          {activeSubcategory?.items && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-2 overflow-x-auto scrollbar-hide"
            >
              {activeSubcategory.items.map(subsub => {
                const isActive = activeSubSubcategoryId === subsub.id;
                return (
                  <button
                    key={subsub.id}
                    onClick={() => handleSubSubcategoryChange(subsub.id)}
                    className={`px-4 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all duration-300
                      ${isActive 
                        ? 'bg-brand-gray-900 text-brand-white shadow-md' 
                        : 'bg-brand-gray-100 text-brand-gray-500 hover:bg-brand-gray-200 hover:text-brand-gray-900'
                      }`}
                  >
                    {subsub.label}
                  </button>
                );
              })}
            </motion.div>
          )}
        </div>
      )}

      {/* Search Header */}
      {searchQuery && (
        <div className="mb-12 border-b border-brand-gray-200 pb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-brand-gray-100 flex items-center justify-center">
              <Search className="w-5 h-5 text-brand-gray-600" />
            </div>
            <div>
              <h2 className="text-2xl font-serif text-brand-black">Search Results</h2>
              <p className="text-brand-gray-500 text-sm mt-1">
                Found {displayedProducts.length} items for "{searchQuery}"
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Products Grid */}
      <div className="relative min-h-[400px]">
        {isLoading || isProductsLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-10">
            {[1, 2, 3, 4].map(n => (
              <div key={n} className="flex flex-col gap-4 animate-pulse">
                <div className="w-full aspect-[4/5] bg-brand-gray-100 rounded-2xl" />
                <div className="space-y-2">
                  <div className="w-1/3 h-3 bg-brand-gray-200 rounded" />
                  <div className="w-2/3 h-4 bg-brand-gray-200 rounded" />
                  <div className="w-1/4 h-5 bg-brand-gray-200 rounded mt-2" />
                </div>
              </div>
            ))}
          </div>
        ) : displayedProducts.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute inset-0 flex flex-col items-center justify-center text-center py-20 bg-brand-gray-50 rounded-3xl border border-brand-gray-200"
          >
            <div className="w-24 h-24 rounded-full bg-brand-white shadow-xl shadow-brand-gray-200/50 flex items-center justify-center mb-6">
              <Search className="w-10 h-10 text-brand-gray-400" />
            </div>
            <h3 className="text-2xl font-serif text-brand-black mb-2">No items found</h3>
            <p className="text-brand-gray-500 max-w-md mx-auto">
              We couldn't find any products matching your current selection. 
              Try browsing a different category or refining your search.
            </p>
          </motion.div>
        ) : (
          <motion.div 
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-10"
          >
            <AnimatePresence mode="popLayout">
              {displayedProducts.map((product) => (
                <ProductCard 
                  key={product.id}
                  product={product}
                  wishlist={wishlist}
                  toggleWishlist={toggleWishlist}
                  onProductClick={() => setSelectedProduct(product)}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      <ProductDetailModal
        product={selectedProduct}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        wishlist={wishlist}
        toggleWishlist={toggleWishlist}
      />
    </div>
  );
}
