import { CreatorBadge } from "./CreatorBadge";
import { PremiumSocialBar, SOCIAL_LINKS } from "./SocialIcons";
import { Sparkles } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-brand-black text-brand-white py-20 relative overflow-hidden border-t border-white/5">
      {/* Subtle background glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,_rgba(16,185,129,0.08)_0%,_transparent_60%)] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Premium Live Social & Customer Care Bar */}
        <PremiumSocialBar />

        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 lg:gap-24 pt-10 border-t border-white/10">
          <div className="md:col-span-2">
            <span className="font-serif text-3xl font-bold tracking-tight mb-4 block bg-gradient-to-r from-emerald-200 via-teal-300 to-emerald-400 bg-clip-text text-transparent">
              JIYOO
            </span>
            <p className="text-brand-gray-400 font-light max-w-sm leading-relaxed text-sm">
              The world's finest ingredients, curated for the uncompromising palate. Delivered with precision and elegance.
            </p>

            {/* Quick About Badge & Social Badges Row */}
            <div className="flex flex-wrap items-center gap-3 mt-6">
              <button 
                onClick={() => document.dispatchEvent(new CustomEvent('open-about'))}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/20 text-white text-xs font-semibold hover:bg-white/20 hover:scale-105 transition-all shadow-xs cursor-pointer"
                title="About JIYOO"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>About JIYOO</span>
              </button>

              {SOCIAL_LINKS.map((link) => (
                <a
                  key={link.id}
                  href={link.href}
                  target={link.href.startsWith('http') ? '_blank' : '_self'}
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 flex items-center justify-center text-white/80 hover:text-white transition-all duration-300 hover:scale-110 shadow-lg"
                  aria-label={link.label}
                  title={`${link.label}: ${link.handle}`}
                >
                  {link.icon({ className: "w-4 h-4" })}
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-xs uppercase tracking-widest text-emerald-400 font-semibold mb-6">Explore JIYOO</h4>
            <ul className="space-y-3.5">
              <li>
                <button 
                  onClick={() => document.dispatchEvent(new CustomEvent('open-about'))} 
                  className="text-sm font-medium text-brand-gray-200 hover:text-emerald-400 transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  <span>About Us</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => window.dispatchEvent(new CustomEvent('select-category', { detail: 'fruits' }))}
                  className="text-sm font-light text-brand-gray-400 hover:text-emerald-400 transition-colors block pl-3.5 cursor-pointer text-left"
                >
                  Premium Fruits
                </button>
              </li>
              <li>
                <button 
                  onClick={() => window.dispatchEvent(new CustomEvent('select-category', { detail: 'vegetables' }))}
                  className="text-sm font-light text-brand-gray-400 hover:text-emerald-400 transition-colors block pl-3.5 cursor-pointer text-left"
                >
                  Exotic Vegetables
                </button>
              </li>
              <li>
                <button 
                  onClick={() => window.dispatchEvent(new CustomEvent('select-category', { detail: 'meat' }))}
                  className="text-sm font-light text-brand-gray-400 hover:text-emerald-400 transition-colors block pl-3.5 cursor-pointer text-left"
                >
                  Quality Meats
                </button>
              </li>
              <li>
                <button 
                  onClick={() => window.dispatchEvent(new CustomEvent('select-category', { detail: 'smoothies' }))}
                  className="text-sm font-light text-brand-gray-400 hover:text-emerald-400 transition-colors block pl-3.5 cursor-pointer text-left"
                >
                  Signature Smoothies
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs uppercase tracking-widest text-emerald-400 font-semibold mb-6">Customer Care</h4>
            <ul className="space-y-3.5">
              {SOCIAL_LINKS.map((link) => (
                <li key={link.id}>
                  <a
                    href={link.href}
                    target={link.href.startsWith('http') ? '_blank' : '_self'}
                    rel="noopener noreferrer"
                    className="group text-xs font-light text-brand-gray-300 hover:text-white transition-colors flex items-center gap-2.5"
                  >
                    <span className="w-6 h-6 rounded-lg bg-white/5 group-hover:bg-emerald-500/20 text-brand-gray-400 group-hover:text-emerald-400 flex items-center justify-center transition-colors">
                      {link.icon({ className: "w-3.5 h-3.5" })}
                    </span>
                    <span className="truncate">{link.label}: <strong className="font-mono text-white/90 group-hover:text-emerald-300">{link.handle}</strong></span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="mt-20 pt-8 border-t border-brand-gray-800 flex flex-col md:flex-row items-center justify-between gap-8 relative">
          <div className="flex flex-col gap-3 w-full md:w-auto text-center md:text-left order-3 md:order-1">
            <p className="text-xs text-brand-gray-500 font-light">&copy; {new Date().getFullYear()} JIYOO Premium Products. All rights reserved.</p>
          </div>
          
          {/* Centered 3D Creator Badge */}
          <div className="flex-shrink-0 md:absolute md:left-1/2 md:-translate-x-1/2 order-1 md:order-2">
            <CreatorBadge />
          </div>

          <div className="flex items-center gap-4 w-full md:w-auto justify-center md:justify-end order-2 md:order-3">
            {SOCIAL_LINKS.map((link) => (
              <a
                key={link.id}
                href={link.href}
                target={link.href.startsWith('http') ? '_blank' : '_self'}
                rel="noopener noreferrer"
                className="text-brand-gray-500 hover:text-emerald-400 transition-colors p-1.5 hover:scale-110 transform"
                aria-label={link.label}
              >
                {link.icon({ className: "w-4 h-4" })}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
