import React, { useState, useEffect } from "react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Storefront } from "./components/Storefront";
import { Footer } from "./components/Footer";
import { FlyingItemsLayer } from "./components/FlyingItemsLayer";
import { SplashScreen } from "./components/SplashScreen";
import { AuthModal } from "./components/AuthModal";
import { CartModal } from "./components/CartModal";
import { AdminPanel } from "./components/AdminPanel";
import { AboutModal } from "./components/AboutModal";
import { CreatorShowcase } from "./components/CreatorShowcase";
import { useCart, CartProvider } from "./CartContext";
import { motion, AnimatePresence } from "motion/react";

function AppContent() {
  const { user, isAuthLoading, addedItemToast, setAddedItemToast } = useCart();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [showSplash, setShowSplash] = useState(false);
  const [needsAuth, setNeedsAuth] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isShowcaseOpen, setIsShowcaseOpen] = useState(false);

  
  useEffect(() => {
    const handleOpenShowcase = () => setIsShowcaseOpen(true);
    document.addEventListener('open-creator-showcase', handleOpenShowcase);
    return () => document.removeEventListener('open-creator-showcase', handleOpenShowcase);
  }, []);

  useEffect(() => {
    const handleOpenAbout = () => setIsAboutOpen(true);
    document.addEventListener('open-about', handleOpenAbout);
    return () => document.removeEventListener('open-about', handleOpenAbout);
  }, []);

  useEffect(() => {
    // Check if URL has #admin
    const checkHash = () => {
      if (window.location.hash === '#admin') {
        setIsAdminOpen(true);
      }
    };
    checkHash();
    window.addEventListener('hashchange', checkHash);
    return () => window.removeEventListener('hashchange', checkHash);
  }, []);

  useEffect(() => {
    if (addedItemToast) {
      const timer = setTimeout(() => {
        setAddedItemToast(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [addedItemToast, setAddedItemToast]);

  if (isAuthLoading || showSplash) {
    return (
      <div className="min-h-screen bg-[#f8f6f0]">
        {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}
      </div>
    );
  }

  return (
    <div className="bg-brand-white min-h-screen text-brand-black font-sans selection:bg-brand-gray-900 selection:text-brand-white overflow-x-hidden">
      {isAdminOpen && <AdminPanel onClose={() => {
        setIsAdminOpen(false);
        window.history.pushState("", document.title, window.location.pathname + window.location.search);
      }} />}
      
      <Navbar
        onAboutClick={() => setIsAboutOpen(true)}
        onUserClick={() => setIsAuthOpen(true)}
        onCartClick={() => setIsCartOpen(true)}
      />
      
      <AuthModal 
        isOpen={isAuthOpen || needsAuth} 
        onClose={() => {
          setIsAuthOpen(false);
          setNeedsAuth(false);
        }} 
      />
      
      <CartModal isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      <AboutModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />
      <CreatorShowcase isOpen={isShowcaseOpen} onClose={() => setIsShowcaseOpen(false)} />

      <main className="pt-24 pb-16">
        <Hero />
        <Storefront />
      </main>

      <Footer />
      <FlyingItemsLayer />

      <AnimatePresence>
        {addedItemToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", damping: 25, stiffness: 250 }}
            className="fixed bottom-6 right-6 z-50 bg-brand-gray-900 text-brand-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 max-w-sm border border-brand-gray-800"
          >
            <div className="w-12 h-12 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0 text-amber-400">
              <svg className="w-6 h-6 stroke-current fill-none" viewBox="0 0 24 24" strokeWidth="1.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007z" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider text-brand-gray-500 font-medium">
                Added to Bag
              </p>
              <p className="text-xs font-semibold truncate text-brand-white mt-0.5">
                {addedItemToast.name}
              </p>
            </div>
            <button
              onClick={() => setAddedItemToast(null)}
              className="text-brand-gray-500 hover:text-brand-white transition-colors p-1 shrink-0"
            >
              <svg
                className="w-4 h-4 fill-none stroke-current"
                strokeWidth={2}
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <AppContent />
    </CartProvider>
  );
}
