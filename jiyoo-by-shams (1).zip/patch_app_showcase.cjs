const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

// Add import
code = code.replace('import { AboutModal } from "./components/AboutModal";', 'import { AboutModal } from "./components/AboutModal";\nimport { CreatorShowcase } from "./components/CreatorShowcase";');

// Add state
const statePattern = 'const [isAboutOpen, setIsAboutOpen] = useState(false);';
code = code.replace(statePattern, `${statePattern}\n  const [isShowcaseOpen, setIsShowcaseOpen] = useState(false);`);

// Add event listener
const eventListener = `
  useEffect(() => {
    const handleOpenShowcase = () => setIsShowcaseOpen(true);
    document.addEventListener('open-creator-showcase', handleOpenShowcase);
    return () => document.removeEventListener('open-creator-showcase', handleOpenShowcase);
  }, []);
`;
code = code.replace('useEffect(() => {', `${eventListener}\n  useEffect(() => {`);

// Add component
code = code.replace('<AboutModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />', '<AboutModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />\n      <CreatorShowcase isOpen={isShowcaseOpen} onClose={() => setIsShowcaseOpen(false)} />');

fs.writeFileSync('src/App.tsx', code);
