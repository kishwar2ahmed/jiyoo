const fs = require('fs');
let code = fs.readFileSync('src/components/CartModal.tsx', 'utf8');

const target = `            // Verify payment
            const verifyRes = await fetch('/api/razorpay/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature
              })
            });
            const verifyData = await verifyRes.json();
            
            if (!verifyData.success) {
              alert('Payment verification failed!');
              setIsProcessing(false);
              return;
            }

            await addDoc(collection(db, 'orders'), {
              userId: user?.id || 'guest',
              amount: cartTotal,
              status: 'completed',
              items: items.map(i => ({ 
                 id: i.id, 
                 name: i.name, 
                 quantity: i.quantity, 
                 price: i.numericPrice, 
                 image: i.image 
               })),
              shippingDetails: { name, phone, address },
              razorpayPaymentId: response.razorpay_payment_id || null,
              razorpayOrderId: response.razorpay_order_id || null,
              createdAt: serverTimestamp(),
            });`;

const replacement = `            // Prepare order data for secure backend creation
            const orderData = {
              userId: user?.id || 'guest',
              amount: cartTotal,
              items: items.map(i => ({ 
                 id: i.id, 
                 name: i.name, 
                 quantity: i.quantity, 
                 price: i.numericPrice, 
                 image: i.image 
               })),
              shippingDetails: { name, phone, address }
            };

            // Verify payment
            const verifyRes = await fetch('/api/razorpay/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
                orderData
              })
            });
            const verifyData = await verifyRes.json();
            
            if (!verifyData.success) {
              setFormErrors({ ...formErrors, address: 'Payment verification failed: ' + verifyData.error });
              setIsProcessing(false);
              return;
            }`;

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/CartModal.tsx', code);
  console.log('CartModal updated successfully');
} else {
  console.log('Target not found in CartModal');
}
