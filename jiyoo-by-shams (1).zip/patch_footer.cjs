const fs = require('fs');
let code = fs.readFileSync('src/components/Footer.tsx', 'utf8');

code = code.replace(`<h4 className="text-xs uppercase tracking-widest text-brand-gold font-semibold mb-6">Collections</h4>
            <ul className="space-y-4">
              <li><button onClick={() => document.dispatchEvent(new CustomEvent('open-about'))} className="text-sm font-light text-brand-gray-300 hover:text-amber-400 transition-colors">About JIYOO</button></li>
            <ul className="space-y-4">`, `<h4 className="text-xs uppercase tracking-widest text-brand-gold font-semibold mb-6">Collections</h4>
            <ul className="space-y-4">
              <li><button onClick={() => document.dispatchEvent(new CustomEvent('open-about'))} className="text-sm font-light text-brand-gray-300 hover:text-amber-400 transition-colors">About JIYOO</button></li>`);

fs.writeFileSync('src/components/Footer.tsx', code);
