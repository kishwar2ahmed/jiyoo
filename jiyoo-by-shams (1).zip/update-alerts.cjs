const fs = require('fs');
let code = fs.readFileSync('src/components/CartModal.tsx', 'utf8');

code = code.replace(
  "alert('Razorpay SDK failed to load. Check your connection.');",
  "setFormErrors({ ...formErrors, address: 'Razorpay SDK failed to load. Check your connection.' });"
);

code = code.replace(
  "alert('Failed to create order: ' + data.error);",
  "setFormErrors({ ...formErrors, address: 'Failed to create order: ' + data.error });"
);

code = code.replace(
  "alert(`Payment failed! Reason: ${response.error.description}`);",
  "setFormErrors({ ...formErrors, address: `Payment failed! Reason: ${response.error.description}` });"
);

code = code.replace(
  "alert('Error starting Razorpay checkout: ' + err.message);",
  "setFormErrors({ ...formErrors, address: 'Error starting Razorpay checkout: ' + err.message });"
);

fs.writeFileSync('src/components/CartModal.tsx', code);
console.log('Replaced alerts successfully');
