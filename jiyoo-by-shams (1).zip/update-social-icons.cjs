const fs = require('fs');
let code = fs.readFileSync('src/components/SocialIcons.tsx', 'utf8');

const regexInstagram = /\s*{\s*id: 'instagram'[\s\S]*?accentColor: '#E1306C'\s*},/;
code = code.replace(regexInstagram, '');

code = code.replace('const instagramIcon = SOCIAL_LINKS[1].icon;', 'const phoneIcon = SOCIAL_LINKS[1].icon;');

const regexInstaButton = /{\/\* Instagram Quick Floating Button \*\/}[\s\S]*?<\/span>\n\s*<\/motion\.a>/;

const phoneButton = `{/* Phone Quick Floating Button */}
      <motion.a
        href="tel:+917899744335"
        whileHover={{ scale: 1.1, y: -2 }}
        whileTap={{ scale: 0.9 }}
        className="group relative flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-600 text-white shadow-2xl shadow-amber-500/30 border border-white/20"
        aria-label="Call Us"
      >
        {phoneIcon({ className: "w-5 h-5" })}
        
        {/* Hover Tooltip */}
        <span className="absolute right-14 px-3 py-1.5 rounded-xl bg-zinc-900/90 text-white text-xs font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none shadow-xl border border-white/10 backdrop-blur-md">
          Call Now
        </span>
      </motion.a>`;

code = code.replace(regexInstaButton, phoneButton);

fs.writeFileSync('src/components/SocialIcons.tsx', code);
console.log('SocialIcons updated');
