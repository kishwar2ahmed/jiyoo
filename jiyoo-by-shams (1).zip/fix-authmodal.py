import re

with open('src/components/AuthModal.tsx', 'r') as f:
    content = f.read()

# remove motion.div dynamic lighting
content = re.sub(r'<motion\.div\s*className="absolute inset-0 bg-\[radial-gradient[^>]*animate=\{phase\}[\s\S]*?<\/motion\.div>', '', content)

# remove CinematicCharacter wrapper
content = re.sub(r'<motion\.div[\s\S]*?<CinematicCharacter phase=\{phase\} \/>\s*<\/motion\.div>', '', content)

# replace card wrapper
card_regex = r'<motion\.div\s*initial="enter"\s*animate=\{phase\}\s*variants=\{[\s\S]*?\}\}\s*className="relative w-full'
new_card = r'''<motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="relative w-full'''
content = re.sub(card_regex, new_card, content)

# remove phase conditions on pointer events
content = re.sub(r'phase !== "idle" && phase !== "release" && phase !== "vanish"\s*\?\s*"pointer-events-none select-none"\s*:\s*""', '""', content)

# remove hand grips entirely
content = re.sub(r'\{\(phase === "grab" \|\| phase === "pull"\) && \([\s\S]*?<\/motion\.div>\n\s*\)\}', '', content)

# check for any other remaining "phase"
with open('src/components/AuthModal.tsx', 'w') as f:
    f.write(content)

print("fixed python")
