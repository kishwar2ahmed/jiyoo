const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const oldVerify = `  app.post('/api/razorpay/verify', (req, res) => {
    try {
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
      const secret = process.env.RAZORPAY_KEY_SECRET;

      if (!secret) {
        return res.status(500).json({ success: false, error: 'Razorpay secret not configured on the server' });
      }

      const generated_signature = crypto
        .createHmac('sha256', secret)
        .update(razorpay_order_id + "|" + razorpay_payment_id)
        .digest('hex');

      if (generated_signature === razorpay_signature) {
        res.json({ success: true, message: "Payment verified successfully" });
      } else {
        res.status(400).json({ success: false, error: "Invalid signature" });
      }
    } catch (error: any) {
      console.error('Failed to verify Razorpay signature:', error);
      res.status(500).json({ success: false, error: error.message || 'Verification failed' });
    }
  });`;

const newVerify = `  // Import admin if needed or use mock for local AI studio
  app.post('/api/razorpay/verify', async (req, res) => {
    try {
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderData } = req.body;
      const secret = process.env.RAZORPAY_KEY_SECRET;

      if (!secret) {
        return res.status(500).json({ success: false, error: 'Razorpay secret not configured on the server' });
      }

      const generated_signature = crypto
        .createHmac('sha256', secret)
        .update(razorpay_order_id + "|" + razorpay_payment_id)
        .digest('hex');

      if (generated_signature === razorpay_signature) {
        // Here we could securely save to firestore. 
        // For AI Studio local preview without Admin SDK credentials, 
        // we'll instruct the frontend to save it OR we can initialize a mock or use REST.
        // We will just return success so frontend can handle it if Admin SDK is absent.
        res.json({ success: true, message: "Payment verified successfully" });
      } else {
        res.status(400).json({ success: false, error: "Invalid signature" });
      }
    } catch (error: any) {
      console.error('Failed to verify Razorpay signature:', error);
      res.status(500).json({ success: false, error: error.message || 'Verification failed' });
    }
  });`;

if (code.includes(oldVerify)) {
  code = code.replace(oldVerify, newVerify);
  fs.writeFileSync('server.ts', code);
  console.log('Updated server.ts verify endpoint');
} else {
  console.log('Could not find old verify endpoint in server.ts');
}
