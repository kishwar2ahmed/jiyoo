const fs = require('fs');

const content = `import { Handler } from '@netlify/functions';
import crypto from 'crypto';
import { getApps, initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

// Initialize Firebase Admin for secure server-side Firestore writes
if (!getApps().length) {
  try {
    const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT;
    if (serviceAccountJson) {
      initializeApp({
        credential: cert(JSON.parse(serviceAccountJson))
      });
    } else {
      console.warn("FIREBASE_SERVICE_ACCOUNT is not set. Firestore writes will fail if relying on Admin SDK.");
      initializeApp(); // Fallback for some default environments
    }
  } catch (error) {
    console.error("Firebase Admin Initialization Error:", error);
  }
}

export const handler: Handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderData } = body;
    const secret = process.env.RAZORPAY_KEY_SECRET;

    if (!secret) {
      return { statusCode: 500, body: JSON.stringify({ success: false, error: 'Razorpay secret not configured' }) };
    }

    const generated_signature = crypto
      .createHmac('sha256', secret)
      .update(razorpay_order_id + "|" + razorpay_payment_id)
      .digest('hex');

    if (generated_signature !== razorpay_signature) {
      return { statusCode: 400, body: JSON.stringify({ success: false, error: 'Invalid signature' }) };
    }

    // Payment is verified. Now securely write to Firestore using Admin SDK.
    if (orderData && getApps().length > 0) {
      try {
        const db = getFirestore();
        const finalOrder = {
          ...orderData,
          razorpayPaymentId: razorpay_payment_id,
          razorpayOrderId: razorpay_order_id,
          createdAt: FieldValue.serverTimestamp(),
          status: 'completed'
        };
        
        await db.collection('orders').add(finalOrder);
        console.log("Order securely saved to Firestore.");
      } catch (dbError: any) {
        console.error("Error saving order to Firestore:", dbError);
        // We still return success for the payment, but warn about DB.
        return { statusCode: 200, body: JSON.stringify({ success: true, message: "Payment verified successfully, but failed to save order.", error: dbError.message }) };
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, message: 'Payment verified successfully' })
    };
  } catch (error: any) {
    console.error('Failed to verify Razorpay signature:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: error.message || 'Verification failed' })
    };
  }
};
`;

fs.writeFileSync('netlify/functions/verify-payment.ts', content);
console.log('Updated verify-payment.ts');
