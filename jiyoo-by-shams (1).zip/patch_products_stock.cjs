const fs = require('fs');
let code = fs.readFileSync('src/types.ts', 'utf8');
if (!code.includes('stock?: number;')) {
  code = code.replace('price: number;', 'price: number;\n  stock?: number;');
  fs.writeFileSync('src/types.ts', code);
}
