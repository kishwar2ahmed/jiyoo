const fs = require('fs');

const imports = `import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Loader2, LogOut, Check, Mail, Lock, ShoppingBag, User, Sparkles } from "lucide-react";
import { useCart } from "../CartContext";
import { auth, googleProvider, db } from "../lib/firebase";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile, signInWithPopup } from "firebase/auth";
import { collection, query, where, getDocs, doc, setDoc } from "firebase/firestore";
import { Order } from "../types";

export function AuthModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { user, logoutUser } = useCart();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [step, setStep] = useState<"login" | "success">("login");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");

  useEffect(() => {
    if (isOpen) {
      setError(null);
      setStep("login");
      setMode("signin");
      setIsLoading(false);
    }
  }, [isOpen]);

  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      setStep("success");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      if (err.code === "auth/user-not-found" || err.code === "auth/wrong-password" || err.code === "auth/invalid-credential") {
        setError("Invalid email or password. Don't have an account? Click 'Create Account' above.");
      } else {
        setError(err.message || "Failed to sign in. Please check your credentials.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      setError("Please enter your full name");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(userCredential.user, {
        displayName: fullName
      });
      setStep("success");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      if (err.code === "auth/email-already-in-use") {
        setError("An account with this email already exists.");
      } else if (err.code === "auth/weak-password") {
        setError("Password should be at least 6 characters.");
      } else {
        setError(err.message || "Failed to create account. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
      setStep("success");
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      setError(err.message || "Failed to sign in with Google.");
    } finally {
      setIsLoading(false);
    }
  };

`;

const currentCode = fs.readFileSync('src/components/AuthModal.tsx', 'utf8');

// The rest of the modal code starts from '  return (\n    <AnimatePresence>'
const renderIndex = currentCode.indexOf('<AnimatePresence>');
let renderPart = currentCode.substring(renderIndex);
if (!renderPart.startsWith('return (')) {
  renderPart = '  return (\n    ' + renderPart;
}

fs.writeFileSync('src/components/AuthModal.tsx', imports + renderPart);
console.log('Restored AuthModal correctly');
