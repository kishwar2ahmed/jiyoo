const fs = require('fs');
let code = fs.readFileSync('src/components/AdminPanel.tsx', 'utf8');

code = code.replace(
  "const [saving, setSaving] = useState<string | null>(null);",
  "const [saving, setSaving] = useState<string | null>(null);\n  const [error, setError] = useState<string | null>(null);"
);

code = code.replace(
  "alert('Failed to save. Ensure you have the right permissions.');",
  "setError('Failed to save. Ensure you have the right permissions.');\n      setTimeout(() => setError(null), 3000);"
);

const errorElement = `{error && (<div className="fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded z-50">{error}</div>)}`;
code = code.replace(
  '<div className="fixed inset-0 z-[100] bg-brand-white overflow-y-auto pb-20">',
  `<div className="fixed inset-0 z-[100] bg-brand-white overflow-y-auto pb-20">\n      ${errorElement}`
);

fs.writeFileSync('src/components/AdminPanel.tsx', code);
console.log('AdminPanel alert replaced successfully');
