import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import Razorpay from 'razorpay';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

// Initialize Razorpay
let razorpay: Razorpay | null = null;
if (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
  razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  });
}

// Set up rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per `window` (here, per 15 minutes)
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  message: 'Too many requests from this IP, please try again after 15 minutes',
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Security Middlewares
  app.use(helmet({
    contentSecurityPolicy: false, // Disable CSP for Vite dev server compatibility (or configure it properly)
  }));
  app.use(express.json({ limit: '10kb' })); // Limit body size to 10kb
  app.use(cookieParser());
  
  // Apply rate limiter to all API routes
  app.use('/api/', apiLimiter);

  // === Payment Endpoints ===
  
  // Create Razorpay Order
  app.post('/api/razorpay/order', async (req, res) => {
    try {
      if (!razorpay) {
        return res.status(500).json({ error: 'Razorpay is not configured on the server. Please add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to your environment variables.' });
      }

      const { amount } = req.body;
      
      if (!amount || isNaN(amount)) {
        return res.status(400).json({ error: 'Valid amount is required' });
      }

      const options = {
        amount: Math.round(amount * 100), // amount in smallest currency unit (paise)
        currency: 'INR',
        receipt: `receipt_order_${crypto.randomBytes(4).toString('hex')}`
      };

      const order = await razorpay.orders.create(options);
      
      res.json({
        success: true,
        order,
        key_id: process.env.RAZORPAY_KEY_ID // send public key id to frontend
      });
    } catch (error: any) {
      console.error('Failed to create Razorpay order:', error);
      res.status(500).json({ error: error.message || 'Something went wrong while creating order' });
    }
  });

  // Import admin if needed or use mock for local AI studio
  app.post('/api/razorpay/verify', async (req, res) => {
    try {
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderData } = req.body;
      const secret = process.env.RAZORPAY_KEY_SECRET;

      if (!secret) {
        return res.status(500).json({ success: false, error: 'Razorpay secret not configured on the server' });
      }

      const generated_signature = crypto
        .createHmac('sha256', secret)
        .update(razorpay_order_id + "|" + razorpay_payment_id)
        .digest('hex');

      if (generated_signature === razorpay_signature) {
        // Here we could securely save to firestore. 
        // For AI Studio local preview without Admin SDK credentials, 
        // we'll instruct the frontend to save it OR we can initialize a mock or use REST.
        // We will just return success so frontend can handle it if Admin SDK is absent.
        res.json({ success: true, message: "Payment verified successfully" });
      } else {
        res.status(400).json({ success: false, error: "Invalid signature" });
      }
    } catch (error: any) {
      console.error('Failed to verify Razorpay signature:', error);
      res.status(500).json({ success: false, error: error.message || 'Verification failed' });
    }
  });

  // === Vite Middleware for Development ===
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
