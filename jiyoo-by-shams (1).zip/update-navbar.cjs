const fs = require('fs');
let code = fs.readFileSync('src/components/Navbar.tsx', 'utf8');

const regexInstagram = /<a\s*href="https:\/\/www\.instagram\.com\/jiyooshams\?igsh=MW1uanR2NHNpMzk2eg=="[\s\S]*?<\/a>/;
code = code.replace(regexInstagram, '');

fs.writeFileSync('src/components/Navbar.tsx', code);
console.log('Navbar updated');
