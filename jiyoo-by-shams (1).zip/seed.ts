import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc } from 'firebase/firestore';
import { PRODUCTS } from './src/data.js';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const firebaseConfig = require('./firebase-applet-config.json');

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

async function seed() {
  console.log('Seeding products...');
  const productsRef = collection(db, 'products');
  for (const p of PRODUCTS) {
    await setDoc(doc(productsRef, p.id), p);
    console.log('Added', p.id);
  }
  console.log('Done!');
}
seed().catch(console.error);
