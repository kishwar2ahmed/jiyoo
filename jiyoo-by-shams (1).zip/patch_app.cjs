const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

// Remove duplicates of isAboutOpen
code = code.replace(/const \[isAboutOpen, setIsAboutOpen\] = useState\(false\);\n  const \[isAboutOpen, setIsAboutOpen\] = useState\(false\);/, 'const [isAboutOpen, setIsAboutOpen] = useState(false);');

// Remove duplicate AboutModal
code = code.replace(/<AboutModal isOpen={isAboutOpen} onClose=\{\(\) => setIsAboutOpen\(false\)\} \/>\n      <AboutModal isOpen={isAboutOpen} onClose=\{\(\) => setIsAboutOpen\(false\)\} \/>/, '<AboutModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />');

fs.writeFileSync('src/App.tsx', code);
