const fs = require('fs');
let code = fs.readFileSync('src/components/AuthModal.tsx', 'utf8');

// Remove CinematicCharacter import
code = code.replace(/import { CinematicCharacter } from "\.\/CinematicCharacter";\n/, '');

// Replace phase state and sequence
const sequenceRegex = /const \[phase, setPhase\] = useState<[\s\S]*?\}, \[isOpen\]\);/m;
code = code.replace(sequenceRegex, '');

// Remove CinematicCharacter component wrapper
const cinematicRegex = /<motion\.div\s*initial="enter"[\s\S]*?<CinematicCharacter phase=\{phase\} \/>\s*<\/motion\.div>/m;
code = code.replace(cinematicRegex, '');

// Replace card motion.div variants
const cardMotionRegex = /<motion\.div\s*initial="enter"\s*animate=\{phase\}\s*variants=\{[\s\S]*?\}\}\s*className="relative w-full/m;
const fastCardMotion = `<motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="relative w-full`;
code = code.replace(cardMotionRegex, fastCardMotion);

fs.writeFileSync('src/components/AuthModal.tsx', code);
console.log('Animation updated');
