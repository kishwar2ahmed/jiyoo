export interface WeightOption {
  weight?: string;
  label?: string;
  price: string | number;
  originalPrice?: string | number;
}

export interface Product {
  id: string | number;
  name: string;
  subtitle?: string;
  description?: string;
  price: any;
  numericPrice?: number;
  originalPrice?: any;
  discount?: number;
  unit?: string;
  image: string;
  badge?: string;
  freshnessBadge?: string;
  deliveryEstimate?: string;
  rating?: number;
  reviewsCount?: number;
  isOrganic?: boolean;
  isPopular?: boolean;
  category?: string;
  categoryId?: string;
  subcategory?: string;
  subcategoryId?: string;
  subsubcategory?: string;
  subSubcategoryId?: string;
  weights?: WeightOption[];
  origin?: string;
  tags?: string[];
  features?: string[];
  isMeatProduct?: boolean;
  fishCuts?: any[];
  cleaningOptions?: any[];
  cutType?: string;
  stock?: number;
}

export type CartProduct = Product;

export interface SubSubCategory {
  id: string;
  label: string;
}

export interface SubCategory {
  id: string;
  label: string;
  items?: SubSubCategory[];
}

export interface Category {
  id: string;
  label: string;
  items?: SubCategory[];
}

export interface CartItem {
  id: string | number;
  name: string;
  price: any;
  numericPrice: number;
  unit?: string;
  image: string;
  quantity: number;
  selectedWeight?: string;
  selectedCut?: string;
}

export interface AuthUser {
  id: string;
  email: string;
  name?: string;
  displayName?: string;
  picture?: string;
  role?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
  role?: 'admin' | 'customer';
  createdAt?: any;
}

export interface Order {
  id: string;
  userId: string;
  amount: number;
  items: Array<{
    id: string | number;
    name: string;
    quantity: number;
    price: number;
    image?: string;
  }>;
  shippingDetails: {
    name: string;
    phone: string;
    address: string;
  };
  paymentMethod?: string;
  status: string;
  createdAt: any;
  razorpay_order_id?: string;
  razorpay_payment_id?: string;
}
