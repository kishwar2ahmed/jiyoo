import React, { createContext, useContext, useState, useEffect } from 'react';
import { db } from './lib/firebase';
import { doc, onSnapshot, setDoc, getDoc } from 'firebase/firestore';

interface Settings {
  storeName: string;
  contactEmail: string;
  logoUrl: string | null;
  developerImageUrl: string | null;
}

interface SettingsContextType {
  settings: Settings;
  updateSettings: (newSettings: Partial<Settings>) => Promise<void>;
}

const defaultSettings: Settings = {
  storeName: 'JIYOO Premium Products',
  contactEmail: 'support@jiyoo.com',
  logoUrl: null,
  developerImageUrl: null,
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<Settings>(defaultSettings);

  useEffect(() => {
    let unsub = () => {};
    const initSettings = async () => {
      try {
        const docRef = doc(db, 'settings', 'global');
        const docSnap = await getDoc(docRef);
        if (!docSnap.exists()) {
          // Initialize if missing (only allowed if security rules permit or done by admin)
          try {
            await setDoc(docRef, defaultSettings);
          } catch (e) {
            console.log('Cannot initialize settings (requires admin)', e);
          }
        }
        
        unsub = onSnapshot(docRef, (snap) => {
          if (snap.exists()) {
            setSettings({ ...defaultSettings, ...snap.data() } as Settings);
          }
        });
      } catch (err) {
        console.error('Error fetching settings:', err);
      }
    };
    initSettings();
    
    return () => unsub();
  }, []);

  const updateSettings = async (newSettings: Partial<Settings>) => {
    const updated = { ...settings, ...newSettings };
    await setDoc(doc(db, 'settings', 'global'), updated, { merge: true });
    setSettings(updated);
  };

  return (
    <SettingsContext.Provider value={{ settings, updateSettings }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
