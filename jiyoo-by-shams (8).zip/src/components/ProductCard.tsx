import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, ShoppingBag, Clock, ShieldCheck, Check, Minus, Plus } from 'lucide-react';
import { useCart } from '../CartContext';
import { Product } from '../types';
import logoImage from '../assets/logo.jpg';
import { useSettings } from '../SettingsContext';

export function ProductCard({ 
  product, 
  wishlist, 
  toggleWishlist, 
  onProductClick 
}: { 
  key?: React.Key,
  product: Product, 
  wishlist: string[], 
  toggleWishlist: (id: string) => void,
  onProductClick?: (product: Product) => void
}) {
  const { addToCart, triggerFlyingItem } = useCart();
  const { settings } = useSettings();
  const [selectedWeight, setSelectedWeight] = useState(product.weights?.[0]);
  const [selectedCleaning, setSelectedCleaning] = useState(product.cleaningOptions?.[0]);
  const [selectedCut, setSelectedCut] = useState(product.fishCuts?.[0]);
  const [cardQty, setCardQty] = useState(1);

  const currentPrice = selectedWeight ? selectedWeight.price : product.price;
  const currentUnit = selectedWeight ? selectedWeight.label : product.unit;

  const handleAddToCart = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation(); // Prevent opening the detail modal
    const rect = e.currentTarget.getBoundingClientRect();
    triggerFlyingItem({
      image: product.image,
      startX: rect.left + rect.width / 2,
      startY: rect.top + rect.height / 2,
    });
    
    let itemName = product.name;
    if (selectedCut) itemName += ` - ${selectedCut}`;
    if (selectedCleaning) itemName += ` (${selectedCleaning})`;

    addToCart({
      id: `${product.id}-${currentUnit}-${selectedCut || ''}-${selectedCleaning || ''}`,
      name: itemName,
      price: `₹${currentPrice}`,
      numericPrice: currentPrice,
      image: product.image,
      badge: currentUnit
    }, cardQty);
  };

  const incrementQty = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCardQty(prev => prev + 1);
  };

  const decrementQty = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (cardQty > 1) {
      setCardQty(prev => prev - 1);
    }
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      onClick={() => onProductClick?.(product)}
      className="group flex flex-col bg-white rounded-xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-300 border border-[#E7E3DA] cursor-pointer h-full"
    >
      {/* Product Image Area */}
      <div className="relative aspect-[4/3] overflow-hidden bg-[#F4F1EA]">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          referrerPolicy="no-referrer"
          loading="lazy"
          decoding="async"
          onError={(e) => {
            (e.target as HTMLImageElement).src = settings.logoUrl || logoImage;
          }}
        />
        <div className="absolute inset-0 z-10 bg-gradient-to-t from-[#1C1917]/20 via-transparent pointer-events-none" />
        
        {/* Freshness Badge */}
        {product.freshnessBadge && (
          <div className="absolute top-3 left-3 z-20">
            <span className="inline-flex items-center gap-1 bg-[#FAF9F5] text-[#1C1917] px-2.5 py-1 rounded-sm text-[10px] font-semibold uppercase tracking-wider border border-[#E7E3DA]">
              <ShieldCheck className="w-3 h-3 text-emerald-700" />
              {product.freshnessBadge}
            </span>
          </div>
        )}

        {/* Wishlist Button */}
        <button 
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(String(product.id));
          }}
          className="absolute top-3 right-3 z-20 w-8 h-8 bg-[#FAF9F5] rounded-full flex items-center justify-center text-[#1C1917] hover:bg-white transition-colors border border-[#E7E3DA]"
        >
          <Heart 
            className="w-4 h-4 transition-transform active:scale-125" 
            fill={wishlist.includes(String(product.id)) ? '#DC2626' : 'none'} 
            stroke={wishlist.includes(String(product.id)) ? '#DC2626' : 'currentColor'}
          />
        </button>
      </div>

      {/* Product Information Card */}
      <div className="flex-1 flex flex-col p-5">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h4 className="text-base sm:text-lg font-serif-luxury font-semibold text-[#1C1917] leading-tight mb-1 line-clamp-1">
              {product.name}
            </h4>
            <div className="flex items-center gap-2 text-[11px] text-[#78716C] font-medium">
              <span className="uppercase tracking-widest text-[10px]">{product.categoryId}</span>
              <span>•</span>
              <span className="inline-flex items-center gap-0.5 text-emerald-800 font-semibold uppercase text-[10px]">
                <Check className="w-2.5 h-2.5" /> In Stock
              </span>
            </div>
          </div>
        </div>
        
        {product.description && (
          <p className="text-xs text-[#78716C] line-clamp-2 mb-4 leading-relaxed font-normal">
            {product.description}
          </p>
        )}

        {/* Option selectors */}
        <div className="mt-auto space-y-4">
          <div className="space-y-2">
            {/* Weights */}
            {product.weights && product.weights.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-0.5">
                {product.weights.map((w) => (
                  <button
                    key={w.label}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedWeight(w);
                    }}
                    className={`px-2.5 py-1 rounded-sm text-[10px] font-semibold whitespace-nowrap transition-colors border ${
                      selectedWeight?.label === w.label 
                        ? 'bg-[#1C1917] text-[#FAF9F5] border-[#1C1917]' 
                        : 'bg-[#F4F1EA] text-[#44403C] border-[#E7E3DA] hover:border-[#1C1917]'
                    }`}
                  >
                    {w.label}
                  </button>
                ))}
              </div>
            )}

            {/* Fish Cuts */}
            {product.fishCuts && product.fishCuts.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-0.5">
                {product.fishCuts.map((c) => (
                  <button
                    key={c}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedCut(c);
                    }}
                    className={`px-2.5 py-1 rounded-sm text-[10px] font-semibold whitespace-nowrap transition-colors border ${
                      selectedCut === c 
                        ? 'bg-[#1C1917] text-[#FAF9F5] border-[#1C1917]' 
                        : 'bg-[#F4F1EA] text-[#44403C] border-[#E7E3DA] hover:border-[#1C1917]'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}

            {/* Cleaning Options */}
            {product.cleaningOptions && product.cleaningOptions.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-0.5">
                {product.cleaningOptions.map((c) => (
                  <button
                    key={c}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedCleaning(c);
                    }}
                    className={`px-2.5 py-1 rounded-sm text-[10px] font-semibold whitespace-nowrap transition-colors border ${
                      selectedCleaning === c 
                        ? 'bg-[#1C1917] text-[#FAF9F5] border-[#1C1917]' 
                        : 'bg-[#F4F1EA] text-[#44403C] border-[#E7E3DA] hover:border-[#1C1917]'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Action Row */}
          <div className="pt-3 border-t border-[#E7E3DA] flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[9px] text-[#78716C] uppercase font-semibold tracking-widest flex items-center gap-1">
                <Clock className="w-2.5 h-2.5" /> {product.deliveryEstimate || '60m'}
              </span>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-base sm:text-lg font-bold text-[#1C1917] tracking-tight">₹{currentPrice * cardQty}</span>
                {product.discount && cardQty === 1 && (
                  <span className="text-[10px] text-[#78716C] line-through">
                    ₹{Math.round(currentPrice / (1 - product.discount / 100))}
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {/* Card Inline Quantity Selector */}
              <div className="bg-[#F4F1EA] rounded-md flex items-center border border-[#E7E3DA] p-0.5 h-8 shrink-0">
                <button
                  onClick={decrementQty}
                  disabled={cardQty <= 1}
                  className="w-5 h-5 rounded flex items-center justify-center text-[#1C1917] hover:bg-white disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-5 text-center font-bold text-[#1C1917] text-xs">{cardQty}</span>
                <button
                  onClick={incrementQty}
                  className="w-5 h-5 rounded flex items-center justify-center text-[#1C1917] hover:bg-white transition-all"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>

              {/* Add Button */}
              <button 
                onClick={handleAddToCart}
                className="bg-[#1C1917] text-[#FAF9F5] h-8 px-3 rounded-md font-semibold text-xs tracking-wider uppercase flex items-center justify-center gap-1.5 hover:bg-[#292524] transition-all active:scale-95 cursor-pointer"
              >
                <ShoppingBag className="w-3.5 h-3.5" /> Add
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
