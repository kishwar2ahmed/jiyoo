import React, { useRef, useState } from 'react';
import { motion, useInView } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { DeveloperPresentation } from './DeveloperPresentation';
import developerImage from '../assets/IMG-20260723-WA0099.jpg';

export function DeveloperFooter() {
  const containerRef = useRef<HTMLButtonElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-10%" });
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <motion.button
        onClick={() => setIsModalOpen(true)}
        ref={containerRef}
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full mt-8 overflow-hidden rounded-xl group transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] hover:-translate-y-1 hover:shadow-[0_8px_16px_rgba(0,0,0,0.06)] cursor-pointer block text-left"
        style={{ backgroundColor: '#F5F1EB' }}
      >
      {/* SVG Noise Texture */}
      <svg
        className="pointer-events-none absolute inset-0 z-0 h-full w-full opacity-[0.04] mix-blend-multiply"
        xmlns="http://www.w3.org/2000/svg"
      >
        <filter id="noiseFilterMin">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#noiseFilterMin)" />
      </svg>

      {/* Outer Paper Shadow */}
      <div className="absolute inset-0 z-0 transition-all duration-500 ease-out shadow-[inset_0_1px_2px_rgba(255,255,255,0.8)] group-hover:shadow-[inset_0_2px_8px_rgba(255,255,255,1),inset_0_-2px_10px_rgba(0,0,0,0.03)]" />

      {/* Main Content */}
      <div className="relative z-10 flex flex-row items-center justify-between px-4 py-3 gap-3">
        
        {/* LEFT: Mini Portrait & Text */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          {/* Portrait Mask */}
          <motion.div 
            className="relative w-12 h-12 md:w-14 md:h-14 flex-shrink-0 overflow-hidden transition-all duration-[1.2s] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.12] group-hover:-rotate-[6deg] group-hover:shadow-[0_12px_24px_rgba(0,0,0,0.15)] rounded-[0.25rem]"
            initial={{ opacity: 0, clipPath: 'polygon(20% 0, 100% 20%, 80% 100%, 0 80%)', scale: 0.8, filter: 'blur(8px)', rotate: 5 }}
            animate={isInView ? { opacity: 1, clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)', scale: 1, filter: 'blur(0px)', rotate: 0 } : { opacity: 0 }}
            transition={{ duration: 1.4, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="absolute inset-0 z-10 shadow-[inset_0_2px_6px_rgba(0,0,0,0.15)] pointer-events-none rounded-[0.25rem] transition-all duration-[1.2s] group-hover:opacity-60" />
            <motion.img 
              src={developerImage} 
              alt="Kishwar" 
              className="w-full h-full object-cover object-top transition-all duration-[1.2s] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.15] group-hover:rotate-[2deg]"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = '/IMG-20260723-WA0099.jpg';
              }}
              initial={{ scale: 1.4 }}
              animate={isInView ? { scale: 1 } : { scale: 1.4 }}
              transition={{ duration: 1.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            />
          </motion.div>

          {/* Typography */}
          <div className="flex flex-col justify-center">
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -10 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
              className="flex flex-col md:flex-row md:gap-1.5 md:items-baseline"
            >
              <h2 className="text-xs md:text-sm font-serif tracking-tight text-[#1E1E1C] leading-tight group-hover:text-[#5C2328] transition-colors duration-500">
                Designed with <span role="img" aria-label="heart" className="inline-block text-red-500">❤️</span> <span className="text-[#85786F] italic transition-transform duration-500 group-hover:translate-x-1 inline-block">by Kishwar Ahmed</span>
              </h2>
            </motion.div>
            
            <motion.p 
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : { opacity: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-[#53624C] font-mono text-[8.5px] uppercase tracking-[0.2em] mt-0.5 mix-blend-color-burn group-hover:text-[#1E1E1C] transition-colors duration-500"
            >
              Premium Digital Experiences
            </motion.p>
          </div>
        </div>

        {/* RIGHT: Action Button */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex-shrink-0"
        >
          <div className="w-7 h-7 rounded-full border border-[#DDD5CB] flex items-center justify-center transition-all duration-500 group-hover:border-[#1E1E1C] group-hover:bg-[#1E1E1C] group-hover:shadow-[0_4px_12px_rgba(30,30,28,0.15)] group-hover:scale-105">
            <ArrowRight className="w-3 h-3 text-[#1E1E1C] transition-all duration-500 group-hover:text-[#F5F1EB] group-hover:translate-x-0.5" strokeWidth={1.5} />
          </div>
        </motion.div>

      </div>
      </motion.button>
      
      <DeveloperPresentation isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}
