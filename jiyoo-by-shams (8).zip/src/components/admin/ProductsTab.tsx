import React, { useState, useEffect } from 'react';
import { collection, getDocs, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../lib/firebase';
import { Product } from '../../types';
import { PRODUCTS } from '../../data';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Edit2, Trash2, Search, Image as ImageIcon, Loader2, Database } from 'lucide-react';

export function ProductsTab() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    loadProducts();
  }, []);

  async function loadProducts() {
    setLoading(true);
    try {
      const snap = await getDocs(collection(db, 'products'));
      const loaded: Product[] = [];
      snap.forEach(doc => {
        loaded.push({ id: doc.id, ...doc.data() } as Product);
      });
      setProducts(loaded);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  const handleSeedCatalog = async () => {
    if (!window.confirm("Seed default sample catalog to Firestore?")) return;
    setLoading(true);
    try {
      for (const p of PRODUCTS) {
        await setDoc(doc(db, 'products', String(p.id)), p);
      }
      alert("Sample catalog seeded successfully!");
      loadProducts();
    } catch (err) {
      console.error("Error seeding catalog:", err);
      alert("Failed to seed catalog.");
      setLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.name || !editingProduct?.price || !editingProduct?.categoryId) return;
    
    try {
      const id = editingProduct.id || Math.random().toString(36).substring(2, 9);
      const payload = { ...editingProduct, id } as Product;
      
      await setDoc(doc(db, 'products', String(id)), payload);
      setIsModalOpen(false);
      setEditingProduct(null);
      loadProducts();
    } catch (err) {
      console.error("Error saving product:", err);
      alert("Failed to save product.");
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      try {
        await deleteDoc(doc(db, 'products', id));
        loadProducts();
      } catch (err) {
        console.error("Error deleting product:", err);
      }
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const storageRef = ref(storage, `products/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      setEditingProduct(prev => ({ ...prev, image: url }));
    } catch (err) {
      console.error("Error uploading image:", err);
      alert("Failed to upload image.");
    } finally {
      setUploadingImage(false);
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (p.categoryId && p.categoryId.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-brand-black">Products Management</h2>
          <p className="text-brand-gray-500">Add, edit, or remove products from your catalog.</p>
        </div>
        <div className="flex items-center gap-2">
          {products.length === 0 && (
            <button 
              onClick={handleSeedCatalog}
              className="bg-emerald-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-emerald-700 transition-colors flex items-center gap-2"
            >
              <Database className="w-4 h-4" /> Seed Sample Catalog
            </button>
          )}
          <button 
            onClick={() => {
              setEditingProduct({ tags: [], unit: 'kg', price: 0, stock: 0 });
              setIsModalOpen(true);
            }}
            className="bg-brand-black text-brand-white px-4 py-2 rounded-lg font-medium hover:bg-brand-gray-900 transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> Add Product
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-brand-gray-200">
        <div className="relative max-w-md mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-gray-400" />
          <input 
            type="text"
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-brand-gray-50 border border-brand-gray-200 rounded-lg outline-none focus:border-emerald-600 text-sm"
          />
        </div>

        {loading ? (
          <div className="py-10 text-center text-brand-gray-500">Loading products...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-brand-gray-500 uppercase bg-brand-gray-50">
                <tr>
                  <th className="px-4 py-3 rounded-tl-lg">Product</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Price</th>
                  <th className="px-4 py-3 rounded-tr-lg text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map(p => (
                  <tr key={p.id} className="border-b border-brand-gray-100 hover:bg-brand-gray-50 transition-colors">
                    <td className="px-4 py-3 flex items-center gap-3">
                      <div className="w-10 h-10 rounded overflow-hidden bg-brand-gray-200 shrink-0">
                        {p.image ? (
                          <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <ImageIcon className="w-5 h-5 m-auto text-brand-gray-400 mt-2.5" />
                        )}
                      </div>
                      <span className="font-medium text-brand-black">{p.name}</span>
                    </td>
                    <td className="px-4 py-3 text-brand-gray-600 capitalize">{p.categoryId}</td>
                    <td className="px-4 py-3 text-brand-gray-600">₹{p.price} / {p.unit}</td>
                    <td className="px-4 py-3 text-right">
                      <button 
                        onClick={() => { setEditingProduct(p); setIsModalOpen(true); }}
                        className="text-blue-600 hover:bg-blue-50 p-2 rounded-lg transition-colors mr-2"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(String(p.id))}
                        className="text-red-600 hover:bg-red-50 p-2 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {filteredProducts.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-brand-gray-500">
                      No products found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit/Add Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsModalOpen(false)} />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white w-full max-w-2xl rounded-2xl shadow-xl z-10 overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-6 border-b border-brand-gray-200 flex justify-between items-center bg-brand-gray-50">
                <h3 className="text-xl font-bold text-brand-black">
                  {editingProduct?.id ? 'Edit Product' : 'Add New Product'}
                </h3>
              </div>
              <div className="p-6 overflow-y-auto flex-1">
                <form id="productForm" onSubmit={handleSave} className="space-y-4">
                  
                  {/* Image Upload */}
                  <div>
                    <label className="block text-sm font-medium text-brand-gray-700 mb-1">Product Image</label>
                    <div className="flex items-center gap-4">
                      <div className="w-24 h-24 rounded-lg bg-brand-gray-100 border border-brand-gray-200 overflow-hidden flex items-center justify-center shrink-0">
                        {uploadingImage ? (
                          <Loader2 className="w-6 h-6 animate-spin text-brand-gray-400" />
                        ) : editingProduct?.image ? (
                          <img src={editingProduct.image} alt="Preview" className="w-full h-full object-cover" />
                        ) : (
                          <ImageIcon className="w-8 h-8 text-brand-gray-400" />
                        )}
                      </div>
                      <div className="flex-1">
                        <input 
                          type="file" 
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="block w-full text-sm text-brand-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-brand-gray-100 file:text-brand-black hover:file:bg-brand-gray-200"
                        />
                        <div className="mt-2 text-xs text-brand-gray-400">Or provide image URL:</div>
                        <input 
                          type="text"
                          value={editingProduct?.image || ''}
                          onChange={e => setEditingProduct(prev => ({ ...prev, image: e.target.value }))}
                          placeholder="https://..."
                          className="w-full mt-1 bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-1.5 text-sm outline-none focus:border-emerald-600"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-brand-gray-700 mb-1">Name *</label>
                      <input 
                        required
                        type="text"
                        value={editingProduct?.name || ''}
                        onChange={e => setEditingProduct(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-white border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-brand-gray-700 mb-1">Category ID *</label>
                      <input 
                        required
                        type="text"
                        value={editingProduct?.categoryId || ''}
                        onChange={e => setEditingProduct(prev => ({ ...prev, categoryId: e.target.value }))}
                        className="w-full bg-white border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-brand-gray-700 mb-1">Price (₹) *</label>
                      <input 
                        required
                        type="number"
                        min="0"
                        step="0.01"
                        value={editingProduct?.price || ''}
                        onChange={e => setEditingProduct(prev => ({ ...prev, price: Number(e.target.value) }))}
                        className="w-full bg-white border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-brand-gray-700 mb-1">Stock Quantity</label>
                      <input 
                        type="number"
                        min="0"
                        value={editingProduct?.stock || 0}
                        onChange={e => setEditingProduct(prev => ({ ...prev, stock: Number(e.target.value) }))}
                        className="w-full bg-white border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-brand-gray-700 mb-1">Unit *</label>
                      <input 
                        required
                        type="text"
                        value={editingProduct?.unit || ''}
                        onChange={e => setEditingProduct(prev => ({ ...prev, unit: e.target.value }))}
                        placeholder="e.g., kg, pack"
                        className="w-full bg-white border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-brand-gray-700 mb-1">Description</label>
                    <textarea 
                      value={editingProduct?.description || ''}
                      onChange={e => setEditingProduct(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full bg-white border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-brand-gray-700 mb-1">Subcategory ID</label>
                    <input 
                      type="text"
                      value={editingProduct?.subcategoryId || ''}
                      onChange={e => setEditingProduct(prev => ({ ...prev, subcategoryId: e.target.value }))}
                      className="w-full bg-white border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
                    />
                  </div>

                </form>
              </div>
              <div className="p-4 border-t border-brand-gray-200 flex justify-end gap-3 bg-brand-gray-50">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-brand-gray-600 hover:bg-brand-gray-200 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  form="productForm"
                  className="px-4 py-2 text-sm font-medium bg-brand-black text-white rounded-lg hover:bg-brand-gray-900 transition-colors"
                >
                  Save Product
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
