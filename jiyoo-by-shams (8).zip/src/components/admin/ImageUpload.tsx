import React, { useState, useRef } from 'react';
import { UploadCloud, Image as ImageIcon, Loader2, CheckCircle2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ImageUploadProps {
  label: string;
  value: string | null;
  onChange: (url: string | null) => void;
  circular?: boolean;
  storagePath: string; // 'logo' or 'developer-image'
}

export function ImageUpload({ label, value, onChange, circular = false, storagePath }: ImageUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const validateAndProcessFile = async (file: File): Promise<Blob> => {
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      throw new Error('Please upload a valid image file (PNG, JPG, JPEG, SVG, WebP)');
    }
    if (file.size > 5 * 1024 * 1024) {
      throw new Error('File size must be less than 5MB');
    }

    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          if (circular) {
            const size = Math.min(width, height);
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              const offsetX = (width - size) / 2;
              const offsetY = (height - size) / 2;
              ctx.drawImage(img, offsetX, offsetY, size, size, 0, 0, size, size);
            }
          } else {
            const MAX_DIMENSION = 1200;
            if (width > height && width > MAX_DIMENSION) {
              height *= MAX_DIMENSION / width;
              width = MAX_DIMENSION;
            } else if (height > MAX_DIMENSION) {
              width *= MAX_DIMENSION / height;
              height = MAX_DIMENSION;
            }
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(img, 0, 0, width, height);
            }
          }

          canvas.toBlob(
            (blob) => {
              if (blob) resolve(blob);
              else reject(new Error('Image processing failed'));
            },
            'image/webp',
            0.85
          );
        };
        img.onerror = () => reject(new Error('Invalid image file'));
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) await handleFileUpload(file);
  };

  const handleFileInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) await handleFileUpload(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleFileUpload = async (file: File) => {
    setError(null);
    setIsUploading(true);
    setProgress(30); // Simulate initial progress

    try {
      const processedBlob = await validateAndProcessFile(file);
      setProgress(60); // Progress after processing

      const formData = new FormData();
      const fieldName = storagePath === 'logo' ? 'logo' : 'developer';
      formData.append(fieldName, processedBlob, `${fieldName}.webp`);

      const response = await fetch(`/api/admin/upload/${storagePath}`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Upload failed with status: ${response.status}`);
      }

      let data;
      try {
        data = await response.json();
      } catch (err) {
        throw new Error('Invalid response from server');
      }

      setProgress(100);

      if (data.success) {
        // Force browser to fetch new image by appending timestamp
        onChange(`${data.imageUrl}?t=${Date.now()}`);
      } else {
        throw new Error(data.error || 'Upload failed');
      }
    } catch (err: any) {
      setError(err.message || 'Error processing image');
    } finally {
      setIsUploading(false);
      setProgress(0);
    }
  };

  const handleRemove = async () => {
    if (window.confirm('Are you sure you want to remove this image?')) {
      try {
        await fetch(`/api/admin/${storagePath}`, { method: 'DELETE' });
        onChange(null);
      } catch (err) {
        console.error('Failed to delete image');
      }
    }
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-brand-gray-700">{label}</label>
      
      <AnimatePresence mode="wait">
        {value ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="relative group w-full"
          >
            <div className={`relative overflow-hidden border border-brand-gray-200 bg-brand-gray-50 flex items-center justify-center ${circular ? 'w-32 h-32 rounded-full mx-auto' : 'w-full h-48 rounded-xl'}`}>
              <img src={value} alt={label} className="w-full h-full object-contain p-2" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3 backdrop-blur-sm">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 bg-white text-brand-black rounded-full hover:bg-brand-gray-100 transition-colors shadow-sm"
                  title="Replace"
                >
                  <UploadCloud className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleRemove}
                  className="p-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors shadow-sm"
                  title="Remove"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            onClick={() => !isUploading && fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`relative border-2 border-dashed rounded-xl transition-all duration-200 cursor-pointer overflow-hidden flex flex-col items-center justify-center text-center px-6 ${circular ? 'w-32 h-32 mx-auto rounded-full' : 'h-48'} ${
              isDragging ? 'border-emerald-500 bg-emerald-50/50' : 'border-brand-gray-200 hover:border-brand-gray-300 hover:bg-brand-gray-50/50'
            } ${isUploading ? 'pointer-events-none' : ''}`}
          >
            {isUploading ? (
              <div className="flex flex-col items-center gap-3 w-full max-w-[200px]">
                <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
                <div className="w-full bg-brand-gray-200 rounded-full h-1.5 overflow-hidden">
                  <div 
                    className="bg-emerald-600 h-full transition-all duration-300 ease-out" 
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <span className="text-xs font-medium text-brand-gray-600">{Math.round(progress)}%</span>
              </div>
            ) : (
              <>
                <div className="w-10 h-10 rounded-full bg-brand-gray-100 flex items-center justify-center mb-3 text-brand-gray-500">
                  <UploadCloud className="w-5 h-5" />
                </div>
                {!circular && (
                  <>
                    <p className="text-sm font-medium text-brand-gray-800 mb-1">Click or drag image to upload</p>
                    <p className="text-xs text-brand-gray-500">SVG, PNG, JPG or WebP (max 5MB)</p>
                  </>
                )}
                {circular && (
                  <p className="text-xs text-brand-gray-500 text-center">Upload<br/>Image</p>
                )}
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {error && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-sm text-red-500 mt-2 flex items-center gap-1.5">
          <X className="w-3.5 h-3.5 shrink-0" /> {error}
        </motion.p>
      )}

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileInput}
        accept="image/png, image/jpeg, image/jpg, image/svg+xml, image/webp"
        className="hidden"
      />
    </div>
  );
}
