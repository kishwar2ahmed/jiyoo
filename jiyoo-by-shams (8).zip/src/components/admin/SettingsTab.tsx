import React, { useState, useEffect } from 'react';
import { Save } from 'lucide-react';
import { useSettings } from '../../SettingsContext';
import { useCart } from '../../CartContext';
import { ImageUpload } from './ImageUpload';

export function SettingsTab() {
  const { settings, updateSettings } = useSettings();
  const { user } = useCart();
  const [storeName, setStoreName] = useState(settings.storeName);
  const [contactEmail, setContactEmail] = useState(settings.contactEmail);
  const [logoUrl, setLogoUrl] = useState(settings.logoUrl || '');
  const [developerImageUrl, setDeveloperImageUrl] = useState(settings.developerImageUrl || '');
  const [isSaving, setIsSaving] = useState(false);

  const canEditBranding = user?.email === 'yoyokishwar@gmail.com' || user?.email === 'jiyooshams@gmail.com' || user?.email === 'shamsjiyoo@gmail.com';

  useEffect(() => {
    setStoreName(settings.storeName);
    setContactEmail(settings.contactEmail);
    setLogoUrl(settings.logoUrl || '');
    setDeveloperImageUrl(settings.developerImageUrl || '');
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const updates: any = {
        storeName,
        contactEmail,
      };
      if (canEditBranding) {
        updates.logoUrl = logoUrl || null;
        updates.developerImageUrl = developerImageUrl || null;
      }
      await updateSettings(updates);
      alert('Store settings saved successfully.');
    } catch (err) {
      console.warn("Could not save settings", err);
      alert('Failed to save settings. Check permissions.');
    }
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-brand-black">Settings</h2>
        <p className="text-brand-gray-500">Manage global store configuration.</p>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-brand-gray-200 max-w-2xl">
        <form onSubmit={handleSave} className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-brand-gray-700 mb-1">Store Name</label>
              <input 
                type="text" value={storeName} onChange={e => setStoreName(e.target.value)}
                className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-brand-gray-700 mb-1">Contact Email</label>
              <input 
                type="email" value={contactEmail} onChange={e => setContactEmail(e.target.value)}
                className="w-full bg-brand-gray-50 border border-brand-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-emerald-600"
              />
            </div>
          </div>

          {canEditBranding && (
            <div className="pt-6 border-t border-brand-gray-100 space-y-8">
              <div>
                <h3 className="text-lg font-medium text-brand-black mb-4">Branding</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  <ImageUpload 
                    label="Store Logo" 
                    value={logoUrl} 
                    onChange={url => setLogoUrl(url || '')} 
                    storagePath="logo" 
                  />
                  <ImageUpload 
                    label="Developer Image" 
                    value={developerImageUrl} 
                    onChange={url => setDeveloperImageUrl(url || '')} 
                    circular={true} 
                    storagePath="developer-image" 
                  />
                </div>
              </div>
            </div>
          )}
          
          <div className="pt-6 border-t border-brand-gray-100">
            <button disabled={isSaving} type="submit" className="w-full sm:w-auto bg-brand-black text-white px-6 py-2.5 rounded-lg font-medium hover:bg-brand-gray-900 transition-colors flex items-center justify-center gap-2">
              <Save className="w-4 h-4" /> {isSaving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
