import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, ShoppingBag, Clock, ShieldCheck } from 'lucide-react';
import { useCart } from '../CartContext';
import { Product } from '../types';

export function MeatProductCard({ 
  product, 
  wishlist, 
  toggleWishlist, 
  onProductClick 
}: { 
  key?: React.Key, 
  product: Product, 
  wishlist: string[], 
  toggleWishlist: (id: string) => void,
  onProductClick?: (product: Product) => void
}) {
  const { addToCart, triggerFlyingItem } = useCart();
  const [selectedWeight, setSelectedWeight] = useState(product.weights?.[0]);
  const [selectedCleaning, setSelectedCleaning] = useState(product.cleaningOptions?.[0]);
  const [selectedCut, setSelectedCut] = useState(product.fishCuts?.[0]);

  const currentPrice = selectedWeight ? selectedWeight.price : product.price;
  const currentUnit = selectedWeight ? selectedWeight.label : product.unit;

  const handleAddToCart = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation(); // Avoid opening the detail modal
    const rect = e.currentTarget.getBoundingClientRect();
    triggerFlyingItem({
      image: product.image,
      startX: rect.left + rect.width / 2,
      startY: rect.top + rect.height / 2,
    });
    
    let itemName = product.name;
    if (selectedCut) itemName += ` - ${selectedCut}`;
    if (selectedCleaning) itemName += ` (${selectedCleaning})`;

    addToCart({
      id: `${product.id}-${currentUnit}-${selectedCut || ''}-${selectedCleaning || ''}`,
      name: itemName,
      price: `₹${currentPrice}`,
      numericPrice: currentPrice,
      image: product.image,
      badge: currentUnit
    });
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      onClick={() => onProductClick?.(product)}
      className="group flex flex-col bg-brand-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-brand-gray-100 cursor-pointer"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-brand-gray-50">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 z-20 bg-gradient-to-t from-brand-black/40 via-brand-black/0 to-brand-black/0 pointer-events-none" />
        
        {/* Badges */}
        <div className="absolute top-4 left-4 z-30 flex flex-col gap-2">
          {product.freshnessBadge && (
            <span className="inline-flex items-center gap-1 bg-brand-white/95 backdrop-blur-md text-brand-black px-2.5 py-1 rounded-md text-[10px] font-semibold uppercase tracking-wider shadow-sm">
              <ShieldCheck className="w-3 h-3 text-green-500" />
              {product.freshnessBadge}
            </span>
          )}
        </div>

        <button 
          onClick={(e) => {
            e.stopPropagation(); // Avoid opening the detail modal
            toggleWishlist(String(product.id));
          }}
          className="absolute top-4 right-4 z-30 w-9 h-9 bg-brand-white/80 backdrop-blur-md rounded-full flex items-center justify-center text-brand-black hover:bg-brand-white transition-colors shadow-sm"
        >
          <Heart className="w-4 h-4" fill={wishlist.includes(String(product.id)) ? 'currentColor' : 'none'} />
        </button>
      </div>

      <div className="flex-1 flex flex-col p-5">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h4 className="text-lg font-medium text-brand-black leading-tight mb-1">{product.name}</h4>
            <div className="flex items-center gap-2 text-xs text-brand-gray-500">
              {product.origin && <span>Origin: {product.origin}</span>}
              {product.origin && product.cutType && <span>•</span>}
              {product.cutType && <span>Cut: {product.cutType}</span>}
            </div>
          </div>
        </div>
        
        {product.description && (
          <p className="text-sm text-brand-gray-500 line-clamp-2 mb-4 leading-relaxed">
            {product.description}
          </p>
        )}

        <div className="mt-auto space-y-4">
          {/* Options Selectors */}
          <div className="space-y-3">
            {/* Weight Options */}
            {product.weights && product.weights.length > 0 && (
              <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
                {product.weights.map((w) => (
                  <button
                    key={w.label}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedWeight(w);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                      selectedWeight?.label === w.label 
                        ? 'bg-brand-black text-brand-white shadow-sm' 
                        : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100'
                    }`}
                  >
                    {w.label}
                  </button>
                ))}
              </div>
            )}

            {/* Fish Cuts */}
            {product.fishCuts && product.fishCuts.length > 0 && (
              <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
                {product.fishCuts.map((c) => (
                  <button
                    key={c}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedCut(c);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                      selectedCut === c 
                        ? 'bg-brand-black text-brand-white shadow-sm' 
                        : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}

            {/* Cleaning Options */}
            {product.cleaningOptions && product.cleaningOptions.length > 0 && (
              <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
                {product.cleaningOptions.map((c) => (
                  <button
                    key={c}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedCleaning(c);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                      selectedCleaning === c 
                        ? 'bg-brand-black text-brand-white shadow-sm' 
                        : 'bg-brand-gray-50 text-brand-gray-600 hover:bg-brand-gray-100'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-brand-gray-100 flex items-end justify-between">
            <div>
              <div className="flex items-center gap-1 text-[11px] text-brand-gray-400 mb-1 uppercase tracking-wider font-medium">
                <Clock className="w-3 h-3" />
                Delivery: {product.deliveryEstimate || '90 mins'}
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-xl font-semibold text-brand-black tracking-tight">₹{currentPrice}</span>
                {product.discount && (
                  <span className="text-xs text-brand-gray-400 line-through">
                    ₹{Math.round(currentPrice / (1 - product.discount / 100))}
                  </span>
                )}
              </div>
            </div>

            <button 
              onClick={handleAddToCart}
              className="bg-brand-black text-brand-white px-5 py-2.5 rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-brand-gray-900 shadow-md transition-all active:scale-95"
            >
              <ShoppingBag className="w-4 h-4" /> Add
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
