import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Lock, LayoutDashboard, Package, ShoppingCart, Users, Tags, Settings, BarChart } from 'lucide-react';
import { useCart } from '../CartContext';

import { DashboardTab } from './admin/DashboardTab';
import { ProductsTab } from './admin/ProductsTab';
import { OrdersTab } from './admin/OrdersTab';
import { UsersTab } from './admin/UsersTab';
import { CategoriesTab } from './admin/CategoriesTab';
import { SettingsTab } from './admin/SettingsTab';
import { AnalyticsTab } from './admin/AnalyticsTab';

type Tab = 'dashboard' | 'products' | 'orders' | 'users' | 'categories' | 'analytics' | 'settings';

export function AdminPanel({ onClose }: { onClose: () => void }) {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const { user, isAuthLoading } = useCart();

  if (isAuthLoading) return (
    <div className="fixed inset-0 z-[100] bg-brand-white flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-gold"></div>
    </div>
  );

  // Check role: "admin"
  if (!user || (user.role !== 'admin' && user.email !== 'jiyooshams@gmail.com' && user.email !== 'yoyokishwar@gmail.com' && user.email !== 'shamsjiyoo@gmail.com')) {
    return (
      <div className="fixed inset-0 z-[100] bg-brand-white flex flex-col items-center justify-center p-4">
        <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mb-4">
          <Lock className="w-8 h-8 text-red-600" />
        </div>
        <h2 className="text-2xl font-serif font-bold text-brand-black mb-2">Access Denied</h2>
        <p className="text-brand-gray-500 mb-6 text-center max-w-sm">
          You do not have permission to access the admin panel. Please sign in with an administrator account.
        </p>
        <button 
          onClick={onClose}
          className="bg-brand-black text-brand-white px-6 py-2 rounded-lg font-medium hover:bg-brand-gray-900 transition-colors"
        >
          Return to Store
        </button>
      </div>
    );
  }

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'orders', label: 'Orders', icon: ShoppingCart },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'categories', label: 'Categories', icon: Tags },
    { id: 'analytics', label: 'Analytics', icon: BarChart },
    { id: 'settings', label: 'Settings', icon: Settings },
  ] as const;

  return (
    <div className="fixed inset-0 z-[100] bg-brand-gray-50 flex overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 bg-brand-white border-r border-brand-gray-200 flex flex-col">
        <div className="p-6 border-b border-brand-gray-200 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-serif font-bold text-brand-black">JIYOO Admin</h1>
            <p className="text-xs text-brand-gray-500">Control Panel</p>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as Tab)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                  isActive 
                    ? 'bg-brand-gray-900 text-brand-white' 
                    : 'text-brand-gray-600 hover:bg-brand-gray-100'
                }`}
              >
                <Icon className="w-5 h-5" />
                {tab.label}
              </button>
            );
          })}
        </nav>
        <div className="p-4 border-t border-brand-gray-200">
          <button 
            onClick={onClose}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-brand-gray-100 hover:bg-brand-gray-200 text-brand-black rounded-lg text-sm font-medium transition-colors"
          >
            <X className="w-4 h-4" /> Exit Admin
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <div className="flex-1 overflow-y-auto p-8 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {activeTab === 'dashboard' && <DashboardTab />}
              {activeTab === 'products' && <ProductsTab />}
              {activeTab === 'orders' && <OrdersTab />}
              {activeTab === 'users' && <UsersTab />}
              {activeTab === 'categories' && <CategoriesTab />}
              {activeTab === 'analytics' && <AnalyticsTab />}
              {activeTab === 'settings' && <SettingsTab />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
