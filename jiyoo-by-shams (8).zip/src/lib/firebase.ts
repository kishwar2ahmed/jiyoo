import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, OAuthProvider } from 'firebase/auth';
import { initializeFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBdrqpqhQHcBn5412S_L6OxlHgLSZF6W_M",
  authDomain: "flash-medley-442314-n7.firebaseapp.com",
  projectId: "flash-medley-442314-n7",
  storageBucket: "flash-medley-442314-n7.firebasestorage.app",
  messagingSenderId: "259084804834",
  appId: "1:259084804834:web:2d9a6d49282d0f179f34bb"
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const appleProvider = new OAuthProvider('apple.com');
export const storage = getStorage(app);
