export function createWhatsAppOrderUrl({
  items,
  totalAmount,
  customerName,
  customerPhone,
  customerAddress,
  paymentMethod = 'Cash on Delivery (WhatsApp)'
}: {
  items: Array<{ name: string; quantity: number; price: number | string; numericPrice?: number; selectedWeight?: string; selectedCut?: string }>;
  totalAmount: number;
  customerName?: string;
  customerPhone?: string;
  customerAddress?: string;
  paymentMethod?: string;
}) {
  let text = `🛒 *NEW ORDER - JIYOO FRESH STORE*\n`;
  text += `────────────────────\n`;
  
  items.forEach((item, index) => {
    const itemPrice = item.numericPrice || (typeof item.price === 'number' ? item.price : parseFloat(String(item.price).replace(/[^0-9.]/g, '')) || 0);
    const weightInfo = item.selectedWeight ? ` (${item.selectedWeight})` : '';
    const cutInfo = item.selectedCut ? ` [Cut: ${item.selectedCut}]` : '';
    text += `${index + 1}. *${item.name}*${weightInfo}${cutInfo}\n   Qty: ${item.quantity} × ₹${itemPrice} = ₹${itemPrice * item.quantity}\n`;
  });

  text += `────────────────────\n`;
  text += `💰 *Total Amount:* ₹${totalAmount}\n`;
  text += `💳 *Payment Option:* ${paymentMethod}\n\n`;

  if (customerName || customerPhone || customerAddress) {
    text += `👤 *Delivery Details:*\n`;
    if (customerName) text += `• *Name:* ${customerName}\n`;
    if (customerPhone) text += `• *Phone:* ${customerPhone}\n`;
    if (customerAddress) text += `• *Address:* ${customerAddress}\n`;
  } else {
    text += `📍 *Note:* Please reply with your delivery address for instant dispatch!\n`;
  }

  const encoded = encodeURIComponent(text);
  return `https://wa.me/919876543210?text=${encoded}`;
}

export function createSingleProductWhatsAppUrl({
  productName,
  quantity,
  selectedWeight,
  selectedCut,
  totalPrice
}: {
  productName: string;
  quantity: number;
  selectedWeight?: string;
  selectedCut?: string;
  totalPrice: number;
}) {
  let text = `👋 *HI JIYOO! I want to order this product:* \n\n`;
  text += `🥩 *${productName}*\n`;
  text += `• Quantity: ${quantity}\n`;
  if (selectedWeight) text += `• Weight: ${selectedWeight}\n`;
  if (selectedCut) text += `• Preparation: ${selectedCut}\n`;
  text += `• Total Price: ₹${totalPrice}\n\n`;
  text += `Please confirm order availability and delivery time! 🛵💨`;

  const encoded = encodeURIComponent(text);
  return `https://wa.me/919876543210?text=${encoded}`;
}
