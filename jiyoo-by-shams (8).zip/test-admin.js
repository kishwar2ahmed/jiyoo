import admin from 'firebase-admin';
try {
  admin.initializeApp();
  console.log('Firebase Admin Initialized');
} catch (e) {
  console.error('Failed', e);
}
