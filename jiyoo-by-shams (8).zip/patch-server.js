import fs from 'fs';

let content = fs.readFileSync('server.ts', 'utf8');

const uploadRoutes = `
import multer from 'multer';
import fsSync from 'fs';

// Setup multer for local storage
const uploadDir = path.join(process.cwd(), 'public', 'uploads');
if (!fsSync.existsSync(uploadDir)) {
  fsSync.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir)
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const ext = path.extname(file.originalname) || '.webp';
    cb(null, file.fieldname + '-' + uniqueSuffix + ext)
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Only images are allowed'));
    }
    cb(null, true);
  }
});

// Helper for sending success response
const handleUpload = (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, error: 'No file uploaded' });
  }
  
  // In production, also copy to dist/uploads so it can be served
  if (process.env.NODE_ENV === 'production') {
    const distUploadDir = path.join(process.cwd(), 'dist', 'uploads');
    if (!fsSync.existsSync(distUploadDir)) {
      fsSync.mkdirSync(distUploadDir, { recursive: true });
    }
    fsSync.copyFileSync(req.file.path, path.join(distUploadDir, req.file.filename));
  }
  
  res.json({ success: true, imageUrl: \`/uploads/\${req.file.filename}\` });
};

`;

const routesToAdd = `
  // Admin Upload Endpoints
  app.post('/api/admin/upload/logo', upload.single('logo'), handleUpload);
  app.post('/api/admin/upload/developer-image', upload.single('developer'), handleUpload);
  
  app.delete('/api/admin/logo', (req, res) => res.json({ success: true }));
  app.delete('/api/admin/developer-image', (req, res) => res.json({ success: true }));

  // Serve uploads
  app.use('/uploads', express.static(path.join(process.cwd(), 'public', 'uploads')));
  if (process.env.NODE_ENV === 'production') {
    app.use('/uploads', express.static(path.join(process.cwd(), 'dist', 'uploads')));
  }
`;

// Insert imports
content = content.replace("import rateLimit from 'express-rate-limit';", "import rateLimit from 'express-rate-limit';\n" + uploadRoutes);

// Insert routes inside startServer
content = content.replace("// === Vite Middleware for Development ===", routesToAdd + "\n  // === Vite Middleware for Development ===");

fs.writeFileSync('server.ts', content);
console.log('Patched server.ts');
