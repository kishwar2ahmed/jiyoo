import admin from 'firebase-admin';
import { getStorage } from 'firebase-admin/storage';
import fs from 'fs';
const config = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));
try {
  admin.initializeApp({
    storageBucket: config.storageBucket
  });
  const bucket = getStorage().bucket();
  const file = bucket.file('test.txt');
  await file.save('hello world');
  console.log('Saved');
  await file.delete();
  console.log('Deleted');
} catch (e) {
  console.error('Failed', e);
}
