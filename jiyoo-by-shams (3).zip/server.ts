import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import Razorpay from 'razorpay';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

// Helper to dynamically obtain Razorpay instance
function getRazorpay() {
  const key_id = process.env.RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;
  if (key_id && key_secret) {
    return new Razorpay({ key_id, key_secret });
  }
  return null;
}

// Set up rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per `window` (here, per 15 minutes)
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  message: 'Too many requests from this IP, please try again after 15 minutes',
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Security Middlewares
  app.use(helmet({
    contentSecurityPolicy: false, // Disable CSP for Vite dev server compatibility (or configure it properly)
  }));
  app.use(express.json({ 
    limit: '10kb',
    verify: (req, res, buf) => {
      (req as any).rawBody = buf.toString('utf8');
    }
  })); // Limit body size to 10kb
  app.use(cookieParser());
  
  // Apply rate limiter to all API routes
  app.use('/api/', apiLimiter);

  // === Payment Endpoints ===
  
  // Create Razorpay Order
  const handleCreateOrder = async (req: express.Request, res: express.Response) => {
    try {
      const { amount, currency = 'INR' } = req.body;
      
      if (!amount || isNaN(amount) || amount <= 0) {
        return res.status(400).json({ success: false, error: 'Valid amount is required' });
      }

      const razorpayInstance = getRazorpay();
      if (razorpayInstance && process.env.RAZORPAY_KEY_ID) {
        const options = {
          amount: Math.round(amount * 100), // amount in paise
          currency: currency,
          receipt: `receipt_${Date.now()}_${Math.floor(Math.random() * 1000)}`
        };

        const order = await razorpayInstance.orders.create(options);
        return res.status(200).json({
          success: true,
          order,
          key_id: process.env.RAZORPAY_KEY_ID,
          isLive: true
        });
      }

      // Fallback Demo / Sandbox Mode if Razorpay environment variables are not yet configured
      const mockOrderId = `order_demo_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      return res.status(200).json({
        success: true,
        order: {
          id: mockOrderId,
          entity: 'order',
          amount: Math.round(amount * 100),
          currency: currency,
          receipt: `receipt_demo_${Date.now()}`,
          status: 'created',
          created_at: Math.floor(Date.now() / 1000)
        },
        key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_demo_key',
        isTestMode: true
      });
    } catch (error: any) {
      console.error('Failed to create Razorpay order:', error);
      res.status(500).json({ success: false, error: error.message || 'Something went wrong while creating order' });
    }
  };

  app.post('/.netlify/functions/create-order', handleCreateOrder);
  app.post('/api/razorpay/order', handleCreateOrder);

  // Verify Payment
  const handleVerifyPayment = async (req: express.Request, res: express.Response) => {
    try {
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
      const secret = process.env.RAZORPAY_KEY_SECRET;

      if (!razorpay_order_id || !razorpay_payment_id) {
        return res.status(400).json({ success: false, error: 'Missing payment verification details' });
      }

      // Demo/Test payment verification fallback
      if (!secret || razorpay_order_id.startsWith('order_demo_') || razorpay_signature === 'demo_signature') {
        return res.status(200).json({ success: true, message: "Payment verified successfully (Demo Sandbox Mode)", isTestMode: true });
      }

      if (!razorpay_signature) {
        return res.status(400).json({ success: false, error: 'Missing payment signature' });
      }

      const generated_signature = crypto
        .createHmac('sha256', secret)
        .update(razorpay_order_id + "|" + razorpay_payment_id)
        .digest('hex');

      if (generated_signature === razorpay_signature) {
        res.status(200).json({ success: true, message: "Payment verified successfully" });
      } else {
        res.status(400).json({ success: false, error: "Invalid payment signature" });
      }
    } catch (error: any) {
      console.error('Failed to verify Razorpay signature:', error);
      res.status(500).json({ success: false, error: error.message || 'Verification failed' });
    }
  };

  app.post('/.netlify/functions/verify-payment', handleVerifyPayment);
  app.post('/api/razorpay/verify', handleVerifyPayment);

  // Webhook Handling
  const handleWebhook = async (req: express.Request, res: express.Response) => {
    try {
      const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
      
      if (webhookSecret) {
        const signature = req.headers['x-razorpay-signature'] as string;
        if (!signature) {
          return res.status(400).json({ success: false, error: 'Missing webhook signature' });
        }
        
        const expectedSignature = crypto
          .createHmac('sha256', webhookSecret)
          .update((req as any).rawBody || '')
          .digest('hex');

        if (signature !== expectedSignature) {
          return res.status(400).json({ success: false, error: 'Invalid webhook signature' });
        }
      }
      
      const event = req.body.event;
      console.log(`[Webhook Received]: ${event}`, req.body.payload);
      
      // Handle events
      switch (event) {
        case 'payment.captured':
        case 'payment.authorized':
          // Can implement post-payment processes here
          break;
        case 'payment.failed':
          console.warn('Payment failed webhook:', req.body.payload.payment.entity.error_description);
          break;
        case 'refund.created':
        case 'refund.processed':
          console.info('Refund event received:', req.body.payload.refund.entity.id);
          break;
        default:
          console.log(`Unhandled event: ${event}`);
      }
      
      res.status(200).json({ success: true });
    } catch (error: any) {
      console.error('Webhook processing failed:', error);
      res.status(500).json({ success: false, error: 'Webhook processing failed' });
    }
  };

  app.post('/.netlify/functions/webhook', handleWebhook);
  app.post('/api/razorpay/webhook', handleWebhook);

  // === Vite Middleware for Development ===
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
