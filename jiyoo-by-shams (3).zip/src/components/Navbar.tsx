import React, { useState, useEffect } from 'react';
import { ShoppingBag, User, Search, X } from 'lucide-react';
import { useCart } from '../CartContext';
import { motion, AnimatePresence } from 'motion/react';
import logoImage from '../assets/logo.jpg';

export function Navbar({ onUserClick, onCartClick, onAboutClick }: { onUserClick: () => void; onCartClick: () => void; onAboutClick?: () => void }) {
  const { cartCount, user, logoutUser, searchQuery, setSearchQuery } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${scrolled ? 'bg-[#FAF9F5]/95 border-b border-[#E7E3DA] py-3.5 shadow-xs' : 'bg-transparent py-5'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <motion.div 
              className="flex-shrink-0 cursor-pointer flex items-center gap-3"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <img 
                src={logoImage} 
                alt="JIYOO" 
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/logo.jpg';
                }}
                className="h-9 w-9 md:h-10 md:w-10 rounded-lg object-cover border border-[#E7E3DA]" 
              />
              <span className="font-serif-luxury text-xl sm:text-2xl font-semibold tracking-wider text-brand-black block">JIYOO</span>
            </motion.div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-6 items-center">
              <button 
                onClick={onAboutClick} 
                className="text-sm font-medium text-brand-gray-500 hover:text-brand-black transition-colors cursor-pointer"
              >
                About Us
              </button>
              <button 
                onClick={() => window.dispatchEvent(new CustomEvent('select-category', { detail: 'fruits' }))} 
                className="text-sm font-medium text-brand-gray-500 hover:text-brand-black transition-colors cursor-pointer"
              >
                Fruits
              </button>
              <button 
                onClick={() => window.dispatchEvent(new CustomEvent('select-category', { detail: 'vegetables' }))} 
                className="text-sm font-medium text-brand-gray-500 hover:text-brand-black transition-colors cursor-pointer"
              >
                Vegetables
              </button>
              <button 
                onClick={() => window.dispatchEvent(new CustomEvent('select-category', { detail: 'meat' }))} 
                className="text-sm font-medium text-brand-gray-500 hover:text-brand-black transition-colors cursor-pointer"
              >
                Meat
              </button>
              <button 
                onClick={() => window.dispatchEvent(new CustomEvent('select-category', { detail: 'smoothies' }))} 
                className="text-sm font-medium text-brand-gray-500 hover:text-brand-black transition-colors cursor-pointer"
              >
                Smoothies
              </button>
            </nav>

            {/* Actions */}
            <div className="flex items-center space-x-6">
              
              <button 
                onClick={() => setSearchOpen(!searchOpen)} 
                className="text-brand-gray-900 hover:text-brand-black transition-colors"
                aria-label="Search"
              >
                <Search className="w-5 h-5" strokeWidth={1.5} />
              </button>

              <button 
                onClick={onUserClick} 
                className="text-brand-gray-900 hover:text-brand-black transition-colors flex items-center gap-2"
                aria-label="Account"
              >
                {user ? (
                  user.picture ? (
                    <img src={user.picture} alt={user.name || user.displayName || 'User'} className="w-7 h-7 rounded-full border border-brand-gray-200" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-brand-gray-100 border border-brand-gray-200 flex items-center justify-center text-xs font-semibold text-brand-black">
                      {(user.name || user.displayName || user.email || 'Member').slice(0, 2).toUpperCase()}
                    </div>
                  )
                ) : (
                  <User className="w-5 h-5" strokeWidth={1.5} />
                )}
              </button>
              
              {user && (
                <button
                  onClick={logoutUser}
                  className="text-xs font-medium text-brand-gray-500 hover:text-brand-black transition-colors hidden sm:block"
                >
                  Sign Out
                </button>
              )}

              <button 
                id="cart-icon-button"
                onClick={onCartClick} 
                className="text-brand-gray-900 hover:text-brand-black transition-colors relative"
                aria-label="Cart"
              >
                <motion.div
                  key={cartCount}
                  animate={cartCount > 0 ? { scale: [1, 1.25, 1] } : {}}
                  transition={{ duration: 0.3, ease: 'easeOut' }}
                >
                  <ShoppingBag className="w-5 h-5" strokeWidth={1.5} />
                </motion.div>
                {cartCount > 0 && (
                  <motion.span 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1.5 -right-1.5 bg-brand-black text-brand-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center"
                  >
                    {cartCount}
                  </motion.span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Full screen Search Overlay */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-50 bg-brand-white/95 backdrop-blur-md flex flex-col pt-24 px-4 sm:px-6 lg:px-8"
          >
            <button 
              onClick={() => setSearchOpen(false)}
              className="absolute top-6 right-6 p-2 text-brand-gray-500 hover:text-brand-black transition-colors"
            >
              <X className="w-6 h-6" strokeWidth={1.5} />
            </button>
             <div className="max-w-3xl mx-auto w-full">
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search premium products..."
                className="w-full bg-transparent border-b border-brand-gray-200 text-3xl md:text-5xl font-serif text-brand-black placeholder:text-brand-gray-200 focus:outline-none focus:border-brand-black transition-colors py-4"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    setSearchOpen(false);
                    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                autoFocus
              />
              <div className="mt-12">
                <h3 className="text-sm font-medium text-brand-gray-500 uppercase tracking-widest mb-4">Trending</h3>
                <div className="flex flex-wrap gap-3">
                  {['Mango', 'Avocado', 'Apples', 'Pomegranate', 'Salmon', 'Chicken', 'Mutton', 'Prawns', 'Smoothie'].map(term => (
                    <button 
                      key={term} 
                      onClick={() => { 
                        setSearchQuery(term); 
                        setSearchOpen(false); 
                        document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' }); 
                      }}
                      className="px-4 py-2 rounded-full border border-brand-gray-200 text-sm hover:border-brand-black transition-colors"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
